# Материалы к статье о пятиминутных доходностях альткойнов

Пакет содержит выполненный notebook, исходники расчётов, протокол 2.1.0,
зафиксированные зависимости, таблицы результатов и контрольные суммы данных.
Описательные результаты относятся к 1 января 2022 — 30 июня 2023 (UTC).
Это материалы исследования данных, без обученных альфа-моделей и бэктестов.

Встроенные графики notebook показывают измеренные результаты. Художественная
обложка сайта в пакет не входит. Исходные биржевые архивы и parquet не включены:
их источники и контрольные суммы перечислены в манифестах. Для загрузки данных
нужен доступ к официальному публичному архиву Binance. Заключительное полугодие
не входит в анализ EDA, хотя подготовка хранит полную историю 2022–2023.

Из корня распакованного пакета, с Python 3.12 и установленным uv:

```text
uv export --frozen --no-emit-project --no-emit-local --no-dev --emit-index-url --format requirements-txt --output-file requirements.txt
uv venv --python 3.12
uv pip install -r requirements.txt
uv run --no-project python -m research.src.alpha_study.data prepare
uv run --no-project python -m research.src.alpha_study.build_notebook --execute
```

Команды установки отражают полный lockfile проекта и могут загружать крупные
библиотеки. Для самого EDA нужны numpy, pandas, scipy, statsmodels, matplotlib,
seaborn, pyarrow, requests, filelock, nbformat, nbclient, nbconvert, ipykernel,
threadpoolctl; точные использованные версии находятся в eda_summary.json.
Модули infra/protocol входят в пакет и импортируются из его корня.

MANIFEST.sha256 проверяет каждый включённый файл. Значения source_sha256,
spec_sha256 и data_hash в eda_summary.json связывают расчёт с исходниками,
настройками и биржевыми манифестами. Метка Git-коммита описывает исходное рабочее
окружение; содержимое файлов точнее задаётся перечисленными SHA-256.
