"""The evaluation protocol as code.

Rules (see infra/README.md for the wording):

1. a spec is registered before the run: ``spec.register`` appends a ``freeze``
   event (spec sha256, data hash, code version) to the append-only ledger;
2. walk-forward with a separate validation block: ``walkforward.make_windows``
   gives train -> [purge] -> validation -> [purge] -> test;
3. day-block bootstrap: ``bootstrap.day_block_bootstrap`` resamples whole days
   because observations within a day are correlated;
4. null comparison with random inputs of the same size: ``null`` module;
5. the deflated Sharpe ratio across all tested variants: ``dsr`` module;
6. results defined after seeing the data are post hoc: ``posthoc`` module.
"""

from . import bootstrap, dsr, ledger, null, posthoc, spec, walkforward

__all__ = ["bootstrap", "dsr", "ledger", "null", "posthoc", "spec", "walkforward"]
