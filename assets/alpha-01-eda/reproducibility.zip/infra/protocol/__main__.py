"""``python -m infra.protocol``: ledger audit and DSR recompute.

python -m infra.protocol check-ledger LEDGER [--specs DIR]
python -m infra.protocol dsr LEDGER
"""

from __future__ import annotations

import argparse
import sys

from . import dsr, ledger


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="infra.protocol")
    sub = ap.add_subparsers(dest="cmd", required=True)
    c = sub.add_parser("check-ledger", help="audit a ledger file (exit 1 on problems)")
    c.add_argument("ledger")
    c.add_argument("--specs", help="directory of spec .toml files to cross-check")
    d = sub.add_parser("dsr", help="deflated Sharpe of every result against all trials")
    d.add_argument("ledger")
    a = ap.parse_args(argv)

    if a.cmd == "check-ledger":
        problems = ledger.check(a.ledger, a.specs)
        for p in problems:
            print(p, file=sys.stderr)
        print(
            f"{a.ledger}: {'clean' if not problems else f'{len(problems)} problem(s)'}"
        )
        return 1 if problems else 0
    if a.cmd == "dsr":
        for (eid, sha, dh), v in dsr.current_dsr(a.ledger).items():
            print(f"{eid}  spec={sha[:12]}  data={str(dh)[:12]}  dsr={v}")
        return 0
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
