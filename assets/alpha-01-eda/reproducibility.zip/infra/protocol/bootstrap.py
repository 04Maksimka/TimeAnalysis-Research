"""Bootstrap intervals (protocol rule 3).

``bootstrap_trades`` resamples trades (iid) and ``bootstrap_daily`` resamples
blocks of days; ``day_block_bootstrap`` is the general version for any statistic
computed over per-observation values tagged by day — resampling whole days,
because observations within a day are correlated.
"""

from __future__ import annotations

import math

import numpy as np


def bootstrap_trades(
    returns: np.ndarray, n_boot: int = 5000, seed: int = 0, level: float = 0.95
) -> dict:
    """Percentile intervals of expectancy and profit factor by resampling trades with
    replacement."""
    r = np.asarray(returns, dtype=np.float64)
    if r.size < 2:
        return {}
    rng = np.random.default_rng(seed)
    idx = rng.integers(0, r.size, size=(n_boot, r.size))
    sample = r[idx]
    means = sample.mean(axis=1)
    gains = np.where(sample > 0, sample, 0.0).sum(axis=1)
    losses = -np.where(sample < 0, sample, 0.0).sum(axis=1)
    with np.errstate(divide="ignore", invalid="ignore"):
        pf = np.where(losses > 0, gains / losses, np.inf)
    a = (1.0 - level) / 2.0 * 100.0
    return {
        "expectancy_ci": [
            float(np.percentile(means, a)),
            float(np.percentile(means, 100 - a)),
        ],
        "profit_factor_ci": [
            float(np.percentile(pf, a)),
            float(np.percentile(pf, 100 - a)),
        ],
        "p_expectancy_le_0": float((means <= 0).mean()),
    }


def moving_block_indices(
    n: int, block: int, n_boot: int, rng: np.random.Generator
) -> np.ndarray:
    """Moving-block bootstrap index matrix (n_boot, n): blocks of ``block`` days, no wrap."""
    block = max(1, min(block, n))
    n_blocks = math.ceil(n / block)
    starts = rng.integers(0, n - block + 1, size=(n_boot, n_blocks))
    idx = (starts[:, :, None] + np.arange(block)[None, None, :]).reshape(n_boot, -1)
    return idx[:, :n]


def bootstrap_daily(
    daily_returns: np.ndarray,
    benchmark: np.ndarray | None = None,
    block: int = 10,
    n_boot: int = 5000,
    seed: int = 0,
    level: float = 0.95,
) -> dict:
    """Moving-block intervals of total return and Sharpe; with a benchmark, of the paired
    differences."""
    r = np.asarray(daily_returns, dtype=np.float64)
    if r.size < 2 * block:
        return {}
    rng = np.random.default_rng(seed)
    idx = moving_block_indices(r.size, block, n_boot, rng)
    s = r[idx]
    tot = np.prod(1.0 + s, axis=1) - 1.0
    sd = s.std(axis=1, ddof=1)
    with np.errstate(divide="ignore", invalid="ignore"):
        shp = np.where(sd > 0, s.mean(axis=1) / sd * math.sqrt(365), 0.0)
    a = (1.0 - level) / 2.0 * 100.0
    out = {
        "total_return_ci": [
            float(np.percentile(tot, a)),
            float(np.percentile(tot, 100 - a)),
        ],
        "sharpe_ci": [float(np.percentile(shp, a)), float(np.percentile(shp, 100 - a))],
    }
    if benchmark is not None:
        b = np.asarray(benchmark, dtype=np.float64)[idx]
        btot = np.prod(1.0 + b, axis=1) - 1.0
        bsd = b.std(axis=1, ddof=1)
        with np.errstate(divide="ignore", invalid="ignore"):
            bshp = np.where(bsd > 0, b.mean(axis=1) / bsd * math.sqrt(365), 0.0)
        out["excess_total_return_ci"] = [
            float(np.percentile(tot - btot, a)),
            float(np.percentile(tot - btot, 100 - a)),
        ]
        out["sharpe_difference_ci"] = [
            float(np.percentile(shp - bshp, a)),
            float(np.percentile(shp - bshp, 100 - a)),
        ]
    return out


def day_block_bootstrap(
    values: np.ndarray,
    day_ids: np.ndarray,
    stat=np.mean,
    n_boot: int = 2000,
    seed: int = 0,
    level: float = 0.95,
) -> dict:
    """``stat`` over ``values`` with a day-level bootstrap: whole days are resampled with
    replacement (hours inside a day are correlated, so resampling rows would be too narrow).

    ``day_ids`` tags each observation with its day (dates, ints, strings — anything
    ``np.unique`` can group). Returns the observed statistic, its percentile interval and
    the bootstrap distribution. The common ``stat=np.mean`` case uses day sums.
    """
    v = np.asarray(values, dtype=np.float64)
    uniq, inv = np.unique(np.asarray(day_ids), return_inverse=True)
    d = uniq.size
    rng = np.random.default_rng(seed)
    idx = rng.integers(0, d, size=(n_boot, d))
    if stat is np.mean:
        sums = np.bincount(inv, weights=v, minlength=d)
        cnts = np.bincount(inv, minlength=d)
        with np.errstate(invalid="ignore", divide="ignore"):
            dist = sums[idx].sum(axis=1) / cnts[idx].sum(axis=1)
        observed = float(v.mean()) if v.size else math.nan
    else:
        days = [v[inv == i] for i in range(d)]
        dist = np.array([stat(np.concatenate([days[j] for j in row])) for row in idx])
        observed = float(stat(v)) if v.size else math.nan
    a = (1.0 - level) / 2.0 * 100.0
    dist = dist[np.isfinite(dist)]
    return {
        "stat": observed,
        "ci": [
            float(np.percentile(dist, a)),
            float(np.percentile(dist, 100 - a)),
        ]
        if dist.size
        else [math.nan, math.nan],
        "dist": dist,
    }
