"""Sharpe statistics and the deflated Sharpe ratio (protocol rule 5).

DSR (Bailey and Lopez de Prado, 2012 and 2014) deflates a result's Sharpe by the
number of variants tried and the spread of their Sharpe ratios — the ledger keeps
every trial, so the count is honest.
"""

from __future__ import annotations

import csv
import math
from pathlib import Path

import numpy as np
from scipy import stats

from . import ledger

EULER_GAMMA = 0.5772156649015329


def sharpe(daily_returns: np.ndarray, periods: int = 365) -> float:
    """Annualised Sharpe ratio of daily returns (crypto trades every day: 365)."""
    r = np.asarray(daily_returns)
    sd = r.std(ddof=1) if r.size > 1 else 0.0
    return float(r.mean() / sd * math.sqrt(periods)) if sd > 0 else 0.0


def probabilistic_sharpe(
    sr: float, n_obs: int, skew: float, kurtosis: float, sr_benchmark: float = 0.0
) -> float:
    """P(true Sharpe > sr_benchmark) given an observed per-period Sharpe ``sr``.

    ``kurtosis`` is the ordinary (non-excess) kurtosis; a normal distribution has 3.
    """
    if n_obs < 2:
        return math.nan
    denom = 1.0 - skew * sr + (kurtosis - 1.0) / 4.0 * sr * sr
    if denom <= 0:
        return math.nan
    z = (sr - sr_benchmark) * math.sqrt(n_obs - 1) / math.sqrt(denom)
    return float(stats.norm.cdf(z))


def expected_max_sharpe(n_trials: int, var_sharpe: float) -> float:
    """Expected maximum of ``n_trials`` per-period Sharpe ratios whose true value is zero."""
    if n_trials <= 1 or var_sharpe <= 0:
        return 0.0
    z1 = stats.norm.ppf(1.0 - 1.0 / n_trials)
    z2 = stats.norm.ppf(1.0 - 1.0 / (n_trials * math.e))
    return float(math.sqrt(var_sharpe) * ((1.0 - EULER_GAMMA) * z1 + EULER_GAMMA * z2))


def deflated_sharpe(
    daily_returns: np.ndarray, n_trials: int, var_trial_sharpe: float
) -> dict:
    """Deflated Sharpe ratio of daily returns, given how many strategies were tried and how
    much their (per-period) Sharpe ratios varied. With one trial it equals PSR against zero."""
    r = np.asarray(daily_returns, dtype=np.float64)
    if r.size < 3 or r.std(ddof=1) == 0:
        return {
            "dsr": math.nan,
            "sr_per_day": 0.0,
            "sr0_per_day": 0.0,
            "n_trials": n_trials,
        }
    sr = float(r.mean() / r.std(ddof=1))
    skew = float(stats.skew(r))
    kurt = float(stats.kurtosis(r, fisher=False))
    sr0 = expected_max_sharpe(n_trials, var_trial_sharpe)
    return {
        "dsr": probabilistic_sharpe(sr, r.size, skew, kurt, sr0),
        "sr_per_day": sr,
        "sr0_per_day": sr0,
        "skew": skew,
        "kurtosis": kurt,
        "n_trials": int(n_trials),
        "var_trial_sharpe": float(var_trial_sharpe),
    }


def current_dsr(path: str | Path) -> dict[tuple, float | None]:
    """Deflated Sharpe ratio of every result against ALL results now in the ledger.

    A result's own ``dsr`` counts only the trials that existed when it ran, so the first trial of
    a ledger is deflated by nothing. This recomputes each one with today's number of trials and
    spread of Sharpe ratios. It needs the result's skew, kurtosis and day count (stored since
    the first version of the ledger) or its ``oos_daily.csv`` next to the report; otherwise None.
    """
    res = ledger.results(path)
    srs = [r["sr_per_day"] for r in res if r.get("sr_per_day") is not None]
    n = len(srs)
    var = float(np.var(srs, ddof=1)) if n > 1 else 0.0
    out: dict[tuple, float | None] = {}
    for r in res:
        key = (r["experiment_id"], r["spec_sha256"], r.get("data_hash"))
        if r.get("oos_days") and r.get("skew") is not None:
            sr0 = expected_max_sharpe(n, var)
            out[key] = probabilistic_sharpe(
                r["sr_per_day"], r["oos_days"], r["skew"], r["kurtosis"], sr0
            )
            continue
        daily = Path(r.get("report", "")).with_name("oos_daily.csv")
        if daily.exists():
            with daily.open() as f:
                d = np.array([float(x["strategy_return"]) for x in csv.DictReader(f)])
            out[key] = deflated_sharpe(d, n, var)["dsr"]
        else:
            out[key] = None
    return out
