"""Append-only trial ledger.

Every run writes a ``freeze`` event (spec hash, data hash, code version) before any result is
computed and a ``result`` event afterwards. The ledger is the record of everything that was tried:
the deflated Sharpe ratio of a new result is computed against all results in it.

Rule: once an experiment id has a result, its spec cannot change. A changed spec needs a new id, so
that a revised hypothesis counts as another trial instead of silently replacing the first.

``check`` audits a ledger file (and, optionally, a directory of spec files) after the fact:
malformed lines, out-of-order timestamps, results with no matching freeze and specs edited after
registration.
"""

from __future__ import annotations

import hashlib
import json
import subprocess
import tomllib
from datetime import UTC, datetime
from pathlib import Path


class LedgerError(RuntimeError):
    pass


def now_utc() -> str:
    return datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def code_version(repo_dir: str | Path = ".") -> dict:
    """Git commit and whether the working tree has uncommitted changes (None outside git).

    ``*/ledger/**`` paths are left out of the check: every run appends to the ledger, so
    counting it would mark the second run of a session dirty although the code is unchanged.
    """
    try:
        commit = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=repo_dir,
            capture_output=True,
            text=True,
            check=True,
        ).stdout.strip()
        dirty = bool(
            subprocess.run(
                [
                    "git",
                    "status",
                    "--porcelain",
                    "--untracked-files=no",
                    "--",
                    ":/",
                    ":(glob,exclude)**/ledger/**",
                ],
                cwd=repo_dir,
                capture_output=True,
                text=True,
                check=True,
            ).stdout.strip()
        )
        return {"commit": commit, "dirty": dirty}
    except (OSError, subprocess.CalledProcessError):
        return {"commit": None, "dirty": None}


def read(path: str | Path) -> list[dict]:
    p = Path(path)
    if not p.exists():
        return []
    return [json.loads(line) for line in p.read_text().splitlines() if line.strip()]


def append(path: str | Path, event: dict) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open("a") as f:
        f.write(json.dumps(event, sort_keys=True) + "\n")


def check_freeze(path: str | Path, experiment_id: str, spec_sha256: str) -> None:
    for ev in read(path):
        if (
            ev.get("event") == "result"
            and ev.get("experiment_id") == experiment_id
            and ev.get("spec_sha256") != spec_sha256
        ):
            raise LedgerError(
                f"experiment {experiment_id!r} already has a result under a different spec "
                f"({ev.get('spec_sha256')[:12]}); give the revised spec a new id"
            )


def freeze(
    path: str | Path, experiment_id: str, spec_sha256: str, data_hash: str, extra: dict
) -> dict:
    check_freeze(path, experiment_id, spec_sha256)
    event = {
        "event": "freeze",
        "utc": now_utc(),
        "experiment_id": experiment_id,
        "spec_sha256": spec_sha256,
        "data_hash": data_hash,
        "code": code_version(),
        **extra,
    }
    append(path, event)
    return event


def results(path: str | Path) -> list[dict]:
    """Latest result per (experiment id, spec, data) - reruns of the same thing count once."""
    latest: dict[tuple, dict] = {}
    for ev in read(path):
        if ev.get("event") == "result":
            latest[(ev["experiment_id"], ev["spec_sha256"], ev.get("data_hash"))] = ev
    return list(latest.values())


def check(path: str | Path, specs_dir: str | Path | None = None) -> list[str]:
    """Audit a ledger file; return the list of problems (empty = clean).

    Checked, in file order:

    * every line is valid JSON carrying ``event``, ``experiment_id`` and ``utc``;
    * ``utc`` never decreases (the ledger is append-only, so timestamps order lines);
    * every ``result`` that is not marked ``post_hoc`` was preceded by a ``freeze`` of the
      same experiment id and spec sha256;
    * with ``specs_dir``, every ``*.toml`` there whose experiment id already has a freeze under
      a *different* sha256 was edited after registration.
    """
    problems: list[str] = []
    p = Path(path)
    if not p.exists():
        return [f"{p}: no such ledger"]
    frozen: dict[str, set[str]] = {}
    prev_utc = ""
    for n, line in enumerate(p.read_text().splitlines(), 1):
        if not line.strip():
            continue
        try:
            ev = json.loads(line)
        except ValueError:
            problems.append(f"line {n}: invalid JSON")
            continue
        for key in ("event", "experiment_id", "utc"):
            if key not in ev:
                problems.append(f"line {n}: missing {key!r}")
        if "utc" in ev:
            if ev["utc"] < prev_utc:
                problems.append(
                    f"line {n}: utc {ev['utc']} goes backwards (after {prev_utc})"
                )
            prev_utc = max(prev_utc, ev["utc"])
        if ev.get("event") == "freeze":
            frozen.setdefault(ev.get("experiment_id", ""), set()).add(
                ev.get("spec_sha256", "")
            )
        elif ev.get("event") == "result" and not ev.get("post_hoc"):
            eid, sha = ev.get("experiment_id"), ev.get("spec_sha256")
            if sha not in frozen.get(eid, set()):
                problems.append(
                    f"line {n}: result of {eid!r} has no preceding freeze "
                    f"under the same spec sha256 ({sha!r}); mark it post_hoc or register the spec"
                )
    if specs_dir is not None:
        for f in sorted(Path(specs_dir).glob("*.toml")):
            try:
                raw = tomllib.loads(f.read_text())
                eid = raw["experiment"]["id"]
            except (KeyError, ValueError):
                problems.append(f"{f.name}: not a readable spec (no experiment.id)")
                continue
            sha = sha256_bytes(f.read_bytes())
            if eid in frozen and sha not in frozen[eid]:
                problems.append(
                    f"{f.name}: spec of {eid!r} was edited after registration "
                    f"(current sha256 {sha[:12]} not in the frozen set)"
                )
    return problems
