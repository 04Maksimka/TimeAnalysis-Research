"""Null comparisons (protocol rule 4): what random inputs of the same size produce."""

from __future__ import annotations

import numpy as np


def empirical_p(observed: float, null: np.ndarray, greater: bool = True) -> float:
    """One-sided empirical p-value: (1 + #{null >= observed}) / (1 + n).

    ``greater=True`` asks "how often does the null do at least as well" — small p
    means the observed statistic is unusually high under the null.
    """
    n = np.asarray(null, dtype=np.float64)
    n = n[np.isfinite(n)]
    if n.size == 0:
        return float("nan")
    hits = (n >= observed).sum() if greater else (n <= observed).sum()
    return float((1 + hits) / (1 + n.size))


def subset_null(values: np.ndarray, k: int, draws: int, seed: int) -> np.ndarray:
    """Means of ``draws`` random subsets of size ``k`` of ``values`` (no replacement).

    The null for "the marked subset beats the average": does a same-sized random
    subset of the population look as good?
    """
    v = np.asarray(values, dtype=np.float64)
    rng = np.random.default_rng(seed)
    return np.array(
        [v[rng.choice(v.size, k, replace=False)].mean() for _ in range(draws)]
    )


def random_input_null(statistic, draw_input, n_draws: int, seed: int) -> np.ndarray:
    """``statistic(draw_input(rng))`` over ``n_draws`` random inputs.

    ``draw_input(rng)`` must produce one input of the same size and kind as the
    real one (e.g. shuffled returns, random timestamps in the same window). The
    returned distribution is what the statistic looks like when the input carries
    no signal.
    """
    rng = np.random.default_rng(seed)
    return np.array([statistic(draw_input(rng)) for _ in range(n_draws)])
