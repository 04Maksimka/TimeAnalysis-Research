"""Post-hoc marking (protocol rule 6).

A result is pre-registered only if a matching ``freeze`` (same experiment id and
spec sha256) precedes it in the ledger AND the spec does not set
``experiment.post_hoc = true``. Everything else is post hoc: the result event
carries ``post_hoc: true`` and ``post_hoc_reason``, and its verdict is forced to
``DESCRIPTIVE (post hoc)`` — it can never read CONFIRMED/PASS.
"""

from __future__ import annotations

DESCRIPTIVE = "DESCRIPTIVE (post hoc)"


def freeze_for(events: list[dict], experiment_id: str, spec_sha256: str) -> dict | None:
    """The earliest freeze of this exact spec, or None."""
    for ev in events:
        if (
            ev.get("event") == "freeze"
            and ev.get("experiment_id") == experiment_id
            and ev.get("spec_sha256") == spec_sha256
        ):
            return ev
    return None


def is_pre_registered(
    events: list[dict], spec_raw: dict, experiment_id: str, spec_sha256: str
) -> bool:
    """True when a matching freeze exists and the spec does not declare itself post hoc."""
    if freeze_for(events, experiment_id, spec_sha256) is None:
        return False
    return not bool(spec_raw.get("experiment", {}).get("post_hoc", False))


def post_hoc_reason(
    events: list[dict], spec_raw: dict, experiment_id: str, spec_sha256: str
) -> str | None:
    """Why this result is post hoc (None when it is pre-registered)."""
    reasons = []
    if freeze_for(events, experiment_id, spec_sha256) is None:
        reasons.append("no freeze of this spec precedes the result in the ledger")
    if spec_raw.get("experiment", {}).get("post_hoc", False):
        reasons.append(
            spec_raw["experiment"].get("post_hoc_reason")
            or "spec sets experiment.post_hoc = true"
        )
    return "; ".join(reasons) or None


def verdict(decision: dict, post_hoc: bool) -> dict:
    """The gate decision, overridden when the result is post hoc."""
    if not post_hoc:
        return decision
    return {**decision, "verdict": DESCRIPTIVE, "post_hoc": True}


def banner(post_hoc: bool) -> str:
    """The report-header line for post-hoc results ('' when pre-registered)."""
    if not post_hoc:
        return ""
    return (
        "**DESCRIPTIVE (post hoc)** — this analysis was defined after seeing the "
        "data. It is not a registered trial and cannot support a PASS."
    )
