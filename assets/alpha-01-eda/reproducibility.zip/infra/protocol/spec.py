"""Experiment specs: hashing, loading and registration (protocol rule 1).

A spec is a TOML file in ``experiments/``. ``register`` is the "register before
launch" step: it freezes the spec hash into the ledger (refusing if the same
experiment id already has a result under a different spec).
"""

from __future__ import annotations

import tomllib
from pathlib import Path

from . import ledger


def sha256_file(path: str | Path) -> str:
    return ledger.sha256_bytes(Path(path).read_bytes())


def load_toml(path: str | Path) -> dict:
    return tomllib.loads(Path(path).read_text())


def register(
    spec_path: str | Path,
    ledger_path: str | Path,
    data_hash: str = "",
    extra: dict | None = None,
) -> dict:
    """Freeze ``spec_path`` into ``ledger_path`` and return the freeze event.

    Raises LedgerError when the experiment id already produced a result under a
    different spec — a revised hypothesis must register under a new id.
    """
    p = Path(spec_path)
    raw = load_toml(p)
    experiment_id = raw["experiment"]["id"]
    sha = sha256_file(p)
    return ledger.freeze(
        ledger_path,
        experiment_id,
        sha,
        data_hash,
        {"spec_path": str(p), **(extra or {})},
    )
