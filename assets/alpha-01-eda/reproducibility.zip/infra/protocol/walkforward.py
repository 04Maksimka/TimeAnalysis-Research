"""Walk-forward windows with a separate validation block (protocol rule 2).

Each window is train -> [purge] -> validation -> [purge] -> test. Parameters are
ranked on the training block, finalists are re-scored on the validation block and
only the winner is applied once to the test block. ``validation_months=0`` (with
``purge_days=0``) reproduces the plain train -> test layout.

Purging removes the overlap between a block boundary and the next block, so a
candidate whose holding period reaches past the end of a block cannot leak into
the block the score is chosen on.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import TypeVar

T = TypeVar("T")


def to_ms(value: str | datetime | int) -> int:
    """Milliseconds since the epoch (UTC) from an ISO date/time, a datetime or an int."""
    if isinstance(value, int):
        return int(value)
    if isinstance(value, str):
        value = datetime.fromisoformat(value)
    if value.tzinfo is None:
        value = value.replace(tzinfo=UTC)
    return int(value.timestamp() * 1000)


@dataclass(frozen=True)
class Window:
    train_start: int  # ms, inclusive
    train_end: int  # ms, exclusive
    test_start: int
    test_end: int  # ms, exclusive
    val_start: int | None = None  # ms, inclusive; None: no validation block
    val_end: int | None = None  # ms, exclusive

    @property
    def has_validation(self) -> bool:
        return self.val_start is not None and self.val_end is not None


def add_months(t_ms: int, months: int) -> int:
    import calendar

    d = datetime.fromtimestamp(t_ms / 1000, UTC)
    y, m = divmod(d.month - 1 + months, 12)
    day = min(d.day, calendar.monthrange(d.year + y, m + 1)[1])
    return to_ms(d.replace(year=d.year + y, month=m + 1, day=day))


def make_windows(
    start: str,
    end: str,
    train_months: int,
    test_months: int,
    anchored: bool = False,
    validation_months: int = 0,
    purge_days: int = 0,
) -> list[Window]:
    """Consecutive test windows of ``test_months`` on the same calendar grid as the
    plain train -> test layout: the first test window starts ``train_months`` after
    ``start`` regardless of the validation settings.

    With ``validation_months > 0`` a validation block of that length is carved out
    before the test window, separated by ``purge_days`` on both sides; the training
    block then ends ``purge_days`` before validation starts, so a rolling window's
    training start moves earlier by ``validation_months + 2 * purge_days``. With
    ``validation_months = 0`` the layout is train -> test exactly as before
    (``purge_days`` is ignored: it only separates validation from its neighbours).
    Rolling by default; ``anchored`` keeps the training start fixed. The last test
    window must end on or before ``end``.
    """
    t0, t_end = to_ms(start), to_ms(end)
    purge = purge_days * 86_400_000
    out = []
    k = 0
    while True:
        test_start = add_months(t0, train_months + k * test_months)
        test_end = add_months(test_start, test_months)
        if test_end > t_end:
            break
        if validation_months > 0:
            val_end = test_start - purge
            val_start = add_months(val_end, -validation_months)
            train_end = val_start - purge
        else:
            val_start = val_end = None
            train_end = test_start
        train_start = t0 if anchored else add_months(train_end, -train_months)
        out.append(
            Window(train_start, train_end, test_start, test_end, val_start, val_end)
        )
        k += 1
    return out


def select(
    candidates: list[T],
    train_score: list[float],
    val_score: list[float] | None = None,
    n_finalists: int = 10,
) -> T | None:
    """Pick one candidate by train score, then validation score.

    Candidates are ranked by ``train_score``; the top ``n_finalists`` are re-ranked
    by ``val_score`` (ties fall back to the train score). With no validation scores
    the best training score wins — the plain train -> test behavior.

    Returns None when every candidate's train score is -inf (abstain: nothing met
    the minimum requirements), or, with validation, when every finalist's
    validation score is -inf.
    """
    finite = [i for i, s in enumerate(train_score) if s > -math.inf]
    if not finite:
        return None
    finalists = sorted(finite, key=lambda i: train_score[i], reverse=True)[:n_finalists]
    if val_score is None:
        return candidates[finalists[0]]
    best = max(finalists, key=lambda i: (val_score[i], train_score[i]))
    if val_score[best] == -math.inf:
        return None
    return candidates[best]
