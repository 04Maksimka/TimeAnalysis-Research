"""Reproducible, chronological alpha research shared by the notebook series.

Model-specific studies are introduced after discussion of the preceding study.
Importing this package never downloads data or runs an experiment.
"""
