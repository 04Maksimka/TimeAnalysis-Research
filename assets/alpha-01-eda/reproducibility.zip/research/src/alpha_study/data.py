"""Reproducible, checksum-verified Binance data for the monthly alpha study.

Candidates come from archive prefixes and their January 2022 files. Protocol v2
also requires a frozen, dated official exchangeInfo snapshot; preparation never
requests live listing status. Dataframe indices denote candle OPEN times; values
are available at ``available_at``. Missing grid rows are retained, never filled.
"""

from __future__ import annotations

import argparse
import hashlib
import io
import json
import time
import tomllib
import xml.etree.ElementTree as ET
import zipfile
from concurrent.futures import ThreadPoolExecutor, as_completed
from email.utils import parsedate_to_datetime
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import requests

DEFAULT_ROOT = Path(__file__).resolve().parents[2] / "alpha_study"
ARCHIVE_URL = "https://data.binance.vision/"
LIST_URL = "https://s3-ap-northeast-1.amazonaws.com/data.binance.vision"
EXCHANGE_INFO_URL = "https://api.binance.com/api/v3/exchangeInfo"
PREFIX = "data/spot/monthly/klines/"
SELECTION_START = pd.Timestamp("2022-01-01", tz="UTC")
SELECTION_END = pd.Timestamp("2022-01-31", tz="UTC")
STUDY_END = pd.Timestamp("2024-01-01", tz="UTC")
DEVELOPMENT_END = pd.Timestamp("2023-07-01", tz="UTC")
DAILY_START = SELECTION_START - pd.Timedelta(days=200)
KLINE_COLUMNS = [
    "open_time",
    "open",
    "high",
    "low",
    "close",
    "volume",
    "close_time",
    "quote_volume",
    "trade_count",
    "taker_buy_base_volume",
    "taker_buy_quote_volume",
    "ignore",
]
NUMERIC_COLUMNS = [
    "open",
    "high",
    "low",
    "close",
    "volume",
    "quote_volume",
    "trade_count",
    "taker_buy_base_volume",
    "taker_buy_quote_volume",
]
STABLECOINS = {
    "AEUR",
    "BIDR",
    "BUSD",
    "DAI",
    "EURI",
    "FDUSD",
    "IDRT",
    "PAX",
    "SUSD",
    "TUSD",
    "USDC",
    "USDD",
    "USDP",
    "USDS",
    "USDSB",
    "USDT",
    "UST",
    "USTC",
    "VAI",
    "XUSD",
    "USD1",
    "U",
}
FIAT = {
    "ARS",
    "AUD",
    "BRL",
    "EUR",
    "GBP",
    "NGN",
    "PLN",
    "RON",
    "RUB",
    "TRY",
    "UAH",
    "ZAR",
}
LEVERAGED_BASES = {
    "AAVE",
    "ADA",
    "BCH",
    "BNB",
    "BTC",
    "DOT",
    "EOS",
    "ETH",
    "FIL",
    "LINK",
    "LTC",
    "SUSHI",
    "TRX",
    "UNI",
    "XRP",
    "XTZ",
    "YFI",
}


def _canonical_frequency(frequency: str) -> str:
    aliases = {"5min": "5min", "5m": "5min", "1d": "1d", "1D": "1d"}
    if frequency not in aliases:
        raise ValueError("Only five-minute and daily candle frequencies are supported")
    return aliases[frequency]


def validate_data_contract(root: Path | str) -> str:
    """Attest only data-affecting settings, rejecting unsupported protocol edits.

    V1 retains the historical universe; v2 filters it through dated listing
    evidence. Their contract hashes cannot silently attest each other's caches.
    V1 hashing is preserved for reproducibility of the original study.
    """
    location = Path(root) / "protocol.toml"
    if not location.exists():
        raise FileNotFoundError(
            f"Missing data protocol: {location}; copy the versioned study protocol before preparing another root"
        )
    with location.open("rb") as stream:
        protocol = tomllib.load(stream)
    version = protocol.get("study", {}).get("version")
    if version not in {"1.0.0", "2.0.0", "2.1.0"}:
        raise ValueError(f"Unsupported data protocol study.version={version!r}")
    current_filter = version in {"2.0.0", "2.1.0"}
    expected = {
        "data": {
            "base_url": ARCHIVE_URL,
            "market": "spot",
            "quote": "USDT",
            "interval": "5m",
            "pandas_frequency": "5min",
            "timezone": "UTC",
            "timestamp_index": "open_time",
            "start": SELECTION_START,
            "end_exclusive": STUDY_END,
            "selection_end_exclusive": SELECTION_END,
            "final_start": DEVELOPMENT_END,
            "eda_include_final_default": False,
            "checksum_algorithm": "sha256",
            "missing_policy": "no_imputation_no_cross_gap_returns",
        },
        "selection": {
            "coins": 6,
            "high_liquidity_count": 2,
            "median_liquidity_count": 2,
            "high_volatility_count": 2,
            "liquidity_metric": "median_daily_quote_volume",
            "volatility_metric": "std_5m_log_return",
            "minimum_coverage": 0.99,
            "exclude": ["bitcoin", "stablecoins", "leveraged_tokens"],
            "historical_universe": True,
            "future_listing_survival_filter": current_filter,
            "tie_break": "symbol_ascending",
            "groups_disjoint": True,
            "high_volatility_min_liquidity": (
                "current_tradable_eligible_universe_median"
                if current_filter
                else "initial_eligible_universe_median"
            ),
        },
        "regimes": {"symbol": "BTCUSDT", "interval": "1d", "warmup_days": 200},
    }
    for section, fields in expected.items():
        for name, value in fields.items():
            actual = protocol.get(section, {}).get(name)
            if isinstance(value, pd.Timestamp):
                actual = _utc(actual) if actual is not None else None
            if actual != value:
                raise ValueError(
                    f"Unsupported data protocol {section}.{name}={actual!r}; expected {value!r}. "
                    "Create a new dataset version; do not overwrite the frozen universe."
                )
    expected["exclusion_sets"] = {
        "stablecoins": sorted(STABLECOINS),
        "fiat": sorted(FIAT),
        "leveraged_bases": sorted(LEVERAGED_BASES),
        "leveraged_suffixes": ["UP", "DOWN", "BULL", "BEAR"],
    }
    if current_filter:
        _, evidence = load_current_spot_snapshot(root, protocol=protocol)
        expected["current_spot_snapshot"] = evidence
    encoded = json.dumps(expected, sort_keys=True, default=str)
    return hashlib.sha256(encoded.encode("utf-8")).hexdigest()


def load_current_spot_snapshot(
    root: Path | str, *, protocol: dict | None = None
) -> tuple[set[str], dict[str, Any]]:
    """Validate frozen v2 listing evidence without fetching or refreshing it.

    The retrieval and HTTP dates must match the protocol's explicit as-of day,
    rather than today's wall clock, so historical replays remain reproducible.
    A projected snapshot must retain an entry for every historical candidate,
    including symbols absent from the response. Preparation checks that coverage.
    """
    root = Path(root)
    if protocol is None:
        with (root / "protocol.toml").open("rb") as stream:
            protocol = tomllib.load(stream)
    settings = protocol.get("selection", {})
    relative = settings.get("current_spot_snapshot")
    as_of = settings.get("current_spot_as_of")
    if not isinstance(relative, str) or not isinstance(as_of, str):
        raise ValueError(
            "V2 requires selection.current_spot_snapshot and current_spot_as_of"
        )
    try:
        day = pd.Timestamp(as_of)
    except (ValueError, TypeError) as error:
        raise ValueError("Invalid selection.current_spot_as_of date") from error
    if day.strftime("%Y-%m-%d") != as_of:
        raise ValueError("selection.current_spot_as_of must be YYYY-MM-DD")
    path = (root / relative).resolve()
    if Path(relative).is_absolute() or not path.is_relative_to(root.resolve()):
        raise ValueError("Current Spot snapshot must be inside the study root")
    document = json.loads(path.read_text(encoding="utf-8"))
    if (
        document.get("schema_version") != 1
        or document.get("as_of") != as_of
        or document.get("source_url") != EXCHANGE_INFO_URL
        or document.get("http_status") != 200
        or document.get("evidence_status") != "verified_live_response"
        or document.get("projection_policy") != "all_historical_ranked_candidates"
    ):
        raise ValueError(
            "Invalid current Spot snapshot source, status, schema or as-of evidence"
        )
    raw_digest = document.get("raw_response_sha256", "")
    if (
        not isinstance(raw_digest, str)
        or len(raw_digest) != 64
        or any(char not in "0123456789abcdef" for char in raw_digest)
    ):
        raise ValueError(
            "Current Spot snapshot requires a SHA256 of its original response"
        )
    try:
        fetched = pd.Timestamp(document["fetched_at_utc"])
        server_date = pd.Timestamp(parsedate_to_datetime(document["http_date"]))
        if fetched.tz is None or server_date.tz is None:
            raise ValueError("Timestamps require an explicit timezone")
        fetched, server_date = fetched.tz_convert("UTC"), server_date.tz_convert("UTC")
    except (KeyError, ValueError, TypeError, OverflowError) as error:
        raise ValueError(
            "Invalid current Spot snapshot retrieval/HTTP timestamps"
        ) from error
    if (
        fetched.strftime("%Y-%m-%d") != as_of
        or server_date.strftime("%Y-%m-%d") != as_of
        or abs(fetched - server_date) > pd.Timedelta(minutes=5)
    ):
        raise ValueError(
            "Stale current Spot snapshot: retrieval and HTTP date must match as-of"
        )
    rows = document.get("exchange_info", {}).get("symbols")
    if not isinstance(rows, list) or not rows:
        raise ValueError("Current Spot snapshot has no symbol evidence")
    symbols: set[str] = set()
    tradable: set[str] = set()
    for row in rows:
        if not isinstance(row, dict):
            raise ValueError("Malformed current Spot symbol evidence")
        symbol = row.get("symbol")
        if not isinstance(symbol, str) or not symbol.isalnum() or symbol in symbols:
            raise ValueError("Malformed or duplicate current Spot symbol")
        symbols.add(symbol)
        present = row.get("present_in_response")
        if type(present) is not bool:
            raise ValueError(
                "Current Spot evidence requires present_in_response boolean"
            )
        if not present:
            continue
        if (
            not isinstance(row.get("status"), str)
            or not isinstance(row.get("quoteAsset"), str)
            or type(row.get("isSpotTradingAllowed")) is not bool
        ):
            raise ValueError(
                "Current Spot evidence requires status, quote and Spot permission"
            )
        if (
            row["status"] == "TRADING"
            and row["quoteAsset"] == "USDT"
            and row["isSpotTradingAllowed"]
        ):
            tradable.add(symbol)
    symbol_digest = hashlib.sha256(
        json.dumps(sorted(symbols), separators=(",", ":")).encode("utf-8")
    ).hexdigest()
    if document.get("ranked_symbols_sha256") != symbol_digest:
        raise ValueError("Current Spot snapshot projected symbol fingerprint mismatch")
    return tradable, {
        "path": path.relative_to(root.resolve()).as_posix(),
        "sha256": sha256_file(path),
        "as_of": as_of,
        "source_url": EXCHANGE_INFO_URL,
        "fetched_at_utc": fetched.isoformat(),
        "http_date": document["http_date"],
        "raw_response_sha256": raw_digest,
        "ranked_symbols_sha256": symbol_digest,
    }


def _utc(value: Any) -> pd.Timestamp:
    value = pd.Timestamp(value)
    return value.tz_localize("UTC") if value.tz is None else value.tz_convert("UTC")


def _write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(value, indent=2, ensure_ascii=False, default=str) + "\n",
        encoding="utf-8",
    )
    temporary.replace(path)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def verify_checksum(path: Path, checksum_text: str) -> str:
    """Reject malformed hashes and mismatches before any archive is parsed."""
    fields = checksum_text.strip().split()
    if (
        not fields
        or len(fields[0]) != 64
        or any(c not in "0123456789abcdefABCDEF" for c in fields[0])
    ):
        raise ValueError(f"Invalid SHA256 checksum for {path.name}")
    actual = sha256_file(path)
    if actual != fields[0].lower():
        raise ValueError(f"SHA256 mismatch for {path.name}")
    return actual


def _get(url: str, **kwargs: Any) -> requests.Response:
    for attempt in range(4):
        try:
            response = requests.get(url, timeout=(15, 90), **kwargs)
            if response.status_code == 404:
                return response
            response.raise_for_status()
            return response
        except requests.RequestException:
            if attempt == 3:
                raise
            time.sleep(2**attempt)
    raise RuntimeError("Unreachable")


def discover_archive_symbols() -> list[str]:
    """List all historical archive prefixes, including delisted symbols."""
    namespace = {"s3": "http://s3.amazonaws.com/doc/2006-03-01/"}
    marker = ""
    symbols: set[str] = set()
    while True:
        response = _get(
            LIST_URL, params={"delimiter": "/", "prefix": PREFIX, "marker": marker}
        )
        document = ET.fromstring(response.content)
        for item in document.findall("s3:CommonPrefixes/s3:Prefix", namespace):
            symbol = str(item.text).removeprefix(PREFIX).rstrip("/")
            if symbol.endswith("USDT"):
                symbols.add(symbol)
        if (
            document.findtext("s3:IsTruncated", default="false", namespaces=namespace)
            != "true"
        ):
            break
        next_marker = document.findtext("s3:NextMarker", namespaces=namespace)
        if not next_marker or next_marker == marker:
            raise ValueError("Truncated archive listing has no next marker")
        marker = next_marker
    return sorted(symbols)


def exclusion_reason(symbol: str) -> str | None:
    if not symbol.endswith("USDT"):
        return "non_usdt_quote"
    base = symbol[:-4]
    if base == "BTC":
        return "bitcoin_external_factor"
    if base in STABLECOINS:
        return "stablecoin"
    if base in FIAT:
        return "fiat"
    if any(
        base == name + suffix
        for name in LEVERAGED_BASES
        for suffix in ("UP", "DOWN", "BULL", "BEAR")
    ):
        return "leveraged_token"
    return None


def archive_key(symbol: str, interval: str, month: str) -> str:
    if not symbol.isalnum() or interval not in {"5m", "1d"}:
        raise ValueError("Unsupported symbol or interval")
    pd.Period(month, freq="M")
    return f"{PREFIX}{symbol}/{interval}/{symbol}-{interval}-{month}.zip"


def fetch_archive(
    symbol: str, interval: str, month: str, root: Path
) -> tuple[Path | None, dict[str, Any]]:
    """Fetch immutable local bytes; existing bytes must match their saved hash."""
    key = archive_key(symbol, interval, month)
    path = root / "data" / "raw" / key
    checksum_path = path.with_suffix(".zip.CHECKSUM")
    record: dict[str, Any] = {
        "symbol": symbol,
        "interval": interval,
        "month": month,
        "url": ARCHIVE_URL + key,
    }
    if path.exists():
        if not checksum_path.exists():
            raise ValueError(f"Existing raw archive without checksum: {path}")
        digest = verify_checksum(path, checksum_path.read_text(encoding="utf-8"))
    else:
        checksum = _get(ARCHIVE_URL + key + ".CHECKSUM")
        if checksum.status_code == 404:
            record.update(status="unavailable", reason="checksum_http_404")
            return None, record
        response = _get(ARCHIVE_URL + key)
        if response.status_code == 404:
            record.update(status="unavailable", reason="archive_http_404")
            return None, record
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_suffix(".zip.part")
        temporary.write_bytes(response.content)
        digest = verify_checksum(temporary, checksum.text)
        temporary.replace(path)
        checksum_path.write_text(checksum.text, encoding="utf-8")
    record.update(
        status="verified",
        sha256=digest,
        bytes=path.stat().st_size,
        local_path=path.relative_to(root).as_posix(),
    )
    return path, record


def read_archive(path: Path) -> pd.DataFrame:
    with zipfile.ZipFile(path) as archive:
        files = [name for name in archive.namelist() if name.lower().endswith(".csv")]
        if len(files) != 1:
            raise ValueError(f"Expected one CSV in {path.name}")
        raw = pd.read_csv(io.BytesIO(archive.read(files[0])), header=None)
    if raw.shape[1] != len(KLINE_COLUMNS):
        raise ValueError(f"Unexpected kline width in {path.name}: {raw.shape[1]}")
    raw.columns = KLINE_COLUMNS
    # Some archive families include a header; only its explicit first cell is allowed.
    if len(raw) and str(raw.iloc[0, 0]).lower() in {"open_time", "open time"}:
        raw = raw.iloc[1:].reset_index(drop=True)
    return raw


def normalize_klines(
    rawframe: pd.DataFrame, frequency: str = "5min", start: Any = None, end: Any = None
) -> pd.DataFrame:
    """Validate raw candles and retain the complete UTC grid [start, end).

    Invalid OHLC/volume candles are quarantined (numeric fields set to NaN).
    Missing rows and invalid rows both break the log-return sequence. Duplicate
    or off-grid timestamps raise rather than choosing an arbitrary price.
    """
    frequency = _canonical_frequency(frequency)
    step = pd.Timedelta(days=1) if frequency == "1d" else pd.Timedelta(minutes=5)
    grid_frequency = "1D" if frequency == "1d" else frequency
    frame = rawframe.copy()
    if len(frame.columns) == 12 and "open_time" not in frame:
        frame.columns = KLINE_COLUMNS
    if not len(frame):
        frame = pd.DataFrame(columns=KLINE_COLUMNS)
    for name in KLINE_COLUMNS:
        if name not in frame:
            raise ValueError(f"Missing Binance column {name}")
    numeric_time = pd.to_numeric(frame["open_time"], errors="raise")
    # Historical study data uses ms; supporting us prevents silent year errors.
    unit = "us" if len(numeric_time) and numeric_time.abs().max() > 10**14 else "ms"
    index = pd.DatetimeIndex(
        pd.to_datetime(numeric_time, unit=unit, utc=True), name="open_time"
    )
    if index.has_duplicates:
        raise ValueError("Duplicate candle open timestamps")
    if index.hasnans or (len(index) and (index != index.floor(grid_frequency)).any()):
        raise ValueError("Missing or off-grid candle open timestamps")
    frame.index = index
    frame = frame.sort_index()
    frame["close_time"] = pd.to_datetime(
        pd.to_numeric(frame["close_time"], errors="raise"), unit=unit, utc=True
    )
    for name in NUMERIC_COLUMNS:
        frame[name] = pd.to_numeric(frame[name], errors="coerce")
    bad_time = (
        frame["close_time"].isna()
        | (frame["close_time"] < frame.index)
        | (frame["close_time"] >= frame.index + step)
    )
    if bad_time.any():
        raise ValueError("Close time outside candle interval")
    values = frame[NUMERIC_COLUMNS]
    valid = np.isfinite(values).all(axis=1)
    valid &= (frame[["open", "high", "low", "close"]] > 0).all(axis=1)
    valid &= (
        frame[
            [
                "volume",
                "quote_volume",
                "trade_count",
                "taker_buy_base_volume",
                "taker_buy_quote_volume",
            ]
        ]
        >= 0
    ).all(axis=1)
    valid &= frame["high"].ge(frame[["open", "low", "close"]].max(axis=1))
    valid &= frame["low"].le(frame[["open", "high", "close"]].min(axis=1))
    frame["invalid_candle"] = ~valid
    frame.loc[~valid, NUMERIC_COLUMNS] = np.nan
    frame["observed"] = True
    if start is None:
        if not len(frame):
            raise ValueError("Empty data requires explicit start and end")
        start = frame.index.min()
    if end is None:
        if not len(frame):
            raise ValueError("Empty data requires explicit start and end")
        end = frame.index.max() + step
    start, end = _utc(start), _utc(end)
    if (
        start >= end
        or start != start.floor(grid_frequency)
        or end != end.floor(grid_frequency)
    ):
        raise ValueError("Bounds must be ordered and aligned to candle grid")
    grid = pd.date_range(
        start, end, freq=grid_frequency, inclusive="left", name="open_time"
    )
    frame = frame.reindex(grid)
    frame["observed"] = frame["observed"].eq(True)
    frame["invalid_candle"] = frame["invalid_candle"].eq(True)
    frame["missing_candle"] = ~frame["observed"]
    frame["valid_candle"] = frame["observed"] & ~frame["invalid_candle"]
    frame["available_at"] = frame.index + step
    frame["log_return"] = np.log(frame["close"]).diff()
    frame["zero_volume"] = frame["volume"].eq(0) & frame["valid_candle"]
    return frame.drop(columns=["open_time", "ignore"], errors="ignore")


def universe_metrics(symbol: str, frame: pd.DataFrame) -> dict[str, Any]:
    """Selection statistics use exactly Jan 1--30, regardless of input extent."""
    sample = frame.loc[(frame.index >= SELECTION_START) & (frame.index < SELECTION_END)]
    grid = pd.date_range(SELECTION_START, SELECTION_END, freq="5min", inclusive="left")
    sample = sample.reindex(grid)
    coverage = float(sample["valid_candle"].eq(True).sum() / len(grid))
    daily = sample["quote_volume"].resample("1D").sum(min_count=1)
    return {
        "symbol": symbol,
        "coverage": coverage,
        "median_daily_quote_volume": float(daily.median()),
        "return_std": float(np.log(sample["close"]).diff().std(ddof=1)),
        "selection_start": SELECTION_START.isoformat(),
        "selection_end_exclusive": SELECTION_END.isoformat(),
    }


def select_universe(
    metrics: pd.DataFrame, *, current_spot_symbols: set[str] | None = None
) -> pd.DataFrame:
    """Pick six assets, computing the median after the optional v2 listing filter.

    Omitting the filter preserves v1's historical-universe selection. Callers
    using v2 must obtain the set from ``load_current_spot_snapshot``.
    """
    eligible = metrics.loc[metrics["coverage"].ge(0.99)].copy()
    eligible = eligible.loc[eligible["symbol"].map(exclusion_reason).isna()]
    eligible = eligible.replace([np.inf, -np.inf], np.nan).dropna(
        subset=["median_daily_quote_volume", "return_std"]
    )
    if eligible["symbol"].duplicated().any():
        raise ValueError("Duplicate universe symbols")
    if current_spot_symbols is not None:
        eligible = eligible.loc[eligible["symbol"].isin(current_spot_symbols)]
    if len(eligible) < 6:
        raise ValueError("At least six eligible historical assets are required")
    median = float(eligible["median_daily_quote_volume"].median())
    high = (
        eligible.sort_values(
            ["median_daily_quote_volume", "symbol"], ascending=[False, True]
        )
        .head(2)
        .assign(family="high_liquidity")
    )
    remaining = eligible.loc[~eligible["symbol"].isin(high["symbol"])].copy()
    remaining["distance_to_median"] = (
        remaining["median_daily_quote_volume"] - median
    ).abs()
    middle = (
        remaining.sort_values(["distance_to_median", "symbol"])
        .head(2)
        .assign(family="medium_liquidity")
    )
    remaining = remaining.loc[
        ~remaining["symbol"].isin(middle["symbol"])
        & remaining["median_daily_quote_volume"].ge(median)
    ]
    volatile = (
        remaining.sort_values(["return_std", "symbol"], ascending=[False, True])
        .head(2)
        .assign(family="high_volatility")
    )
    result = pd.concat([high, middle, volatile], ignore_index=True)
    if len(result) != 6:
        raise ValueError(
            "Cannot pick two liquid high-volatility assets after prior groups"
        )
    result["universe_median_daily_quote_volume"] = median
    return result.drop(columns="distance_to_median", errors="ignore")


def _download_many(
    jobs: list[tuple[str, str, str]], root: Path, workers: int
) -> list[tuple[Path | None, dict[str, Any]]]:
    result = []
    with ThreadPoolExecutor(max_workers=workers) as executor:
        futures = {executor.submit(fetch_archive, *job, root): job for job in jobs}
        for number, future in enumerate(as_completed(futures), 1):
            result.append(future.result())
            if number % 25 == 0 or number == len(jobs):
                print(f"Verified/downloaded {number}/{len(jobs)} archives", flush=True)
    return sorted(
        result,
        key=lambda item: (item[1]["symbol"], item[1]["interval"], item[1]["month"]),
    )


def prepare_study(root: Path | str | None = None, workers: int = 12) -> dict[str, Any]:
    """Select with versioned January/listing rules; cache 2022--2023 for reuse."""
    root = Path(root) if root is not None else DEFAULT_ROOT
    contract_hash = validate_data_contract(root)
    with (root / "protocol.toml").open("rb") as stream:
        protocol = tomllib.load(stream)
    current_symbols = None
    listing_evidence = None
    if protocol["selection"]["future_listing_survival_filter"]:
        current_symbols, listing_evidence = load_current_spot_snapshot(
            root, protocol=protocol
        )
    artifacts = root / "artifacts"
    frozen_selection = artifacts / "selection.json"
    if frozen_selection.exists():
        frozen_hash = json.loads(frozen_selection.read_text(encoding="utf-8")).get(
            "data_contract_sha256"
        )
        if frozen_hash != contract_hash:
            raise ValueError(
                "Frozen universe data contract mismatch; create a new dataset version before preparation"
            )
    artifacts.mkdir(parents=True, exist_ok=True)
    snapshot_path = artifacts / "universe_archive_snapshot.json"
    if snapshot_path.exists():
        symbols = json.loads(snapshot_path.read_text(encoding="utf-8"))["symbols"]
    else:
        symbols = discover_archive_symbols()
        _write_json(
            snapshot_path,
            {
                "source": LIST_URL,
                "prefix": PREFIX,
                "retrieved_at": pd.Timestamp.now(tz="UTC").isoformat(),
                "symbols": symbols,
                "note": "Historical archive prefixes, not today's active exchangeInfo. January availability and coverage determine eligibility.",
            },
        )
    audit = [
        {"symbol": symbol, "reason": exclusion_reason(symbol) or "candidate"}
        for symbol in symbols
    ]
    candidates = [row["symbol"] for row in audit if row["reason"] == "candidate"]
    print(
        f"Historical archive discovery: {len(symbols)} USDT symbols; {len(candidates)} January candidates",
        flush=True,
    )
    initial = _download_many(
        [(symbol, "5m", "2022-01") for symbol in candidates], root, workers
    )
    records = [record for _, record in initial]
    metrics = []
    for path, record in initial:
        if path is not None:
            frame = normalize_klines(
                read_archive(path), start=SELECTION_START, end=SELECTION_END
            )
            metrics.append(universe_metrics(record["symbol"], frame))
    ranking = pd.DataFrame(metrics).sort_values(
        ["median_daily_quote_volume", "symbol"], ascending=[False, True]
    )
    ranking["eligible"] = ranking["coverage"].ge(0.99)
    if listing_evidence is not None:
        ranked_digest = hashlib.sha256(
            json.dumps(sorted(ranking["symbol"]), separators=(",", ":")).encode("utf-8")
        ).hexdigest()
        if ranked_digest != listing_evidence["ranked_symbols_sha256"]:
            raise ValueError(
                "Current Spot snapshot does not cover the historical ranked candidates"
            )
        ranking["historically_eligible"] = ranking["eligible"]
        ranking["current_spot_tradable"] = ranking["symbol"].isin(current_symbols)
        ranking["eligible"] &= ranking["current_spot_tradable"]
    ranking.to_csv(artifacts / "universe_ranked.csv", index=False)
    ranked_lookup = ranking.set_index("symbol")
    for row in audit:
        if row["reason"] == "candidate":
            if row["symbol"] not in ranked_lookup.index:
                row["reason"] = "no_january_2022_archive"
            else:
                row["coverage"] = float(ranked_lookup.loc[row["symbol"], "coverage"])
                row["reason"] = (
                    "eligible" if row["coverage"] >= 0.99 else "coverage_below_99pct"
                )
                if (
                    row["reason"] == "eligible"
                    and current_symbols is not None
                    and row["symbol"] not in current_symbols
                ):
                    row["reason"] = "not_current_spot_tradable"
    pd.DataFrame(audit).to_csv(artifacts / "universe_audit.csv", index=False)
    selected = select_universe(ranking, current_spot_symbols=current_symbols)
    selection = {
        "data_contract_sha256": contract_hash,
        "selection_start": SELECTION_START.isoformat(),
        "selection_end_exclusive": SELECTION_END.isoformat(),
        "minimum_coverage": 0.99,
        "expected_candles": 8640,
        "tie_break": "symbol ascending",
        "selected": selected.to_dict(orient="records"),
        "symbols": selected["symbol"].tolist(),
        "exclusions": {
            "stablecoins": sorted(STABLECOINS),
            "fiat": sorted(FIAT),
            "leveraged_bases": sorted(LEVERAGED_BASES),
            "leveraged_suffixes": ["UP", "DOWN", "BULL", "BEAR"],
            "external_factor": "BTCUSDT",
        },
        "source_documentation": "https://github.com/binance/binance-public-data",
    }
    if listing_evidence is not None:
        selection["protocol_version"] = protocol["study"]["version"]
        selection["future_listing_survival_filter"] = True
        selection["current_spot_snapshot"] = listing_evidence
    selection_path = artifacts / "selection.json"
    if selection_path.exists():
        previous = json.loads(selection_path.read_text(encoding="utf-8"))
        if (
            previous.get("data_contract_sha256") == contract_hash
            and previous.get("protocol_version") in {"2.0.0", "2.1.0"}
            and protocol["study"]["version"] in {"2.0.0", "2.1.0"}
        ):
            # The version records when selection was frozen, not the latest
            # analysis settings used with those same immutable input data.
            selection["protocol_version"] = previous["protocol_version"]
        if previous != selection:
            raise ValueError(
                "Universe changed; create a new study version rather than overwrite selection"
            )
    else:
        _write_json(selection_path, selection)
    print("Selected historical assets: " + ", ".join(selection["symbols"]), flush=True)
    months = pd.period_range("2022-01", "2023-12", freq="M").astype(str)
    daily_months = pd.period_range(
        DAILY_START.strftime("%Y-%m"), "2023-12", freq="M"
    ).astype(str)
    jobs = [
        (symbol, "5m", month)
        for symbol in selection["symbols"] + ["BTCUSDT"]
        for month in months
    ]
    jobs += [("BTCUSDT", "1d", month) for month in daily_months]
    downloaded = _download_many(jobs, root, workers)
    records.extend(record for _, record in downloaded)
    unique = {
        (record["symbol"], record["interval"], record["month"]): record
        for record in records
    }
    _write_json(
        artifacts / "download_manifest.json",
        {
            "dataset_version": (
                "alpha-study-2022-2023-v2"
                if listing_evidence is not None
                else "alpha-study-2022-2023-v1"
            ),
            "data_contract_sha256": contract_hash,
            **(
                {"current_spot_snapshot": listing_evidence}
                if listing_evidence is not None
                else {}
            ),
            "normalization_version": 1,
            "timestamp_semantics": "index=open UTC; available_at=open+interval; close_time=source inclusive close",
            "records": [unique[key] for key in sorted(unique)],
        },
    )
    normalized = root / "data" / "normalized"
    normalized.mkdir(parents=True, exist_ok=True)
    quality = []
    normalized_manifest = []
    groups = [
        (symbol, "5m", "5min", SELECTION_START)
        for symbol in selection["symbols"] + ["BTCUSDT"]
    ]
    groups += [("BTCUSDT", "1d", "1d", DAILY_START)]
    for symbol, interval, frequency, start in groups:
        files = [
            path
            for path, record in downloaded
            if path and record["symbol"] == symbol and record["interval"] == interval
        ]
        raw = (
            pd.concat([read_archive(path) for path in files], ignore_index=True)
            if files
            else pd.DataFrame(columns=KLINE_COLUMNS)
        )
        frame = normalize_klines(raw, frequency=frequency, start=start, end=STUDY_END)
        output = normalized / f"{symbol}-{frequency}.parquet"
        frame.to_parquet(output, index=True)
        normalized_manifest.append(
            {
                "symbol": symbol,
                "frequency": frequency,
                "rows": len(frame),
                "path": output.relative_to(root).as_posix(),
                "sha256": sha256_file(output),
            }
        )
        # Quality counts may cover the holdout; price/return summaries may not.
        for month, part in frame.groupby(frame.index.strftime("%Y-%m")):
            quality.append(
                {
                    "symbol": symbol,
                    "frequency": frequency,
                    "month": month,
                    "expected": len(part),
                    "observed": int(part["observed"].sum()),
                    "valid": int(part["valid_candle"].sum()),
                    "missing": int(part["missing_candle"].sum()),
                    "invalid": int(part["invalid_candle"].sum()),
                    "zero_volume": int(part["zero_volume"].sum()),
                }
            )
        print(
            f"Normalized {symbol} {frequency}: {len(frame):,} rows, {int(frame['missing_candle'].sum())} missing",
            flush=True,
        )
    pd.DataFrame(quality).to_csv(artifacts / "data_quality.csv", index=False)
    _write_json(
        artifacts / "normalized_manifest.json",
        {
            "data_contract_sha256": contract_hash,
            **(
                {"current_spot_snapshot": listing_evidence}
                if listing_evidence is not None
                else {}
            ),
            "files": normalized_manifest,
        },
    )
    return selection


def load_market(
    symbol: str,
    root: Path | str | None = None,
    development_only: bool = True,
    frequency: str = "5min",
) -> pd.DataFrame:
    """Verify cache/protocol provenance, then load development-only by default."""
    if not symbol.isalnum():
        raise ValueError("Unsupported symbol")
    frequency = _canonical_frequency(frequency)
    root = Path(root) if root is not None else DEFAULT_ROOT
    contract_hash = validate_data_contract(root)
    path = root / "data" / "normalized" / f"{symbol}-{frequency}.parquet"
    if not path.exists():
        raise FileNotFoundError(
            f"Missing study cache: {path}. Run python -m research.src.alpha_study.data prepare"
        )
    manifest_path = root / "artifacts" / "normalized_manifest.json"
    if not manifest_path.exists():
        raise FileNotFoundError(
            f"Missing normalized manifest: {manifest_path}. Regenerate the cache with data prepare; preserve selection.json"
        )
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if manifest.get("data_contract_sha256") != contract_hash:
        raise ValueError(
            "Normalized manifest data contract mismatch. Regenerate this dataset version with data prepare; preserve the frozen selection.json"
        )
    records = [
        record
        for record in manifest.get("files", [])
        if record.get("symbol") == symbol and record.get("frequency") == frequency
    ]
    if len(records) != 1 or records[0].get("path") != path.relative_to(root).as_posix():
        raise ValueError(
            f"Missing or ambiguous manifest entry for {symbol} {frequency}; regenerate the cache with data prepare"
        )
    try:
        verify_checksum(path, records[0].get("sha256", ""))
    except ValueError as error:
        raise ValueError(
            f"Normalized cache integrity failure for {path.name}: {error}. Regenerate the cache with data prepare; preserve selection.json"
        ) from error
    frame = pd.read_parquet(path)
    if development_only:
        frame = frame.loc[frame.index < DEVELOPMENT_END]
    return frame


def prepare_analysis_frame(
    frame: pd.DataFrame, *, missing_candles: str = "linear_ohlcv_flagged"
) -> pd.DataFrame:
    """Derive flagged interpolation without modifying raw data or source flags.

    Only entirely missing internal runs bounded by two genuine valid candles
    are interpolated. Invalid candles and leading/trailing gaps stay missing.
    All OHLC, volume and count columns use the same time weights; an interpolated
    trade count is a synthetic numeric value, not a recorded exchange count.

    ``available_at`` remains the nominal candle close. ``data_available_at`` is
    the actual earliest availability of derived values: for an interpolated row
    it is the right boundary's close. ``return_available_at`` also accounts for
    the preceding candle. Use the availability masks below for model inputs and
    labels; interpolation is retrospective and must not create future knowledge.
    Source ``valid_candle``, ``observed``, ``missing_candle``, ``invalid_candle``,
    ``zero_volume`` and ``close_time`` are preserved. Analytical consumers use
    ``analysis_valid_candle`` and ``analysis_zero_volume`` instead.
    """
    if missing_candles != "linear_ohlcv_flagged":
        raise ValueError("Unsupported analysis missing-candle policy")
    required = set(NUMERIC_COLUMNS) | {
        "available_at",
        "observed",
        "missing_candle",
        "invalid_candle",
        "valid_candle",
        "zero_volume",
        "close_time",
    }
    if missing := required - set(frame):
        raise ValueError(f"Missing source candle columns: {sorted(missing)}")
    _validate_analysis_grid(frame)
    if "is_interpolated" in frame and frame["is_interpolated"].any():
        raise ValueError("Prepare analysis from raw candles, not an interpolated frame")
    result = frame.copy(deep=True)
    result["source_missing_candle"] = result["missing_candle"].eq(True)
    result["is_observed"] = result["observed"].eq(True)
    result["is_interpolated"] = False
    source_valid = (
        result["valid_candle"].eq(True)
        & result["is_observed"]
        & ~result["source_missing_candle"]
        & ~result["invalid_candle"].eq(True)
    )
    result["analysis_valid_candle"] = source_valid
    result["data_available_at"] = pd.to_datetime(
        result["available_at"], utc=True
    ).where(source_valid)
    missing_rows = result["source_missing_candle"] & ~result["invalid_candle"].eq(True)
    edges = np.diff(np.r_[False, missing_rows.to_numpy(), False].astype(int))
    starts, stops = np.flatnonzero(edges == 1), np.flatnonzero(edges == -1)
    numeric_positions = result.columns.get_indexer(NUMERIC_COLUMNS)
    for start, stop in zip(starts, stops, strict=True):
        left, right = start - 1, stop
        if (
            left < 0
            or right >= len(result)
            or not (source_valid.iloc[left] and source_valid.iloc[right])
        ):
            continue
        boundaries = result.iloc[[left, right]][NUMERIC_COLUMNS].to_numpy(dtype=float)
        if not np.isfinite(boundaries).all():
            continue
        weights = np.asarray(
            (result.index[start:stop] - result.index[left])
            / (result.index[right] - result.index[left]),
            dtype=float,
        )
        result.iloc[start:stop, numeric_positions] = (
            1 - weights[:, None]
        ) * boundaries[0] + weights[:, None] * boundaries[1]
        result.iloc[start:stop, result.columns.get_loc("is_interpolated")] = True
        result.iloc[start:stop, result.columns.get_loc("analysis_valid_candle")] = True
        result.iloc[start:stop, result.columns.get_loc("data_available_at")] = result[
            "available_at"
        ].iloc[right]
    prices = result["close"].where(result["analysis_valid_candle"])
    result["log_return"] = np.log(prices).diff()
    previous_availability = result["data_available_at"].shift(1)
    result["return_available_at"] = (
        result["data_available_at"]
        .where(
            result["data_available_at"].ge(previous_availability), previous_availability
        )
        .where(result["log_return"].notna())
    )
    result["return_is_interpolated"] = (
        result["is_interpolated"] | result["is_interpolated"].shift(1, fill_value=False)
    ) & result["log_return"].notna()
    result["analysis_zero_volume"] = (
        result["volume"].eq(0) & result["analysis_valid_candle"]
    )
    return result


def _validate_analysis_grid(frame: pd.DataFrame) -> None:
    if (
        not isinstance(frame.index, pd.DatetimeIndex)
        or frame.index.tz is None
        or not frame.index.is_unique
        or not frame.index.is_monotonic_increasing
    ):
        raise ValueError(
            "Analysis requires ordered unique timezone-aware candle timestamps"
        )
    if not len(frame):
        return
    nominal = pd.DatetimeIndex(pd.to_datetime(frame["available_at"], utc=True))
    durations = nominal - frame.index
    step = durations[0]
    if step <= pd.Timedelta(0) or not (durations == step).all():
        raise ValueError("Analysis requires a constant positive candle duration")
    if not frame.index.equals(
        pd.date_range(frame.index[0], periods=len(frame), freq=step)
    ):
        raise ValueError(
            "Analysis requires the complete calendar grid; retain missing rows"
        )


def analysis_available_mask(frame: pd.DataFrame, as_of: Any) -> pd.Series:
    """Mark rows whose candle and return are known by a scalar or per-row cutoff.

    For an online decision at each candle's nominal close, pass
    ``frame.available_at``. Missing values cannot become usable retroactively at
    those decision times. Multi-lag features must also check all contributing
    rows; this helper only attests the current candle and its one-step return.
    """
    required = {
        "analysis_valid_candle",
        "data_available_at",
        "return_available_at",
        "log_return",
    }
    if not required <= set(frame):
        raise ValueError("Availability checks require prepare_analysis_frame output")
    if isinstance(as_of, pd.Series):
        if not as_of.index.equals(frame.index):
            raise ValueError("Per-row availability cutoff must share the candle index")
        cutoff = pd.to_datetime(as_of, utc=True)
    else:
        cutoff = _utc(as_of)
    return (
        frame["analysis_valid_candle"]
        & np.isfinite(frame["log_return"])
        & frame["data_available_at"].le(cutoff)
        & frame["return_available_at"].le(cutoff)
    ).rename("analysis_available")


def analysis_training_mask(frame: pd.DataFrame, start: Any, end: Any) -> pd.Series:
    """Mask source rows and next-return labels known within [start, end).

    A source candle and its return must be known at that row's historical
    forecast origin (its nominal candle close), as well as by the training
    cutoff. Its next-return label must be known by the training cutoff.
    Nominal target-close bounds preserve the existing one-bar label convention.
    Interpolated source rows therefore cannot become eligible retroactively,
    even when their right boundary is already known by the training cutoff.
    This mask governs model inputs and training labels, not execution prices.
    The separately configured simulation may use a flagged synthetic price
    path for fills; that permission never makes future values valid features.
    """
    _validate_analysis_grid(frame)
    left, right = _utc(start), _utc(end)
    if left >= right:
        raise ValueError("Training bounds must form a nonempty interval")
    source_available = analysis_available_mask(
        frame, frame["available_at"]
    ) & analysis_available_mask(frame, right)
    target_available = (
        frame["return_available_at"].shift(-1).le(right)
        & frame["available_at"].shift(-1).le(right)
        & np.isfinite(frame["log_return"].shift(-1))
    )
    return ((frame.index >= left) & source_available & target_available).rename(
        "analysis_label_in_window"
    )


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=["prepare", "status"])
    parser.add_argument("--root", type=Path, default=DEFAULT_ROOT)
    parser.add_argument("--workers", type=int, default=12)
    args = parser.parse_args()
    if args.command == "prepare":
        prepare_study(args.root, args.workers)
    else:
        print((args.root / "artifacts" / "selection.json").read_text(encoding="utf-8"))
        print(
            pd.read_csv(args.root / "artifacts" / "data_quality.csv")
            .groupby(["symbol", "frequency"])[["expected", "missing", "invalid"]]
            .sum()
            .to_string()
        )


if __name__ == "__main__":
    main()
