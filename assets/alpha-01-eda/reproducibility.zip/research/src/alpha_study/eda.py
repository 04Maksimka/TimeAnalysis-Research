"""Development-only EDA helpers; no fitting of alpha models or final-set access."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd

from .data import DEFAULT_ROOT, load_market
from .protocol import StudyConfig, load_config, make_windows
from .statistics import adjust_pvalues, stationarity_tests


def load_development(
    root: str | Path = DEFAULT_ROOT,
) -> tuple[dict, dict[str, pd.DataFrame]]:
    """Load selected assets plus BTC, with an explicit final-period guard."""
    root = Path(root)
    selection = json.loads((root / "artifacts/selection.json").read_text("utf-8"))
    config = load_config(root / "protocol.toml")
    markets = {
        symbol: load_market(symbol, root=root, development_only=True)
        for symbol in [*selection["symbols"], "BTCUSDT"]
    }
    for symbol, frame in markets.items():
        if not frame.index.is_unique or not frame.index.is_monotonic_increasing:
            raise ValueError(f"{symbol}: unordered/duplicate time index")
        if len(frame) and frame.index.max() >= config.final_start:
            raise ValueError(f"{symbol}: final evaluation data entered EDA")
    return selection, markets


def describe_returns(markets: dict[str, pd.DataFrame]) -> pd.DataFrame:
    """Descriptive statistics only: no IID standard errors or Gaussian claims."""
    records = []
    for symbol, frame in markets.items():
        values = frame.log_return
        records.append(
            {
                "symbol": symbol,
                "valid_returns": int(values.count()),
                "mean": values.mean(),
                "std": values.std(),
                "median": values.median(),
                "q01": values.quantile(0.01),
                "q99": values.quantile(0.99),
                "min": values.min(),
                "max": values.max(),
                "skew": values.skew(),
                "excess_kurtosis": values.kurt(),
                "zero_return_fraction": values.eq(0).sum() / max(values.count(), 1),
            }
        )
    return pd.DataFrame(records).set_index("symbol")


def daily_log_returns(markets: dict[str, pd.DataFrame]) -> pd.DataFrame:
    """Sum a complete day of 288 nonmissing adjacent-candle return values.

    Input may be raw or an explicitly derived analysis layer. Derived values
    can include flagged interpolation; completeness does not mean all values
    were observed trades or available online at their nominal candle times.
    Callers retain/report interpolation flags and apply availability cutoffs
    when using this retrospective aggregate in an online setting.
    """
    series = {}
    for symbol, frame in markets.items():
        values = frame.log_return.resample("1D")
        series[symbol] = values.sum(min_count=288).where(values.count().eq(288))
    return pd.DataFrame(series)


def longest_complete_daily_frame(frame: pd.DataFrame) -> pd.DataFrame:
    """Select one explicit contiguous segment; never compress missing days."""
    if frame.empty or frame.index.tz is None:
        raise ValueError("Expected a nonempty timezone-aware daily frame")
    expected = pd.date_range(frame.index.min(), frame.index.max(), freq="1D")
    if not frame.index.equals(expected):
        raise ValueError("Daily frame must retain its complete calendar grid")
    valid = np.isfinite(frame.to_numpy(dtype=float)).all(axis=1)
    edges = np.diff(np.r_[False, valid, False].astype(int))
    starts, stops = np.flatnonzero(edges == 1), np.flatnonzero(edges == -1)
    if not len(starts):
        raise ValueError("No complete common daily segment")
    best = int(np.argmax(stops - starts))
    return frame.iloc[starts[best] : stops[best]].copy()


def market_regimes(
    daily_btc: pd.DataFrame, config: StudyConfig | None = None
) -> pd.DataFrame:
    """SMA regime, available only AFTER the daily candle used has closed.

    The output index is the availability day (the following UTC day), unlike
    input Binance candle-open timestamps. It is not an alpha feature.
    Configured periods affect the descriptive regime, not the training window.
    ``sma_fast``/``sma_slow`` are stable column names; legacy ``sma50`` and
    ``sma200`` aliases exist only when a configured average has that period.
    Pass an archived config explicitly when reproducing an older review.
    Only raw observed BTC daily inputs support this next-day timing rule.
    Interpolated daily values and values available after their nominal next
    midnight are rejected rather than assigned retrospective online labels.
    """
    config = config or load_config()
    settings = config.raw.get("regimes", {})
    fast_days = settings.get("fast_sma", 50)
    slow_days = settings.get("slow_sma", 200)
    transition_days = settings.get("transition_days", 14)
    if (
        any(
            not isinstance(value, int) or isinstance(value, bool) or value <= 0
            for value in (fast_days, slow_days, transition_days)
        )
        or fast_days >= slow_days
    ):
        raise ValueError("SMA periods must be positive integer days with fast < slow.")
    if not daily_btc.index.equals(
        pd.date_range(daily_btc.index.min(), daily_btc.index.max(), freq="1D")
    ):
        raise ValueError("BTC daily input must retain missing dates")
    if "is_interpolated" in daily_btc and daily_btc.is_interpolated.fillna(False).any():
        raise ValueError(
            "Market regimes require raw observed daily candles, not interpolation."
        )
    if (
        "data_available_at" in daily_btc
        and daily_btc.data_available_at.gt(daily_btc.index + pd.Timedelta(days=1)).any()
    ):
        raise ValueError(
            "Daily values available after nominal close cannot label earlier regimes."
        )
    valid_candle = daily_btc.get("analysis_valid_candle", daily_btc.valid_candle)
    prices = daily_btc.close.where(valid_candle)
    fast, slow = prices.rolling(fast_days).mean(), prices.rolling(slow_days).mean()
    available = fast.notna() & slow.notna()
    side = pd.Series(np.sign(fast - slow), index=prices.index)
    crossing = available & available.shift(1, fill_value=False) & side.ne(side.shift(1))
    transition = crossing.rolling(transition_days, min_periods=1).max().astype(bool)
    regime = pd.Series("unknown", index=prices.index)
    regime.loc[available & side.gt(0)] = "bull"
    regime.loc[available & side.lt(0)] = "bear"
    regime.loc[available & transition] = "transition"
    result = pd.DataFrame(
        {"btc_close": prices, "sma_fast": fast, "sma_slow": slow, "regime": regime}
    )
    for period, values in ((fast_days, fast), (slow_days, slow)):
        if period in (50, 200):
            result[f"sma{period}"] = values
    result.index = result.index + pd.Timedelta(days=1)
    result.index.name = "available_day"
    return result


def representative_windows(config: StudyConfig | None = None) -> list:
    """First eligible weekly refit per month, development period only."""
    config = config or load_config()
    output, seen = [], set()
    for window in make_windows(config):
        month = window.refit_end.strftime("%Y-%m")
        if window.refit_end <= config.final_start and month not in seen:
            output.append(window)
            seen.add(month)
    return output


def stationarity_panel(
    markets: dict[str, pd.DataFrame], config: StudyConfig | None = None
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Test log-prices/returns on explicit contiguous segments of 30-day windows.

    This EDA sample uses the first refit per month; model-stage diagnostics must
    run at each actual fit. Raw local labels are diagnostic, not adjusted claims.
    """
    config = config or load_config()
    statistics_settings = config.raw.get("statistics", {})
    working_policy = statistics_settings.get("stationarity_working_policy", "strict")
    summaries, records = [], []
    from threadpoolctl import threadpool_limits

    with threadpool_limits(limits=1):
        for window in representative_windows(config):
            for symbol, frame in markets.items():
                part = frame.loc[
                    (frame.index >= window.refit_start)
                    & (frame.index < window.refit_end)
                ]
                valid_candle = part.get("analysis_valid_candle", part.valid_candle)
                for kind, series in (
                    ("log_price", np.log(part.close.where(valid_candle))),
                    ("log_return", part.log_return),
                ):
                    availability_column = (
                        "data_available_at"
                        if kind == "log_price"
                        else "return_available_at"
                    )
                    availability_excluded_nobs = 0
                    if availability_column in part:
                        available = part[availability_column].le(window.refit_end)
                        availability_excluded_nobs = int(
                            (series.notna() & ~available).sum()
                        )
                        # Preserve the regular calendar; never compress unavailable rows.
                        series = series.where(available)
                    report = stationarity_tests(
                        series,
                        expected_frequency=config.timeframe,
                        maxlag=statistics_settings.get("adf_maxlag", 24),
                        segment_policy="longest",
                        working_policy=working_policy,
                    )
                    classification = {
                        key: report[key]
                        for key in (
                            "diagnostic_status",
                            "working_status",
                            "working_flag",
                            "working_policy",
                        )
                    }
                    segment = report["segment"]
                    interpolation_column = (
                        "is_interpolated"
                        if kind == "log_price"
                        else "return_is_interpolated"
                    )
                    interpolated_nobs = 0
                    if (
                        interpolation_column in part
                        and segment["window_start"] is not None
                    ):
                        selected = part.loc[
                            segment["window_start"] : segment["window_end"]
                        ]
                        interpolated_nobs = int(
                            selected[interpolation_column].fillna(False).sum()
                        )
                    provenance = {
                        "interpolated_nobs": interpolated_nobs,
                        "availability_excluded_nobs": availability_excluded_nobs,
                    }
                    row = {
                        "symbol": symbol,
                        "series": kind,
                        "refit_at": window.refit_end,
                        "history_start": window.refit_start,
                        "status": report["status"],
                        **classification,
                        **provenance,
                        "segment": json.dumps(segment, default=str),
                    }
                    for test in report["tests"]:
                        row[test["test"].lower() + "_pvalue"] = test.get("pvalue")
                        records.append(
                            {
                                **test,
                                **classification,
                                **provenance,
                                "symbol": symbol,
                                "series": kind,
                                "refit_at": str(window.refit_end),
                                "family": "eda_stationarity_diagnostics",
                            }
                        )
                    summaries.append(row)
    corrected = adjust_pvalues(records, method="fdr_by")
    return pd.DataFrame(summaries), pd.DataFrame(corrected)


def lagged_btc_correlations(
    markets: dict[str, pd.DataFrame], max_lag: int = 12
) -> pd.DataFrame:
    """Retrospective corr(r_alt[t+1], r_BTC[t-k]) on the supplied UTC grid.

    For observed candles, BTC k=0 is known at signal close. A derived layer
    may contain interpolation that becomes available only at a later observed
    anchor. This descriptive helper does not filter return_available_at and
    must not be treated as an online feature-selection or availability check.
    """
    btc = markets["BTCUSDT"].log_return
    result = {}
    for symbol, frame in markets.items():
        if symbol == "BTCUSDT":
            continue
        target = frame.log_return.shift(-1)
        result[symbol] = [target.corr(btc.shift(lag)) for lag in range(max_lag + 1)]
    return pd.DataFrame(result, index=pd.Index(range(max_lag + 1), name="lag"))
