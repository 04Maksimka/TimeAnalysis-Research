"""Causal, single-asset long/cash execution used identically by every alpha.

This candle simulator is an explicit fill approximation. Versioned policies
can allow fills on zero-volume or interpolated candles, with their assumptions
recorded in outputs. The defaults block zero-volume fills and reject synthetic
paths. Missing OHLC while a position is held makes the path unscorable. There
is no order-book capacity, spread or queue model; sensitivity tests remain
necessary.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any

import numpy as np
import pandas as pd

from .statistics import _validate_index


class UnscorablePathError(ValueError):
    """Required prices or liquidity are unavailable for a held position."""


@dataclass
class SimulationResult:
    equity: pd.DataFrame
    trades: pd.DataFrame
    events: pd.DataFrame
    settings: dict[str, Any]


def simulate_long_cash(
    bars: pd.DataFrame,
    predictions: pd.Series,
    sigma_next: pd.Series,
    *,
    initial_cash: float = 1.0,
    fee: float = 0.001,
    slippage: float = 0.0005,
    stop_sigma: float = 2.0,
    take_sigma: float = 3.0,
    end_close: bool = True,
    zero_volume_execution: str = "no_fills_report_blocked_orders",
    interpolated_execution: str = "reject",
) -> SimulationResult:
    """Simulate one asset allocation, with no state reset at model refits.

    All inputs have the identical full 5-minute UTC index of candle *open*
    times. Prediction and sigma at row t are known only after close(t); their
    earliest action is open(t+5min). A finite positive forecast opens/holds long;
    nonpositive or unavailable forecasts exit on the next tradable open.

    Entry spends cash including fees at open*(1+slippage). Fixed SL/TP are
    entry_fill*exp(-2*sigma) and entry_fill*exp(3*sigma). Sell proceeds use
    reference_price*(1-slippage)*(1-fee). Resting bracket gaps execute first at
    open, then signal exits; intrabar checks use SL first if both touched. No
    same-candle reentry after an exit. Unavailable risk blocks new entries but
    does not replace an existing position's entry-time brackets.

    Equity is close-marked before hypothetical liquidation costs. end_close
    explicitly liquidates a remaining position at the last permitted close
    with costs, and raises if that candle cannot fill under the selected policy.
    Zero-volume fills require zero_volume_execution='allow_fills_report_assumption'.
    The same value for interpolated_execution permits bars marked by the boolean
    is_interpolated column; these are synthetic execution assumptions, not
    observed quotes. Trades retain this flag even if only an intermediate
    holding candle is synthetic. If data_available_at is supplied, the previous
    candle's prediction/risk cannot act before that timestamp. This also blocks
    predictions based on a future interpolation anchor.
    Do not call separately per weekly fold: pass the entire continuous path.
    """
    if not isinstance(bars, pd.DataFrame) or not len(bars):
        raise ValueError("bars must be a nonempty DataFrame.")
    required = ["open", "high", "low", "close", "volume"]
    if not set(required).issubset(bars.columns):
        raise ValueError(f"bars requires {required}.")
    step = _validate_index(bars.index, "5min")
    if not (bars.index[1:] - bars.index[:-1] == step).all():
        raise ValueError("bars must include the full grid; mark absent candles NaN.")
    if not isinstance(predictions, pd.Series) or not isinstance(sigma_next, pd.Series):
        raise TypeError("predictions and sigma_next must be Series.")
    if not bars.index.equals(predictions.index) or not bars.index.equals(
        sigma_next.index
    ):
        raise ValueError("bars, predictions and sigma_next require identical indexes.")
    if not np.isfinite([initial_cash, fee, slippage, stop_sigma, take_sigma]).all():
        raise ValueError("Execution settings must be finite.")
    if initial_cash <= 0 or not 0 <= fee < 1 or not 0 <= slippage < 1:
        raise ValueError("Cash must be positive; fee and slippage must be in [0,1).")
    if stop_sigma <= 0 or take_sigma <= 0:
        raise ValueError("Barrier multipliers must be positive.")
    if zero_volume_execution not in {
        "no_fills_report_blocked_orders",
        "allow_fills_report_assumption",
    }:
        raise ValueError("Unknown zero_volume_execution policy.")
    if interpolated_execution not in {"reject", "allow_fills_report_assumption"}:
        raise ValueError("Unknown interpolated_execution policy.")
    if "is_interpolated" in bars:
        marker = bars["is_interpolated"]
        if marker.isna().any() or not pd.api.types.is_bool_dtype(marker):
            raise ValueError("is_interpolated must contain nonmissing booleans.")
        synthetic = marker.to_numpy(dtype=bool)
    else:
        synthetic = np.zeros(len(bars), dtype=bool)
    if synthetic.any() and interpolated_execution == "reject":
        raise ValueError("Interpolated candles require an explicit execution policy.")
    if "data_available_at" in bars:
        available_at = pd.DatetimeIndex(
            pd.to_datetime(bars["data_available_at"], utc=True)
        )
    else:
        # Execution may use a hypothetical path, but synthetic source candles
        # without availability metadata cannot justify a causal forecast.
        available_at = (bars.index + step).where(~synthetic, pd.NaT)
    values = bars[required].to_numpy(dtype=float)
    signals = predictions.to_numpy(dtype=float)
    sigmas = sigma_next.to_numpy(dtype=float)
    valid = np.isfinite(values).all(axis=1)
    zero_volume = valid & (values[:, 4] == 0)
    finite_rows = values[valid]
    if (
        np.any(finite_rows[:, :4] <= 0)
        or np.any(finite_rows[:, 4] < 0)
        or np.any(finite_rows[:, 1] < np.max(finite_rows[:, [0, 2, 3]], axis=1))
        or np.any(finite_rows[:, 2] > np.min(finite_rows[:, [0, 1, 3]], axis=1))
    ):
        raise ValueError("OHLC or volume contains invalid finite values.")

    cash, quantity = float(initial_cash), 0.0
    stop, take = math.nan, math.nan
    entry: dict[str, Any] | None = None
    trades: list[dict[str, Any]] = []
    events: list[dict[str, Any]] = []
    rows: list[dict[str, Any]] = []
    next_trade_id = 1

    def sell(position: int, reference: float, reason: str, timing: str) -> None:
        nonlocal cash, quantity, stop, take, entry
        assert entry is not None
        fill = reference * (1 - slippage)
        sale_notional = quantity * fill
        exit_fee = sale_notional * fee
        proceeds = sale_notional - exit_fee
        cash += proceeds
        trade = {
            **entry,
            "exit_time": bars.index[position],
            "exit_timing": timing,
            "exit_price": fill,
            "exit_reference_price": reference,
            "exit_fee": exit_fee,
            "exit_reason": reason,
            "exit_synthetic": bool(synthetic[position]),
            "exit_zero_volume": bool(zero_volume[position]),
            "synthetic": entry["contains_synthetic_candles"],
            "net_pnl": proceeds - entry["entry_cash"],
            "net_return": proceeds / entry["entry_cash"] - 1,
            "bars_held": position - entry["entry_position"] + 1,
        }
        trades.append(trade)
        events.append(
            {
                "time": bars.index[position],
                "timing": timing,
                "event": "exit",
                "reason": reason,
                "trade_id": entry["trade_id"],
                "quantity": quantity,
                "reference_price": reference,
                "fill_price": fill,
                "fee_paid": exit_fee,
                "trade_synthetic": entry["contains_synthetic_candles"],
            }
        )
        quantity, stop, take, entry = 0.0, math.nan, math.nan, None

    for i, timestamp in enumerate(bars.index):
        open_price, high, low, close, volume = values[i]
        source_valid = bool(i > 0 and valid[i - 1] and available_at[i - 1] <= timestamp)
        signal = signals[i - 1] if source_valid else math.nan
        sigma = sigmas[i - 1] if source_valid else math.nan
        if i > 0 and valid[i - 1] and not source_valid:
            events.append(
                {
                    "time": timestamp,
                    "timing": "open",
                    "event": "unavailable-signal",
                    "reason": (
                        "source-data-not-yet-available"
                        if pd.notna(available_at[i - 1])
                        else "source-data-availability-unknown"
                    ),
                    "signal_source_time": bars.index[i - 1],
                }
            )
        wants_long = bool(np.isfinite(signal) and signal > 0)
        tradable = bool(
            valid[i]
            and (volume > 0 or zero_volume_execution == "allow_fills_report_assumption")
        )
        if entry is not None and synthetic[i]:
            entry["contains_synthetic_candles"] = True
        exited = False
        if not valid[i]:
            if quantity:
                raise UnscorablePathError(
                    f"Missing candle while holding long at {timestamp.isoformat()}."
                )
            events.append(
                {
                    "time": timestamp,
                    "event": "unavailable-candle",
                    "reason": "missing-data",
                }
            )
        elif not tradable:
            if quantity and not wants_long:
                events.append(
                    {
                        "time": timestamp,
                        "event": "blocked-exit",
                        "reason": "zero-volume",
                    }
                )
            elif not quantity and wants_long:
                events.append(
                    {
                        "time": timestamp,
                        "event": "blocked-entry",
                        "reason": "zero-volume",
                    }
                )
        else:
            if quantity:
                if open_price <= stop:
                    sell(i, open_price, "stop-gap", "open")
                    exited = True
                elif open_price >= take:
                    sell(i, open_price, "take-gap", "open")
                    exited = True
                elif not wants_long:
                    reason = "signal" if np.isfinite(signal) else "unavailable-signal"
                    sell(i, open_price, reason, "open")
                    exited = True
            if not quantity and not exited and wants_long:
                if not np.isfinite(sigma) or sigma <= 0:
                    events.append(
                        {
                            "time": timestamp,
                            "event": "blocked-entry",
                            "reason": "unavailable-risk",
                        }
                    )
                else:
                    fill = open_price * (1 + slippage)
                    with np.errstate(over="ignore", under="ignore", invalid="ignore"):
                        proposed_stop = fill * np.exp(-stop_sigma * sigma)
                        proposed_take = fill * np.exp(take_sigma * sigma)
                    if (
                        not np.isfinite([proposed_stop, proposed_take]).all()
                        or proposed_stop <= 0
                    ):
                        events.append(
                            {
                                "time": timestamp,
                                "event": "blocked-entry",
                                "reason": "invalid-barriers",
                            }
                        )
                    else:
                        quantity = cash / (fill * (1 + fee))
                        entry_fee = quantity * fill * fee
                        stop, take = float(proposed_stop), float(proposed_take)
                        entry = {
                            "trade_id": next_trade_id,
                            "entry_time": timestamp,
                            "entry_position": i,
                            "entry_price": fill,
                            "entry_reference_price": open_price,
                            "quantity": quantity,
                            "entry_cash": cash,
                            "entry_fee": entry_fee,
                            "entry_sigma": float(sigma),
                            "entry_synthetic": bool(synthetic[i]),
                            "entry_zero_volume": bool(zero_volume[i]),
                            "contains_synthetic_candles": bool(synthetic[i]),
                            "stop": stop,
                            "take": take,
                        }
                        next_trade_id += 1
                        cash = 0.0
                        events.append(
                            {
                                "time": timestamp,
                                "timing": "open",
                                "event": "entry",
                                "reason": "positive-signal",
                                "trade_id": entry["trade_id"],
                                "quantity": quantity,
                                "reference_price": open_price,
                                "fill_price": fill,
                                "fee_paid": entry_fee,
                            }
                        )
            if quantity:
                # With a very tight barrier, entry slippage can place the
                # reference open already below the new stop. Selling at the
                # higher barrier would invent price improvement.
                if open_price <= stop:
                    sell(i, open_price, "stop-gap", "open")
                elif low <= stop:
                    sell(i, stop, "stop", "intrabar")
                elif high >= take:
                    sell(i, take, "take", "intrabar")
        if i == len(bars) - 1 and end_close and quantity:
            if not tradable:
                raise UnscorablePathError(
                    "Cannot liquidate a final position without a tradable closing candle."
                )
            sell(i, close, "end-of-study", "close")
        marked_equity = cash + quantity * close if quantity else cash
        rows.append(
            {
                "time": timestamp,
                "cash": cash,
                "quantity": quantity,
                "equity": marked_equity,
                "position": bool(quantity),
                "stop": stop,
                "take": take,
                "data_available": bool(valid[i]),
                "tradable": tradable,
                "synthetic": bool(synthetic[i]),
                "zero_volume": bool(zero_volume[i]),
                "signal_available": source_valid,
            }
        )

    equity = pd.DataFrame(rows).set_index("time")
    equity["net_return"] = equity["equity"].pct_change(fill_method=None)
    equity.iloc[0, equity.columns.get_loc("net_return")] = (
        equity.iloc[0]["equity"] / initial_cash - 1
    )
    event_frame = pd.DataFrame(events)
    if len(event_frame):
        event_positions = bars.index.get_indexer(event_frame["time"])
        event_frame["synthetic"] = synthetic[event_positions]
        event_frame["zero_volume"] = zero_volume[event_positions]
    return SimulationResult(
        equity=equity,
        trades=pd.DataFrame(trades),
        events=event_frame,
        settings={
            "initial_cash": initial_cash,
            "fee": fee,
            "slippage": slippage,
            "stop_sigma": stop_sigma,
            "take_sigma": take_sigma,
            "end_close": end_close,
            "signal_timing": "next-open",
            "zero_volume_policy": (
                "allow-fills"
                if zero_volume_execution == "allow_fills_report_assumption"
                else "no-fills"
            ),
            "zero_volume_execution": zero_volume_execution,
            "interpolated_execution": interpolated_execution,
            "synthetic_candles": int(synthetic.sum()),
            "zero_volume_candles": int(zero_volume.sum()),
            "missing_held_candle_policy": "unscorable",
        },
    )
