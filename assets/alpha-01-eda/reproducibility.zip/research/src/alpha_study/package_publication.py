"""Package the executed EDA and its reproducibility inputs for the public site."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

from .runs import run_identity

REPO = Path(__file__).resolve().parents[3]
STUDY = REPO / "research/alpha_study"
OUTPUT = REPO / "research/assets/alpha-01-eda/reproducibility.zip"


def main() -> None:
    summary = json.loads((STUDY / "artifacts/eda_summary.json").read_text("utf-8"))
    identity = run_identity(STUDY)
    for key in ("spec_sha256", "data_hash", "source_sha256"):
        if summary[key] != identity[key]:
            raise RuntimeError(f"Publication inputs differ from executed EDA: {key}")
    paths = {REPO / path for path in summary["source_files"]}
    paths.update((REPO / "research/tests").glob("test_alpha_*.py"))
    paths.update(STUDY / name for name in ("PROTOCOL.md", "protocol.toml"))
    paths.update((STUDY / "artifacts").glob("eda_*.csv"))
    paths.update(
        STUDY / "artifacts" / name
        for name in (
            "eda_summary.json",
            "selection.json",
            "current_spot_snapshot.json",
            "download_manifest.json",
            "normalized_manifest.json",
            "data_quality.csv",
            "universe_ranked.csv",
            "universe_audit.csv",
            "universe_archive_snapshot.json",
            "universe_events.json",
            "universe_exclusion_rules.json",
        )
        if (STUDY / "artifacts" / name).exists()
    )
    payload = {path.relative_to(REPO).as_posix(): path.read_bytes() for path in paths}
    payload["README.md"] = """# Материалы к статье о пятиминутных доходностях альткойнов

Пакет содержит выполненный notebook, исходники расчётов, протокол 2.1.0,
зафиксированные зависимости, таблицы результатов и контрольные суммы данных.
Описательные результаты относятся к 1 января 2022 — 30 июня 2023 (UTC).
Это материалы исследования данных, без обученных альфа-моделей и бэктестов.

Встроенные графики notebook показывают измеренные результаты. Художественная
обложка сайта в пакет не входит. Исходные биржевые архивы и parquet не включены:
их источники и контрольные суммы перечислены в манифестах. Для загрузки данных
нужен доступ к официальному публичному архиву Binance. Заключительное полугодие
не входит в анализ EDA, хотя подготовка хранит полную историю 2022–2023.

Из корня распакованного пакета, с Python 3.12 и установленным uv:

```text
uv export --frozen --no-emit-project --no-emit-local --no-dev --emit-index-url --format requirements-txt --output-file requirements.txt
uv venv --python 3.12
uv pip install -r requirements.txt
uv run --no-project python -m research.src.alpha_study.data prepare
uv run --no-project python -m research.src.alpha_study.build_notebook --execute
```

Команды установки отражают полный lockfile проекта и могут загружать крупные
библиотеки. Для самого EDA нужны numpy, pandas, scipy, statsmodels, matplotlib,
seaborn, pyarrow, requests, filelock, nbformat, nbclient, nbconvert, ipykernel,
threadpoolctl; точные использованные версии находятся в eda_summary.json.
Модули infra/protocol входят в пакет и импортируются из его корня.

MANIFEST.sha256 проверяет каждый включённый файл. Значения source_sha256,
spec_sha256 и data_hash в eda_summary.json связывают расчёт с исходниками,
настройками и биржевыми манифестами. Метка Git-коммита описывает исходное рабочее
окружение; содержимое файлов точнее задаётся перечисленными SHA-256.
""".encode()
    manifest = "".join(
        f"{hashlib.sha256(data).hexdigest()}  {name}\n"
        for name, data in sorted(payload.items())
    ).encode()
    payload["MANIFEST.sha256"] = manifest
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    with ZipFile(OUTPUT, "w", compression=ZIP_DEFLATED) as archive:
        for name, data in sorted(payload.items()):
            entry = ZipInfo(name, date_time=(2026, 10, 15, 0, 0, 0))
            entry.compress_type = ZIP_DEFLATED
            entry.external_attr = 0o644 << 16
            archive.writestr(entry, data)
    with ZipFile(OUTPUT) as archive:
        assert archive.testzip() is None
        assert set(archive.namelist()) == set(payload)
        for name, data in payload.items():
            assert archive.read(name) == data
    print(
        json.dumps(
            {
                "path": OUTPUT.relative_to(REPO).as_posix(),
                "files": len(payload),
                "bytes": OUTPUT.stat().st_size,
                "sha256": hashlib.sha256(OUTPUT.read_bytes()).hexdigest(),
            }
        )
    )


if __name__ == "__main__":
    main()
