"""Versioned study configuration and leakage-safe UTC walk-forward windows."""

from __future__ import annotations

import hashlib
import json
import tomllib
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import pandas as pd


def _utc(value: str | pd.Timestamp) -> pd.Timestamp:
    timestamp = pd.Timestamp(value)
    return (
        timestamp.tz_localize("UTC")
        if timestamp.tz is None
        else timestamp.tz_convert("UTC")
    )


@dataclass(frozen=True)
class StudyConfig:
    """Boundaries are UTC bar-open timestamps, with exclusive right edges."""

    start: pd.Timestamp = field(default_factory=lambda: _utc("2022-01-01"))
    end: pd.Timestamp = field(default_factory=lambda: _utc("2024-01-01"))
    selection_end: pd.Timestamp = field(default_factory=lambda: _utc("2022-01-31"))
    final_start: pd.Timestamp = field(default_factory=lambda: _utc("2023-07-01"))
    timeframe: str = "5min"
    history_days: int = 30
    train_days: int = 23
    validation_days: int = 7
    test_days: int = 7
    version: str = "1.0.0"
    raw: dict[str, Any] = field(default_factory=dict, repr=False, compare=False)

    def __post_init__(self) -> None:
        for name in ("start", "end", "selection_end", "final_start"):
            object.__setattr__(self, name, _utc(getattr(self, name)))
        durations = (
            self.history_days,
            self.train_days,
            self.validation_days,
            self.test_days,
        )
        if any(not isinstance(value, int) or value <= 0 for value in durations):
            raise ValueError("Window durations must be positive integer days.")
        if self.train_days + self.validation_days != self.history_days:
            raise ValueError("Training and validation must partition the history.")
        if not self.start < self.selection_end <= self.final_start < self.end:
            raise ValueError("Expected start < selection_end <= final_start < end.")
        if self.selection_end - self.start != pd.Timedelta(days=self.history_days):
            raise ValueError("Selection interval must equal the first history window.")
        if self.bar_delta <= pd.Timedelta(0):
            raise ValueError("The bar interval must be positive.")
        if pd.Timedelta(days=1) % self.bar_delta != pd.Timedelta(0):
            raise ValueError("The bar interval must divide a UTC day exactly.")

    @property
    def bar_delta(self) -> pd.Timedelta:
        return pd.Timedelta(self.timeframe)

    @property
    def development_end(self) -> pd.Timestamp:
        return self.final_start


@dataclass(frozen=True)
class StudyWindow:
    """One fold; train/validation/refit/test intervals are half-open."""

    fold: int
    train_start: pd.Timestamp
    train_end: pd.Timestamp
    validation_start: pd.Timestamp
    validation_end: pd.Timestamp
    refit_start: pd.Timestamp
    refit_end: pd.Timestamp
    test_start: pd.Timestamp
    test_end: pd.Timestamp

    def as_dict(self) -> dict[str, int | pd.Timestamp]:
        return dict(self.__dict__)


def load_config(path: str | Path | None = None) -> StudyConfig:
    """Read a TOML file, or locate it relative to an explicitly given repo root."""
    if path is None:
        location = Path(__file__).resolve().parents[2] / "alpha_study/protocol.toml"
    else:
        location = Path(path)
        if location.is_dir():
            location = location / "research/alpha_study/protocol.toml"
    with location.open("rb") as source:
        raw = tomllib.load(source)
    dataset = raw["data"]
    windows = raw["windows"]
    return StudyConfig(
        start=dataset["start"],
        end=dataset["end_exclusive"],
        selection_end=dataset["selection_end_exclusive"],
        final_start=dataset["final_start"],
        timeframe=dataset["pandas_frequency"],
        history_days=windows["history_days"],
        train_days=windows["train_days"],
        validation_days=windows["validation_days"],
        test_days=windows["test_days"],
        version=raw["study"]["version"],
        raw=raw,
    )


def make_windows(config: StudyConfig | None = None) -> list[StudyWindow]:
    """Build complete consecutive folds; never silently shorten the last test."""
    config = config or load_config()
    start = config.selection_end
    step = pd.Timedelta(days=config.test_days)
    history = pd.Timedelta(days=config.history_days)
    training = pd.Timedelta(days=config.train_days)
    windows = []
    while start + step <= config.end:
        beginning = start - history
        boundary = beginning + training
        windows.append(
            StudyWindow(
                fold=len(windows),
                train_start=beginning,
                train_end=boundary,
                validation_start=boundary,
                validation_end=start,
                refit_start=beginning,
                refit_end=start,
                test_start=start,
                test_end=start + step,
            )
        )
        start += step
    return windows


def label_mask(
    open_index: pd.DatetimeIndex,
    start: str | pd.Timestamp,
    end: str | pd.Timestamp,
    bar_delta: str | pd.Timedelta = "5min",
) -> pd.Series:
    """Select samples whose source AND next close belong to [start, end).

    OHLCV is indexed by bar OPEN, not by observation availability. The label
    for open t is log(C[t + delta] / C[t]). Binance's target close_time is
    t + 2*delta - 1 ms, so t + 2*delta <= end is required. This is an eligibility
    mask only: callers must additionally require contiguous valid candles and
    complete features. A missing row never makes its next row the next candle.
    """
    if not isinstance(open_index, pd.DatetimeIndex) or open_index.tz is None:
        raise ValueError("An explicitly timezone-aware DatetimeIndex is required.")
    if not open_index.is_unique or not open_index.is_monotonic_increasing:
        raise ValueError("Bar-open timestamps must be unique and ordered.")
    left, right = _utc(start), _utc(end)
    delta = pd.Timedelta(bar_delta)
    if left >= right or delta <= pd.Timedelta(0):
        raise ValueError("Expected a nonempty interval and a positive bar length.")
    eligible = (open_index >= left) & (open_index + 2 * delta <= right)
    return pd.Series(eligible, index=open_index, name="label_in_window")


def config_fingerprint(config: StudyConfig | None = None) -> str:
    """Hash the complete versioned config, including statistical conventions."""
    config = config or load_config()
    payload = {key: value for key, value in config.__dict__.items() if key != "raw"}
    payload["raw"] = config.raw
    encoded = json.dumps(payload, sort_keys=True, default=str, ensure_ascii=False)
    return hashlib.sha256(encoded.encode("utf-8")).hexdigest()


def source_fingerprint(paths: list[str | Path]) -> str:
    """Hash supplied source files by content in stable basename order.

    Callers record the path list alongside the digest. Files must exist; missing
    sources are an error instead of producing a misleading successful hash.
    """
    digest = hashlib.sha256()
    for path in sorted(map(Path, paths), key=lambda item: (item.name, str(item))):
        digest.update(path.name.encode("utf-8"))
        digest.update(b"\0")
        digest.update(path.read_bytes())
        digest.update(b"\0")
    return digest.hexdigest()
