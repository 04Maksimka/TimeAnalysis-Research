"""A common causal GARCH risk process, independent of alpha-model predictions.

Decimal close-to-close log returns are multiplied by 100 only during fitting.
Persisted parameters, state variances and returned sigma use decimal-return
units. No variance backfill, interpolation or gap compression is performed.
"""

from __future__ import annotations

import math
import warnings
from collections.abc import Sequence
from dataclasses import asdict, dataclass
from typing import Any

import numpy as np
import pandas as pd
from arch import arch_model

from .protocol import StudyWindow
from .statistics import _validate_index


@dataclass
class GarchState:
    """GARCH(1,1), zero mean, standardized Student-t innovations.

    ``last_variance`` is h_t and ``last_return`` is observed r_t. Therefore
    forecast_sigma() returns sqrt(omega + alpha*r_t**2 + beta*h_t).
    Updating a newly closed return advances h_t first and then stores r_t.
    Calling update on an already-consumed or missing candle is an error.
    """

    omega: float
    alpha: float
    beta: float
    nu: float
    last_variance: float
    last_return: float
    last_timestamp: pd.Timestamp
    fitted_start: pd.Timestamp
    fitted_end: pd.Timestamp
    nobs: int
    fit_warnings: tuple[str, ...] = ()
    frequency: str = "5min"

    @classmethod
    def fit(cls, history: pd.Series, *, min_nobs: int = 500) -> GarchState:
        """Fit one contiguous history of at most 30 days.

        This low-level routine permits >=500 points for isolated diagnostics.
        Use weekly_garch_forecasts for the study's strict 30-day fit windows.
        Failed convergence or invalid parameters raises ValueError: callers
        must record unavailable risk, never silently use a substitute model.
        """
        if not isinstance(history, pd.Series):
            raise TypeError("GARCH history must be a pandas Series.")
        if not isinstance(min_nobs, int) or min_nobs < 10:
            raise ValueError("min_nobs must be an integer of at least ten.")
        step = _validate_index(history.index, "5min")
        values = history.to_numpy(dtype=float)
        if len(values) < min_nobs or not np.isfinite(values).all():
            raise ValueError("Insufficient finite contiguous GARCH history.")
        if not (history.index[1:] - history.index[:-1] == step).all():
            raise ValueError("GARCH cannot compress missing candles.")
        if len(values) > int(pd.Timedelta("30D") / step):
            raise ValueError("GARCH fit history must not exceed thirty days.")
        if values.max() == values.min():
            raise ValueError("Constant returns do not support a GARCH fit.")
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            result = arch_model(
                values * 100.0,
                mean="Zero",
                vol="GARCH",
                p=1,
                o=0,
                q=1,
                dist="StudentsT",
                rescale=False,
            ).fit(disp="off", update_freq=0, cov_type="robust")
        if result.convergence_flag != 0:
            raise ValueError(
                f"GARCH optimization failed: {result.optimization_result.message}"
            )
        params = result.params
        omega = float(params["omega"]) / 10_000.0
        alpha, beta, nu = (float(params[key]) for key in ("alpha[1]", "beta[1]", "nu"))
        variance = float(result.conditional_volatility[-1]) ** 2 / 10_000.0
        # The optimizer admits the integrated boundary alpha+beta=1. It yields
        # finite one-step forecasts but does not imply finite long-run variance.
        if (
            not np.isfinite([omega, alpha, beta, nu, variance]).all()
            or omega <= 0
            or alpha < 0
            or beta < 0
            or alpha + beta > 1 + 1e-8
            or nu <= 2
            or variance <= 0
        ):
            raise ValueError("GARCH fit returned invalid variance parameters.")
        messages = [str(item.message) for item in caught]
        if alpha + beta >= 1 - 1e-8:
            messages.append(
                "Persistence is on the integrated boundary; no finite long-run variance claim."
            )
        return cls(
            omega=omega,
            alpha=alpha,
            beta=beta,
            nu=nu,
            last_variance=variance,
            last_return=float(values[-1]),
            last_timestamp=history.index[-1],
            fitted_start=history.index[0],
            fitted_end=history.index[-1] + step,
            nobs=len(history),
            fit_warnings=tuple(messages),
        )

    def forecast_sigma(self) -> float:
        variance = (
            self.omega
            + self.alpha * self.last_return**2
            + self.beta * self.last_variance
        )
        if not np.isfinite(variance) or variance <= 0:
            raise ValueError("GARCH forecast variance must be finite and positive.")
        return math.sqrt(variance)

    def update_closed_return(self, value: float, timestamp: pd.Timestamp) -> float:
        """Consume exactly the next closed candle and forecast the following one."""
        timestamp = pd.Timestamp(timestamp)
        if str(
            timestamp.tz
        ) != "UTC" or timestamp != self.last_timestamp + pd.Timedelta(self.frequency):
            raise ValueError("GARCH updates require exactly the next UTC candle.")
        if not np.isfinite(value):
            raise ValueError("A missing return invalidates recursive GARCH risk.")
        variance = self.forecast_sigma() ** 2
        self.last_variance = variance
        self.last_return = float(value)
        self.last_timestamp = timestamp
        return self.forecast_sigma()

    def as_dict(self) -> dict[str, Any]:
        record = asdict(self)
        for key in ("last_timestamp", "fitted_start", "fitted_end"):
            record[key] = record[key].isoformat()
        record.update(
            model="GARCH(1,1)",
            mean="zero",
            innovation="standardized-Student-t",
            return_units="decimal-log-return",
            fitting_scale=100,
            persistence=self.alpha + self.beta,
        )
        return record


@dataclass
class RiskForecasts:
    forecasts: pd.DataFrame
    fits: list[dict[str, Any]]


def weekly_garch_forecasts(
    returns: pd.Series,
    windows: Sequence[StudyWindow],
) -> RiskForecasts:
    """Compute one shared risk path for one asset over fixed study windows.

    A row labelled by candle open t is available after that candle closes and
    forecasts sigma for t+5min. At weekly boundaries, the newly fitted state
    produces that boundary's forecast; all alpha models reuse the same output.

    Histories must cover all 30 days. Only a single NaN at the dataset's first
    timestamp (undefined first return) may be excluded, with metadata recording
    this exclusion. Every other gap yields unavailable risk. A missing return
    during a test week invalidates the state until the next successful refit.
    """
    step = _validate_index(returns.index, "5min")
    if not (returns.index[1:] - returns.index[:-1] == step).all():
        raise ValueError("Supply the full UTC grid with missing returns marked NaN.")
    if not len(returns):
        raise ValueError("Returns must contain the history and evaluation grid.")
    output = pd.DataFrame(index=returns.index)
    output["sigma_next"] = np.nan
    output["status"] = "not-evaluated"
    output["fold"] = pd.Series(pd.NA, index=returns.index, dtype="Int64")
    output["available_at"] = returns.index + step
    output["target_open"] = returns.index + step
    fits: list[dict[str, Any]] = []
    previous_end = None
    for window in windows:
        if (
            window.refit_end != window.test_start
            or window.refit_end - window.refit_start != pd.Timedelta("30D")
        ):
            raise ValueError("Expected a thirty-day history ending at test start.")
        if window.test_end - window.test_start != pd.Timedelta("7D"):
            raise ValueError("Risk refits must use complete seven-day test windows.")
        if previous_end is not None and window.test_start != previous_end:
            raise ValueError("Risk windows must be ordered and consecutive.")
        previous_end = window.test_end
        targets = pd.date_range(
            window.test_start, window.test_end, freq=step, inclusive="left"
        )
        origins = targets - step
        if not origins.isin(returns.index).all():
            raise ValueError("Return grid must include all forecast origins.")
        expected_history = pd.date_range(
            window.refit_start, window.refit_end, freq=step, inclusive="left"
        )
        record: dict[str, Any] = {
            "fold": window.fold,
            "status": "unavailable",
            "reason": None,
            "refit_start": window.refit_start.isoformat(),
            "refit_end": window.refit_end.isoformat(),
            "excluded_initial_return": 0,
        }
        state = None
        try:
            if not expected_history.isin(returns.index).all():
                raise ValueError("Incomplete thirty-day input grid.")
            history = returns.loc[expected_history]
            if history.index[0] == returns.index[0] and pd.isna(history.iloc[0]):
                history = history.iloc[1:]
                record["excluded_initial_return"] = 1
            state = GarchState.fit(history)
            record.update(status="ok", fit=state.as_dict())
        except (ValueError, np.linalg.LinAlgError) as error:
            record["reason"] = str(error)
        fits.append(record)
        for number, origin in enumerate(origins):
            output.at[origin, "fold"] = window.fold
            if state is not None and number:
                try:
                    state.update_closed_return(float(returns.at[origin]), origin)
                except ValueError as error:
                    record["state_invalidated_at"] = origin.isoformat()
                    record["state_invalidation_reason"] = str(error)
                    state = None
            if state is None:
                output.at[origin, "status"] = "unavailable"
            else:
                output.at[origin, "sigma_next"] = state.forecast_sigma()
                output.at[origin, "status"] = "ok"
    return RiskForecasts(output, fits)
