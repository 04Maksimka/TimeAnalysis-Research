"""Append-only run provenance, including dirty/untracked source file content."""

from __future__ import annotations

import hashlib
import json
import uuid
from contextlib import contextmanager
from pathlib import Path

from filelock import FileLock

from infra.protocol import ledger

from .data import load_current_spot_snapshot
from .protocol import config_fingerprint, load_config


def _source_identity(repo: Path) -> dict:
    """Include notebook code, local numerical helpers and locked dependencies.

    Outputs and execution counts are deliberately excluded: writing results
    must not change the identity of the code that produced those results.
    Jupyter checkpoint copies are excluded because they are not study sources
    and need not exist in a clean repository checkout.
    """
    sources = sorted((repo / "research/src/alpha_study").glob("*.py"))
    sources += sorted((repo / "infra/protocol").glob("*.py"))
    sources += [repo / "pyproject.toml", repo / "uv.lock"]
    hashes = {
        path.relative_to(repo).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest()
        for path in sources
    }
    for notebook in sorted((repo / "research/posts").rglob("alpha-*.ipynb")):
        if ".ipynb_checkpoints" in notebook.relative_to(repo).parts:
            continue
        document = json.loads(notebook.read_text(encoding="utf-8"))
        code = [
            "".join(cell["source"])
            for cell in document["cells"]
            if cell["cell_type"] == "code"
        ]
        encoded = json.dumps(code, ensure_ascii=False).encode("utf-8")
        hashes[notebook.relative_to(repo).as_posix()] = hashlib.sha256(
            encoded
        ).hexdigest()
    return {
        "source_sha256": hashlib.sha256(
            json.dumps(hashes, sort_keys=True).encode("utf-8")
        ).hexdigest(),
        "source_files": sorted(hashes),
        "source_hashes": hashes,
        "notebook_hash_policy": "ordered code-cell sources; outputs and .ipynb_checkpoints excluded",
    }


def run_identity(study_root: Path) -> dict:
    """Bind an execution to exact configuration, manifests and research code."""
    config = load_config(study_root / "protocol.toml")
    repo = study_root.parents[1]
    manifests = [
        study_root / "artifacts" / name
        for name in (
            "selection.json",
            "download_manifest.json",
            "normalized_manifest.json",
        )
    ]
    if config.raw["selection"]["future_listing_survival_filter"]:
        _, evidence = load_current_spot_snapshot(study_root, protocol=config.raw)
        manifests.append(study_root / evidence["path"])
    manifest_hashes = {
        path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in manifests
    }
    return {
        "spec_sha256": config_fingerprint(config),
        "data_hash": hashlib.sha256(
            json.dumps(manifest_hashes, sort_keys=True).encode()
        ).hexdigest(),
        "manifest_hashes": manifest_hashes,
        **_source_identity(repo),
        "code": ledger.code_version(repo),
    }


def append_event(path: Path, event: dict) -> None:
    """Serialize writers without changing existing historical ledger code."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with FileLock(str(path) + ".lock"):
        ledger.append(path, event)


@contextmanager
def tracked_run(stage: str, study_root: str | Path):
    """Record start/success/failure; a run cannot silently change its inputs.

    The EDA is exploratory and explicitly marked as such. This provenance
    registry does not turn exploration into preregistered confirmation.
    """
    root = Path(study_root).resolve()
    identity = run_identity(root)
    run_id = str(uuid.uuid4())
    path = root / "artifacts/runs.jsonl"
    common = {
        "run_id": run_id,
        "experiment_id": f"{stage}-{identity['spec_sha256'][:12]}",
        "stage": stage,
        "inference_status": "exploratory",
        **identity,
    }
    append_event(path, {**common, "event": "freeze", "utc": ledger.now_utc()})
    result = {}
    try:
        yield result
        after = run_identity(root)
        for key in ("spec_sha256", "data_hash", "source_sha256"):
            if after[key] != identity[key]:
                raise RuntimeError(f"Study input changed during execution: {key}")
    except BaseException as error:
        append_event(
            path,
            {
                **common,
                "event": "failure",
                "utc": ledger.now_utc(),
                "error_type": type(error).__name__,
                "error": str(error)[:2000],
            },
        )
        raise
    else:
        append_event(
            path,
            {
                **common,
                "event": "result",
                "utc": ledger.now_utc(),
                "result": result,
            },
        )


def audit_runs(path: str | Path) -> list[str]:
    """Match the full spec/data/source identity, not only the experiment name."""
    problems = []
    frozen = {}
    completed = set()
    for number, event in enumerate(ledger.read(path), 1):
        run_id = event.get("run_id")
        if event.get("event") == "freeze":
            if run_id in frozen:
                problems.append(f"line {number}: duplicate freeze")
            frozen[run_id] = event
        elif event.get("event") in {"result", "failure"}:
            origin = frozen.get(run_id)
            if origin is None:
                problems.append(f"line {number}: missing freeze")
            elif any(
                origin.get(key) != event.get(key)
                for key in ("spec_sha256", "data_hash", "source_sha256")
            ):
                problems.append(f"line {number}: changed run identity")
            if run_id in completed:
                problems.append(f"line {number}: duplicate terminal event")
            completed.add(run_id)
    for run_id in set(frozen) - completed:
        problems.append(f"run {run_id}: no terminal event")
    return problems
