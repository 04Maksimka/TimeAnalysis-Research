"""Shared, gap-aware inference for the monthly alpha study.

Tests describe evidence in a specified sample; none prove stationarity, causal
effects or profitable trading. Index validation is deliberately strict: removing
missing rows would make nonadjacent candles or days appear consecutive.
"""

from __future__ import annotations

import warnings
from collections.abc import Sequence
from typing import Any, Literal

import numpy as np
import pandas as pd
from statsmodels.stats.diagnostic import acorr_ljungbox, het_arch
from statsmodels.stats.multitest import multipletests
from statsmodels.stats.stattools import jarque_bera
from statsmodels.tsa.stattools import adfuller, kpss

from infra.protocol.bootstrap import moving_block_indices

SegmentPolicy = Literal["reject", "longest"]
StationarityWorkingPolicy = Literal["strict", "conflict_as_stationary_flagged"]


def _validate_index(index: pd.Index, frequency: str) -> pd.Timedelta:
    if not isinstance(index, pd.DatetimeIndex):
        raise ValueError("A UTC DatetimeIndex is required.")
    if str(index.tz) != "UTC":
        raise ValueError("The index must be timezone-aware UTC.")
    if index.hasnans or not index.is_unique or not index.is_monotonic_increasing:
        raise ValueError("Timestamps must be ordered, unique and nonmissing.")
    step = pd.Timedelta(frequency)
    if step <= pd.Timedelta(0):
        raise ValueError("frequency must be a positive fixed timedelta.")
    if len(index) and not (index == index.floor(step)).all():
        raise ValueError(f"Timestamps must lie on the {frequency} UTC grid.")
    return step


def _sample(
    series: pd.Series,
    frequency: str,
    segment_policy: SegmentPolicy,
) -> tuple[pd.Series, dict[str, Any]]:
    """Select at most one contiguous segment, never concatenate across gaps."""
    if not isinstance(series, pd.Series):
        raise TypeError("Expected a pandas Series.")
    if segment_policy not in {"reject", "longest"}:
        raise ValueError("segment_policy must be 'reject' or 'longest'.")
    step = _validate_index(series.index, frequency)
    values = series.to_numpy(dtype=float)
    finite = np.isfinite(values)
    contiguous = np.asarray(series.index[1:] - series.index[:-1] == step)
    if segment_policy == "reject" and (not finite.all() or not contiguous.all()):
        raise ValueError(
            "Nonfinite observations or gaps; use an explicitly reported "
            "contiguous-segment policy instead of dropping rows."
        )

    # Break at a missing observation and at a missing timestamp. Stable max means
    # the earliest segment wins ties; this choice does not depend on test results.
    segments: list[tuple[int, int]] = []
    start: int | None = None
    for position, valid in enumerate(finite):
        if start is not None and (
            not valid or (position > 0 and not contiguous[position - 1])
        ):
            segments.append((start, position))
            start = None
        if valid and start is None:
            start = position
    if start is not None:
        segments.append((start, len(series)))
    left, right = max(segments, key=lambda pair: pair[1] - pair[0], default=(0, 0))
    selected = series.iloc[left:right].astype(float)
    expected = (
        int((series.index[-1] - series.index[0]) / step) + 1 if len(series) else 0
    )
    metadata = {
        "policy": segment_policy,
        "frequency": frequency,
        "input_nobs": len(series),
        "selected_nobs": len(selected),
        "excluded_rows": len(series) - len(selected),
        "missing_grid_rows": expected - len(series),
        "nonfinite_rows": int((~finite).sum()),
        "segment_count": len(segments),
        "window_start": selected.index[0].isoformat() if len(selected) else None,
        "window_end": selected.index[-1].isoformat() if len(selected) else None,
    }
    return selected, metadata


def _record(
    test: str,
    h0: str,
    sample: pd.Series,
    settings: dict[str, Any],
    *,
    status: str = "ok",
    reason: str | None = None,
) -> dict[str, Any]:
    return {
        "test": test,
        "h0": h0,
        "status": status,
        "reason": reason,
        "statistic": None,
        "pvalue": None,
        "pvalue_relation": None,
        "reject": None,
        "nobs": len(sample),
        "lags": None,
        "window_start": sample.index[0].isoformat() if len(sample) else None,
        "window_end": sample.index[-1].isoformat() if len(sample) else None,
        "settings": settings,
        "warnings": [],
    }


def _validate_alpha(alpha: float) -> None:
    if not 0 < alpha < 1:
        raise ValueError("alpha must lie strictly between zero and one.")


def _bound_decision(pvalue: float, relation: str, alpha: float) -> bool | None:
    if relation == "<":
        return True if pvalue <= alpha else None
    if relation == ">":
        return False if pvalue >= alpha else None
    return bool(pvalue < alpha)


def stationarity_working_classification(
    report: dict[str, Any],
    *,
    policy: StationarityWorkingPolicy = "strict",
) -> dict[str, Any]:
    """Apply a modeling convention without changing diagnostic test evidence.

    A conflict means two successful, decidable tests: both reject their
    respective nulls, or neither does. Missing/failed tests and undecidable
    tabulated p-value bounds never receive assumed stationarity. These labels
    are based on the raw joint diagnostic, not multiplicity-adjusted inference.
    """
    if policy not in {"strict", "conflict_as_stationary_flagged"}:
        raise ValueError("Unsupported stationarity working policy.")
    diagnostic = report["status"]
    result = {
        "diagnostic_status": diagnostic,
        "working_status": "undetermined",
        "working_flag": None,
        "working_policy": policy,
    }
    tests = {record["test"]: record for record in report["tests"]}
    adf, kpss_result = tests.get("ADF"), tests.get("KPSS")
    if any(
        record is None
        or record.get("status") != "ok"
        or not isinstance(record.get("reject"), bool | np.bool_)
        for record in (adf, kpss_result)
    ):
        return result
    adf_reject, kpss_reject = bool(adf["reject"]), bool(kpss_result["reject"])
    if diagnostic == "stationary-compatible" and adf_reject and not kpss_reject:
        result["working_status"] = "stationary"
    elif diagnostic == "nonstationarity-supported" and not adf_reject and kpss_reject:
        result["working_status"] = "nonstationary"
    elif (
        diagnostic == "inconclusive"
        and adf_reject == kpss_reject
        and policy == "conflict_as_stationary_flagged"
    ):
        result["working_status"] = "stationary"
        result["working_flag"] = "adf-kpss-conflict"
    return result


def stationarity_tests(
    series: pd.Series,
    *,
    expected_frequency: str = "5min",
    maxlag: int = 24,
    regression: Literal["c", "ct"] = "c",
    alpha: float = 0.05,
    segment_policy: SegmentPolicy = "reject",
    working_policy: StationarityWorkingPolicy = "strict",
) -> dict[str, Any]:
    """Joint ADF/KPSS diagnostics on one explicit, regular UTC segment.

    ADF uses AIC over lags 0..24 by default (two hours on the 5-minute grid).
    This fixed, reported cap keeps repeated monthly tests tractable; it is not
    selected from p-values and can be changed in a preregistered configuration.
    KPSS uses its automatic bandwidth. ``c`` tests level stationarity; ``ct``
    tests stationarity around a linear trend and must be justified beforehand.
    The policy ``longest`` takes the earliest longest finite contiguous segment;
    its exclusions and exact tested window are returned for reporting.
    """
    _validate_alpha(alpha)
    if not isinstance(maxlag, int) or maxlag < 0:
        raise ValueError("maxlag must be a nonnegative integer.")
    if regression not in {"c", "ct"}:
        raise ValueError("regression must be 'c' or 'ct'.")
    sample, segment = _sample(series, expected_frequency, segment_policy)
    settings = {"regression": regression, "alpha": alpha}
    adf_record = _record(
        "ADF",
        "The series has a unit root.",
        sample,
        {**settings, "maxlag": maxlag, "autolag": "AIC"},
    )
    kpss_record = _record(
        "KPSS",
        "The series is level-stationary."
        if regression == "c"
        else "The series is trend-stationary.",
        sample,
        {**settings, "nlags": "auto"},
    )
    records = [adf_record, kpss_record]
    reason = None
    # statsmodels' maximum ADF lag is n//2 - number_of_deterministics - 1.
    required = max(50, 2 * (maxlag + (1 if regression == "c" else 2) + 1))
    if len(sample) < required:
        reason = f"Need at least {required} contiguous observations."
    elif sample.max() == sample.min():
        reason = "A constant series does not support these test regressions."
    if reason:
        for record in records:
            record.update(status="not-applicable", reason=reason)
    else:
        for record, function in [(adf_record, adfuller), (kpss_record, kpss)]:
            try:
                with warnings.catch_warnings(record=True) as caught:
                    warnings.simplefilter("always")
                    if record["test"] == "ADF":
                        result = function(
                            sample.to_numpy(),
                            maxlag=maxlag,
                            regression=regression,
                            autolag="AIC",
                        )
                    else:
                        result = function(
                            sample.to_numpy(), regression=regression, nlags="auto"
                        )
                statistic, pvalue, lags = result[:3]
                if not np.isfinite(statistic) or not np.isfinite(pvalue):
                    raise ValueError("Test produced a nonfinite statistic or p-value.")
                relation = "="
                messages = [str(item.message) for item in caught]
                if record["test"] == "KPSS":
                    if any("smaller" in message for message in messages):
                        relation = "<"
                    elif any("greater" in message for message in messages):
                        relation = ">"
                record.update(
                    statistic=float(statistic),
                    pvalue=float(pvalue),
                    pvalue_relation=relation,
                    reject=_bound_decision(float(pvalue), relation, alpha),
                    lags=int(lags),
                    warnings=messages,
                    critical_values={
                        str(key): float(value)
                        for key, value in result[
                            4 if record["test"] == "ADF" else 3
                        ].items()
                    },
                )
                if record["test"] == "ADF":
                    record["regression_nobs"] = int(result[3])
                    record["information_criterion"] = float(result[5])
            except (ValueError, np.linalg.LinAlgError, OverflowError) as error:
                record.update(status="failed", reason=str(error))

    decision = "inconclusive"
    if any(record["status"] != "ok" for record in records):
        decision = "not-applicable"
    elif adf_record["reject"] is True and kpss_record["reject"] is False:
        decision = "stationary-compatible"
    elif adf_record["reject"] is False and kpss_record["reject"] is True:
        decision = "nonstationarity-supported"
    report = {"status": decision, "tests": records, "segment": segment}
    return {
        **report,
        **stationarity_working_classification(report, policy=working_policy),
    }


def residual_diagnostics(
    series: pd.Series,
    *,
    model_df: int = 0,
    lags: Sequence[int] = (12, 288),
    expected_frequency: str = "5min",
    segment_policy: SegmentPolicy = "reject",
    alpha: float = 0.05,
) -> list[dict[str, Any]]:
    """Ljung-Box, ARCH-LM and descriptive JB for one residual series.

    Pass p+q for fitted ARMA residuals. For standardized GARCH residuals call this
    once on z and again on z**2; covariance/parameter uncertainty of GARCH is not
    covered by the asymptotic p-values. Jarque-Bera assumes normality and is only
    descriptive with dependent observations or a Student-t innovation model.
    """
    _validate_alpha(alpha)
    if not isinstance(model_df, int) or model_df < 0:
        raise ValueError("model_df must be a nonnegative integer.")
    if not lags or any(not isinstance(lag, int) or lag < 1 for lag in lags):
        raise ValueError("lags must contain positive integers.")
    sample, segment = _sample(series, expected_frequency, segment_policy)
    records = []
    for lag in dict.fromkeys(lags):
        for test, h0 in (
            ("Ljung-Box", "No autocorrelation up to the specified lag."),
            ("ARCH-LM", "No ARCH effects up to the specified lag."),
        ):
            record = _record(
                test,
                h0,
                sample,
                {"lag": lag, "model_df": model_df, "alpha": alpha},
            )
            record.update(lags=lag, segment=segment)
            if len(sample) < max(5 * lag, 2 * lag + model_df + 3):
                record.update(
                    status="not-applicable",
                    reason="Too few contiguous observations for this lag.",
                )
            elif sample.max() == sample.min():
                record.update(status="not-applicable", reason="Constant residuals.")
            elif test == "Ljung-Box" and lag <= model_df:
                record.update(
                    status="not-applicable", reason="lag - model_df must be positive."
                )
            else:
                try:
                    with warnings.catch_warnings(record=True) as caught:
                        warnings.simplefilter("always")
                        if test == "Ljung-Box":
                            result = acorr_ljungbox(
                                sample.to_numpy(),
                                lags=[lag],
                                model_df=model_df,
                                return_df=True,
                            )
                            statistic = result.iloc[0]["lb_stat"]
                            pvalue = result.iloc[0]["lb_pvalue"]
                        else:
                            statistic, pvalue, *_ = het_arch(
                                sample.to_numpy(), nlags=lag, ddof=model_df
                            )
                    if not np.isfinite(statistic) or not np.isfinite(pvalue):
                        raise ValueError("Nonfinite diagnostic result.")
                    record.update(
                        statistic=float(statistic),
                        pvalue=float(pvalue),
                        pvalue_relation="=",
                        reject=bool(pvalue < alpha),
                        warnings=[str(item.message) for item in caught],
                    )
                except (ValueError, np.linalg.LinAlgError) as error:
                    record.update(status="failed", reason=str(error))
            records.append(record)

    jb = _record(
        "Jarque-Bera",
        "Residuals follow a normal distribution.",
        sample,
        {"alpha": alpha, "interpretation": "descriptive-only"},
    )
    jb["segment"] = segment
    jb["warnings"] = [
        "Normality p-values are descriptive under temporal dependence; "
        "normality is not the null for Student-t innovations."
    ]
    if len(sample) < 8 or sample.max() == sample.min():
        jb.update(status="not-applicable", reason="Short or constant residuals.")
    else:
        statistic, pvalue, skew, kurtosis = jarque_bera(sample.to_numpy())
        jb.update(
            statistic=float(statistic),
            pvalue=float(pvalue),
            pvalue_relation="=",
            reject=bool(pvalue < alpha),
            skew=float(skew),
            kurtosis=float(kurtosis),
        )
    return [*records, jb]


def adjust_pvalues(
    records: Sequence[dict[str, Any]],
    *,
    method: Literal["holm", "fdr_by"] = "holm",
    family_key: str = "family",
    alpha: float = 0.05,
) -> list[dict[str, Any]]:
    """Adjust prespecified families, retaining failed/unavailable hypotheses.

    Invalid p-values count toward family size as p=1, so failed tests cannot
    silently reduce multiplicity. Their adjusted p-value remains unavailable.
    KPSS bounds are excluded from inference unless exact p-values are supplied;
    bounded p-values are not treated as point estimates for adjustment.
    """
    _validate_alpha(alpha)
    if method not in {"holm", "fdr_by"}:
        raise ValueError("Only holm and fdr_by are supported.")
    output = [dict(record) for record in records]
    families: dict[Any, list[int]] = {}
    for position, record in enumerate(output):
        if family_key not in record:
            raise ValueError(f"Every hypothesis must declare {family_key!r}.")
        families.setdefault(record[family_key], []).append(position)
        record.update(
            correction=method,
            adjusted_pvalue=None,
            adjusted_reject=None,
            correction_status="not-applicable",
        )
    for positions in families.values():
        available = []
        pvalues = []
        for position in positions:
            record = output[position]
            pvalue = record.get("pvalue")
            numeric = isinstance(pvalue, int | float | np.integer | np.floating)
            valid = (
                numeric
                and np.isfinite(pvalue)
                and 0 <= pvalue <= 1
                and record.get("status", "ok") == "ok"
                and record.get("pvalue_relation", "=") in {"=", None}
            )
            available.append(bool(valid))
            pvalues.append(float(pvalue) if valid else 1.0)
        reject, adjusted, *_ = multipletests(pvalues, alpha=alpha, method=method)
        for position, valid, decision, pvalue in zip(
            positions, available, reject, adjusted, strict=True
        ):
            output[position]["family_size"] = len(positions)
            if valid:
                output[position].update(
                    adjusted_pvalue=float(pvalue),
                    adjusted_reject=bool(decision),
                    correction_status="ok",
                )
    return output


def paired_block_bootstrap(
    differences: pd.Series | pd.DataFrame,
    *,
    block_days: int = 14,
    draws: int = 5000,
    seed: int = 0,
    alternative: Literal["two-sided", "less", "greater"] = "two-sided",
    alpha: float = 0.05,
) -> pd.DataFrame:
    """Paired moving-block inference for daily differences in losses or returns.

    All columns share the *same* sampled date indices, preserving cross-model
    and cross-coin dependence. Input rows must be consecutive UTC midnights;
    no missing rows or NaNs are removed. Formal inference requires at least
    max(180 days, 12 full blocks); shorter samples return only the observed
    effect with not-applicable status. This finite-sample guard is a conservative
    study convention, not a guarantee of calibration for arbitrary dependence.
    Confidence intervals use the uncentered bootstrap means; p-values
    use means after centering each input column at its observed mean (H0=0),
    with a plus-one Monte Carlo correction. Negative loss differences favour
    the candidate; positive return differences favour the candidate.

    Results are marginal intervals/tests, not simultaneous confidence regions.
    Call adjust_pvalues on a declared family for confirmatory comparisons.
    """
    _validate_alpha(alpha)
    if not isinstance(block_days, int) or block_days < 1:
        raise ValueError("block_days must be a positive integer.")
    if not isinstance(draws, int) or draws < 1:
        raise ValueError("draws must be a positive integer.")
    if alternative not in {"two-sided", "less", "greater"}:
        raise ValueError("alternative must be two-sided, less or greater.")
    if isinstance(differences, pd.Series):
        differences = differences.to_frame(name=differences.name or "difference")
    if not isinstance(differences, pd.DataFrame) or differences.shape[1] < 1:
        raise TypeError("Expected a nonempty-column Series or DataFrame.")
    if not differences.columns.is_unique:
        raise ValueError("Comparison names must be unique.")
    step = _validate_index(differences.index, "1D")
    values = differences.to_numpy(dtype=float)
    if (
        not np.isfinite(values).all()
        or not (differences.index[1:] - differences.index[:-1] == step).all()
    ):
        raise ValueError(
            "Daily comparisons require aligned, finite, consecutive dates."
        )
    nobs, width = values.shape
    min_nobs = max(180, 12 * block_days)
    records = [
        {
            "comparison": str(name),
            "test": "paired-moving-block-mean",
            "h0": "The mean paired daily difference is zero.",
            "status": "ok" if nobs >= min_nobs else "not-applicable",
            "reason": None
            if nobs >= min_nobs
            else f"Approximate inference requires at least {min_nobs} days (180 days and 12 blocks).",
            "nobs": nobs,
            "min_nobs": min_nobs,
            "inference": "approximate-moving-block-bootstrap",
            "block_days": block_days,
            "draws": draws,
            "seed": seed,
            "alpha": alpha,
            "alternative": alternative,
            "effect": float(values[:, column].mean()) if nobs else None,
            "ci_low": None,
            "ci_high": None,
            "pvalue": None,
            "pvalue_relation": "=",
            "reject": None,
            "window_start": differences.index[0].isoformat() if nobs else None,
            "window_end": differences.index[-1].isoformat() if nobs else None,
        }
        for column, name in enumerate(differences.columns)
    ]
    if nobs < min_nobs:
        return pd.DataFrame(records)

    rng = np.random.default_rng(seed)
    observed = values.mean(axis=0)
    centered = values - observed
    distributions = np.empty((draws, width), dtype=float)
    null_distributions = np.empty_like(distributions)
    # Bound peak memory even when the entire model/coin comparison panel is passed.
    batch = max(1, min(256, 2_000_000 // max(1, nobs * width)))
    for left in range(0, draws, batch):
        right = min(left + batch, draws)
        indices = moving_block_indices(nobs, block_days, right - left, rng)
        distributions[left:right] = values[indices].mean(axis=1)
        null_distributions[left:right] = centered[indices].mean(axis=1)
    lower, upper = np.quantile(distributions, [alpha / 2, 1 - alpha / 2], axis=0)
    if alternative == "less":
        extreme = null_distributions <= observed
    elif alternative == "greater":
        extreme = null_distributions >= observed
    else:
        extreme = np.abs(null_distributions) >= np.abs(observed)
    pvalues = (extreme.sum(axis=0) + 1) / (draws + 1)
    for column, record in enumerate(records):
        record.update(
            ci_low=float(lower[column]),
            ci_high=float(upper[column]),
            pvalue=float(pvalues[column]),
            reject=bool(pvalues[column] < alpha),
        )
    return pd.DataFrame(records)


def daily_loss_differences(
    actual: pd.Series,
    model: pd.Series,
    baseline: pd.Series,
    *,
    expected_frequency: str = "5min",
) -> pd.Series:
    """Daily mean MSE(candidate) - MSE(baseline), evaluated on identical rows.

    Index labels identify *target* candle times, not forecast origin times.
    Inputs must have identical indexes: accidental joins cannot change the
    evaluation population. Missing/nonfinite predictions, absent grid points
    and partial boundary days produce NaN for that day. Do not drop these days
    before bootstrap; choose and disclose a contiguous complete evaluation
    segment or repair the underlying missing forecasts.
    """
    if not all(isinstance(item, pd.Series) for item in (actual, model, baseline)):
        raise TypeError("actual, model and baseline must be Series.")
    step = _validate_index(actual.index, expected_frequency)
    if not actual.index.equals(model.index) or not actual.index.equals(baseline.index):
        raise ValueError(
            "Actual and both forecasts must have identical target indexes."
        )
    observations_per_day = pd.Timedelta("1D") / step
    if not float(observations_per_day).is_integer():
        raise ValueError("The observation frequency must divide one day exactly.")
    if not len(actual):
        return pd.Series(index=actual.index, dtype=float, name="mse_difference")
    data = np.column_stack(
        [item.to_numpy(dtype=float) for item in (actual, model, baseline)]
    )
    valid = np.isfinite(data).all(axis=1)
    with np.errstate(over="ignore", invalid="ignore"):
        difference = (data[:, 0] - data[:, 1]) ** 2 - (data[:, 0] - data[:, 2]) ** 2
    difference[~valid | ~np.isfinite(difference)] = np.nan
    losses = pd.Series(difference, index=actual.index)
    means = losses.resample("1D").mean()
    complete = losses.resample("1D").count() == int(observations_per_day)
    return means.where(complete).rename("mse_difference")
