"""Small frozen preprocessing helpers with explicit training boundaries."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd


def _utc_index(index: pd.Index) -> None:
    if not isinstance(index, pd.DatetimeIndex) or str(index.tz) != "UTC":
        raise ValueError("Expected a timezone-aware UTC DatetimeIndex.")
    if index.hasnans or not index.is_unique or not index.is_monotonic_increasing:
        raise ValueError("Timestamps must be ordered, unique and nonmissing.")


@dataclass(frozen=True)
class TrainingStandardizer:
    """Population z-score parameters fitted only inside [start, end).

    The immutable object stores no data and never updates while transforming a
    validation/test window. Each weekly fit must create a fresh object. Constant
    columns use scale one and are listed explicitly, not silently discarded.
    Scaling does not make a nonstationary feature stationary.
    """

    columns: tuple[str, ...]
    means: tuple[float, ...]
    scales: tuple[float, ...]
    constant_columns: tuple[str, ...]
    training_start: str
    training_end: str
    nobs: int

    @classmethod
    def fit(
        cls,
        frame: pd.DataFrame,
        *,
        train_start: str | pd.Timestamp,
        train_end: str | pd.Timestamp,
    ) -> TrainingStandardizer:
        _utc_index(frame.index)
        if not frame.columns.is_unique or not all(
            isinstance(column, str) for column in frame.columns
        ):
            raise ValueError("Feature names must be unique strings.")
        start, end = pd.Timestamp(train_start), pd.Timestamp(train_end)
        if str(start.tz) != "UTC" or str(end.tz) != "UTC" or start >= end:
            raise ValueError("Training bounds must be UTC and start < end.")
        training = frame.loc[(frame.index >= start) & (frame.index < end)]
        values = training.to_numpy(dtype=float)
        if len(training) < 2 or values.shape[1] < 1 or not np.isfinite(values).all():
            raise ValueError("Need at least two finite training rows and one feature.")
        means = values.mean(axis=0)
        scales = values.std(axis=0, ddof=0)
        constant = scales == 0
        scales[constant] = 1.0
        return cls(
            columns=tuple(frame.columns),
            means=tuple(float(value) for value in means),
            scales=tuple(float(value) for value in scales),
            constant_columns=tuple(frame.columns[constant]),
            training_start=start.isoformat(),
            training_end=end.isoformat(),
            nobs=len(training),
        )

    def _values(self, frame: pd.DataFrame) -> np.ndarray:
        _utc_index(frame.index)
        if tuple(frame.columns) != self.columns:
            raise ValueError("Feature names/order differ from the fitted training set.")
        values = frame.to_numpy(dtype=float)
        if not np.isfinite(values).all():
            raise ValueError(
                "Transform input must be finite; no imputation is implicit."
            )
        return values

    def transform(self, frame: pd.DataFrame) -> pd.DataFrame:
        values = (self._values(frame) - self.means) / self.scales
        return pd.DataFrame(values, index=frame.index, columns=frame.columns)

    def inverse_transform(self, frame: pd.DataFrame) -> pd.DataFrame:
        values = self._values(frame) * self.scales + self.means
        return pd.DataFrame(values, index=frame.index, columns=frame.columns)


def invert_first_difference_forecast(
    changes: pd.Series,
    *,
    last_observed: float,
    last_observed_time: str | pd.Timestamp,
    expected_frequency: str = "5min",
) -> pd.Series:
    """Restore a d=1 forecast path to the original return scale from one origin.

    If the fitted target was delta(r), pass the last *observed return*, not a
    price. The result is r_hat. This cumulative inverse is for one forecast path;
    independent rolling one-step forecasts each require their own observed
    anchor. Missing forecast steps cannot be skipped.
    """
    _utc_index(changes.index)
    step = pd.Timedelta(expected_frequency)
    origin = pd.Timestamp(last_observed_time)
    if str(origin.tz) != "UTC" or step <= pd.Timedelta(0):
        raise ValueError("Origin must be UTC and frequency must be positive.")
    if not np.isfinite(last_observed) or not np.isfinite(changes.to_numpy()).all():
        raise ValueError("Anchor and predicted changes must be finite.")
    expected = pd.date_range(origin + step, periods=len(changes), freq=step)
    if not changes.index.equals(expected):
        raise ValueError("Forecast path must begin one step after its observed anchor.")
    return (last_observed + changes.cumsum()).rename("return_forecast")
