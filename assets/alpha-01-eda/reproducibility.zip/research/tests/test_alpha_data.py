"""Data integrity, honest historical selection, and timing invariants."""

import hashlib
import json
import re
import zipfile

import numpy as np
import pandas as pd
import pytest

from research.src.alpha_study.data import (
    DEFAULT_ROOT,
    KLINE_COLUMNS,
    NUMERIC_COLUMNS,
    analysis_available_mask,
    analysis_training_mask,
    exclusion_reason,
    fetch_archive,
    load_current_spot_snapshot,
    load_market,
    normalize_klines,
    prepare_analysis_frame,
    read_archive,
    select_universe,
    sha256_file,
    universe_metrics,
    validate_data_contract,
    verify_checksum,
)


def write_fixture_protocol(root, *, current=False):
    """Keep synthetic tests independent of the active protocol's live evidence."""
    content = (DEFAULT_ROOT / "protocol.toml").read_text(encoding="utf-8")
    content = re.sub(r'^version = "[^"]+"', 'version = "1.0.0"', content, flags=re.M)
    content = re.sub(r"^current_spot_.*\n", "", content, flags=re.M)
    content = re.sub(r"\n\[preprocessing\][\s\S]*?(?=\n\[|\Z)", "", content)
    content = content.replace(
        "future_listing_survival_filter = true",
        "future_listing_survival_filter = false",
    )
    content = content.replace(
        "current_tradable_eligible_universe_median", "initial_eligible_universe_median"
    )
    if current:
        content = content.replace('version = "1.0.0"', 'version = "2.0.0"')
        content = content.replace(
            "future_listing_survival_filter = false",
            "future_listing_survival_filter = true",
        )
        content = content.replace(
            "initial_eligible_universe_median",
            "current_tradable_eligible_universe_median",
        )
        content = content.replace(
            "[selection]",
            '[selection]\ncurrent_spot_snapshot = "artifacts/current_spot_snapshot.json"\ncurrent_spot_as_of = "2026-10-13"',
        )
    (root / "protocol.toml").write_text(content, encoding="utf-8")


def write_fixture_snapshot(root, *, rows=None):
    rows = (
        rows
        if rows is not None
        else [
            {
                "symbol": symbol,
                "status": "TRADING",
                "quoteAsset": "USDT",
                "isSpotTradingAllowed": True,
                "present_in_response": True,
            }
            for symbol in selection_input()["symbol"]
        ]
    )
    snapshot = {
        "schema_version": 1,
        "as_of": "2026-10-13",
        "fetched_at_utc": "2026-10-13T12:00:01Z",
        "source_url": "https://api.binance.com/api/v3/exchangeInfo",
        "http_status": 200,
        "http_date": "Tue, 13 Oct 2026 12:00:00 GMT",
        "raw_response_sha256": "a" * 64,
        "evidence_status": "verified_live_response",
        "projection_policy": "all_historical_ranked_candidates",
        "ranked_symbols_sha256": hashlib.sha256(
            json.dumps(
                sorted(row["symbol"] for row in rows), separators=(",", ":")
            ).encode()
        ).hexdigest(),
        "exchange_info": {"symbols": rows},
    }
    path = root / "artifacts/current_spot_snapshot.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(snapshot), encoding="utf-8")
    return path


def persist_fixture_cache(root, frame, symbol="TESTUSDT", frequency="5min"):
    directory = root / "data" / "normalized"
    directory.mkdir(parents=True)
    write_fixture_protocol(root)
    path = directory / f"{symbol}-{frequency}.parquet"
    frame.to_parquet(path)
    artifacts = root / "artifacts"
    artifacts.mkdir()
    manifest = {
        "data_contract_sha256": validate_data_contract(root),
        "files": [
            {
                "symbol": symbol,
                "frequency": frequency,
                "path": path.relative_to(root).as_posix(),
                "sha256": sha256_file(path),
            }
        ],
    }
    (artifacts / "normalized_manifest.json").write_text(json.dumps(manifest))
    return path


def raw_candles(times, prices=None, frequency="5min"):
    index = pd.DatetimeIndex(times)
    if index.tz is None:
        index = index.tz_localize("UTC")
    prices = np.asarray(
        prices if prices is not None else np.arange(len(index)) + 100, dtype=float
    )
    open_time = index.as_unit("ms").asi8
    close_time = (
        (index + pd.Timedelta(frequency) - pd.Timedelta(milliseconds=1))
        .as_unit("ms")
        .asi8
    )
    return pd.DataFrame(
        {
            "open_time": open_time,
            "open": prices,
            "high": prices + 1,
            "low": prices - 1,
            "close": prices,
            "volume": 1,
            "close_time": close_time,
            "quote_volume": prices,
            "trade_count": 1,
            "taker_buy_base_volume": 0.5,
            "taker_buy_quote_volume": prices / 2,
            "ignore": 0,
        }
    )[KLINE_COLUMNS]


def test_grid_keeps_missing_candles_and_breaks_returns():
    raw = raw_candles(
        [
            "2022-01-01 00:00",
            "2022-01-01 00:05",
            "2022-01-01 00:15",
            "2022-01-01 00:20",
        ],
        [100, 110, 120, 130],
    )
    normalized = normalize_klines(raw, start="2022-01-01", end="2022-01-01 00:25")
    assert len(normalized) == 5
    assert str(normalized.index.tz) == "UTC"
    assert normalized["missing_candle"].tolist() == [False, False, True, False, False]
    assert normalized["log_return"].iloc[1] == pytest.approx(np.log(1.1))
    assert normalized["log_return"].iloc[2:4].isna().all()
    assert normalized["log_return"].iloc[4] == pytest.approx(np.log(130 / 120))
    assert normalized["available_at"].iloc[0] == pd.Timestamp(
        "2022-01-01 00:05", tz="UTC"
    )
    assert pd.isna(normalized["close_time"].iloc[2])


def test_invalid_ohlc_is_quarantined_and_breaks_next_return():
    raw = raw_candles(pd.date_range("2022-01-01", periods=4, freq="5min"))
    raw.loc[1, "high"] = 0
    normalized = normalize_klines(raw)
    assert normalized["invalid_candle"].tolist() == [False, True, False, False]
    assert normalized["log_return"].iloc[:3].isna().all()
    assert pd.isna(normalized["close"].iloc[1])
    assert normalized["observed"].all()


def test_duplicates_and_offgrid_are_not_silently_repaired():
    duplicate = raw_candles(["2022-01-01", "2022-01-01"])
    with pytest.raises(ValueError, match="Duplicate"):
        normalize_klines(duplicate)
    with pytest.raises(ValueError, match="off-grid"):
        normalize_klines(raw_candles(["2022-01-01 00:01"]))


def test_close_timestamp_must_be_in_its_candle():
    raw = raw_candles(["2022-01-01"])
    raw["close_time"] += 300_000
    with pytest.raises(ValueError, match="Close time"):
        normalize_klines(raw)


def test_microseconds_are_parsed_without_wrong_dates():
    raw = raw_candles(["2022-01-01"])
    raw[["open_time", "close_time"]] *= 1000
    assert normalize_klines(raw).index[0] == pd.Timestamp("2022-01-01", tz="UTC")


def test_empty_archive_becomes_explicit_missing_grid():
    normalized = normalize_klines(pd.DataFrame(), start="2022-01-01", end="2022-01-02")
    assert len(normalized) == 288
    assert normalized["missing_candle"].all()
    assert normalized["log_return"].isna().all()


def test_checksum_and_archive_schema(tmp_path):
    path = tmp_path / "candles.zip"
    raw = raw_candles(["2022-01-01"])
    with zipfile.ZipFile(path, "w") as archive:
        archive.writestr("candles.csv", raw.to_csv(index=False, header=False))
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    assert verify_checksum(path, digest + "  candles.zip") == digest
    assert len(read_archive(path)) == 1
    with pytest.raises(ValueError, match="mismatch"):
        verify_checksum(path, "0" * 64)
    with pytest.raises(ValueError, match="Invalid"):
        verify_checksum(path, "invalid")


def test_exclusions_are_explicit_and_do_not_misclassify_jup():
    assert exclusion_reason("BTCUSDT") == "bitcoin_external_factor"
    assert exclusion_reason("USDCUSDT") == "stablecoin"
    assert exclusion_reason("EURUSDT") == "fiat"
    assert exclusion_reason("ETHDOWNUSDT") == "leveraged_token"
    assert exclusion_reason("JUPUSDT") is None


def selection_input():
    return pd.DataFrame(
        {
            "symbol": [f"COIN{number}USDT" for number in range(10)],
            "coverage": 1.0,
            "median_daily_quote_volume": np.arange(1, 11) * 1e6,
            "return_std": [0.01] * 6 + [0.1, 0.2, 0.3, 0.4],
        }
    )


def test_selection_is_disjoint_historical_and_deterministic():
    metrics = selection_input()
    selected = select_universe(metrics.sample(frac=1, random_state=1))
    assert selected["symbol"].tolist() == [
        "COIN9USDT",
        "COIN8USDT",
        "COIN4USDT",
        "COIN5USDT",
        "COIN7USDT",
        "COIN6USDT",
    ]
    assert selected["symbol"].nunique() == 6
    assert (
        selected["family"].tolist()
        == ["high_liquidity"] * 2 + ["medium_liquidity"] * 2 + ["high_volatility"] * 2
    )
    assert selected["universe_median_daily_quote_volume"].eq(5.5e6).all()


def test_ineligible_or_stable_asset_cannot_change_universe_median():
    metrics = selection_input()
    extra = pd.DataFrame(
        [
            {
                "symbol": "USDCUSDT",
                "coverage": 1,
                "median_daily_quote_volume": 1e12,
                "return_std": 1,
            },
            {
                "symbol": "LATEUSDT",
                "coverage": 0.5,
                "median_daily_quote_volume": 1e15,
                "return_std": 5,
            },
        ]
    )
    assert (
        select_universe(pd.concat([metrics, extra]))["symbol"].tolist()
        == select_universe(metrics)["symbol"].tolist()
    )


def test_v2_listing_filter_precedes_median_and_preserves_v1_selection():
    metrics = selection_input()
    historical = select_universe(metrics)
    tradable = set(metrics["symbol"]) - {"COIN9USDT"}
    current = select_universe(metrics, current_spot_symbols=tradable)
    assert historical["symbol"].iloc[0] == "COIN9USDT"
    assert historical["universe_median_daily_quote_volume"].eq(5.5e6).all()
    assert current["universe_median_daily_quote_volume"].eq(5e6).all()
    assert current["symbol"].tolist() == [
        "COIN8USDT",
        "COIN7USDT",
        "COIN4USDT",
        "COIN3USDT",
        "COIN6USDT",
        "COIN5USDT",
    ]
    with pytest.raises(ValueError, match="six eligible"):
        select_universe(metrics, current_spot_symbols=set())


def test_v2_snapshot_filter_requires_all_three_listing_conditions(tmp_path):
    write_fixture_protocol(tmp_path, current=True)
    path = write_fixture_snapshot(tmp_path)
    document = json.loads(path.read_text())
    rows = document["exchange_info"]["symbols"]
    rows[0]["status"] = "BREAK"
    rows[1]["quoteAsset"] = "BTC"
    rows[2]["isSpotTradingAllowed"] = False
    rows[3] = {"symbol": rows[3]["symbol"], "present_in_response": False}
    path.write_text(json.dumps(document))
    tradable, evidence = load_current_spot_snapshot(tmp_path)
    assert tradable == {f"COIN{number}USDT" for number in range(4, 10)}
    assert evidence["sha256"] == sha256_file(path)
    original_contract = validate_data_contract(tmp_path)
    rows[4]["status"] = "HALT"
    path.write_text(json.dumps(document))
    assert validate_data_contract(tmp_path) != original_contract


@pytest.mark.parametrize(
    "field,value",
    [
        ("as_of", "2026-10-12"),
        ("http_status", 451),
        ("source_url", "https://example.com/api/v3/exchangeInfo"),
        ("evidence_status", "unverified"),
        ("raw_response_sha256", "invalid"),
        ("http_date", "Mon, 12 Oct 2026 12:00:00 GMT"),
        ("fetched_at_utc", "2026-10-12T12:00:01Z"),
        ("fetched_at_utc", "2026-10-13T12:30:01Z"),
        ("fetched_at_utc", "2026-10-13T12:00:01"),
        ("ranked_symbols_sha256", "0" * 64),
    ],
)
def test_invalid_or_stale_listing_snapshot_rejected_before_network(
    tmp_path, monkeypatch, field, value
):
    from research.src.alpha_study import data

    write_fixture_protocol(tmp_path, current=True)
    path = write_fixture_snapshot(tmp_path)
    document = json.loads(path.read_text())
    document[field] = value
    path.write_text(json.dumps(document))
    monkeypatch.setattr(
        data,
        "discover_archive_symbols",
        lambda: pytest.fail("Network must not precede snapshot validation"),
    )
    with pytest.raises(ValueError, match="[Ss]napshot"):
        data.prepare_study(tmp_path)


def test_v2_rejects_v1_frozen_selection_before_network(tmp_path, monkeypatch):
    from research.src.alpha_study import data

    write_fixture_protocol(tmp_path)
    old_contract = validate_data_contract(tmp_path)
    path = tmp_path / "artifacts/selection.json"
    path.parent.mkdir()
    path.write_text(
        json.dumps({"data_contract_sha256": old_contract, "symbols": ["OLDUSDT"]})
    )
    original = path.read_bytes()
    write_fixture_protocol(tmp_path, current=True)
    write_fixture_snapshot(tmp_path)
    monkeypatch.setattr(
        data,
        "discover_archive_symbols",
        lambda: pytest.fail("Frozen selection must be checked before network"),
    )
    with pytest.raises(ValueError, match="Frozen universe data contract mismatch"):
        data.prepare_study(tmp_path)
    assert path.read_bytes() == original


def test_january31_and_future_data_cannot_change_selection_metrics():
    raw = raw_candles(
        pd.date_range("2022-01-01", "2022-02-03", freq="5min", inclusive="left")
    )
    baseline = normalize_klines(raw)
    changed = baseline.copy()
    changed.loc[
        changed.index >= "2022-01-31", ["close", "quote_volume", "log_return"]
    ] = 1e30
    assert universe_metrics("TESTUSDT", baseline) == universe_metrics(
        "TESTUSDT", changed
    )
    assert universe_metrics("TESTUSDT", baseline)["coverage"] == 1


def test_default_loader_hides_concluding_evaluation(tmp_path):
    frame = normalize_klines(raw_candles(["2023-06-30 23:55", "2023-07-01 00:00"]))
    persist_fixture_cache(tmp_path, frame)
    assert len(load_market("TESTUSDT", root=tmp_path)) == 1
    assert len(load_market("TESTUSDT", root=tmp_path, development_only=False)) == 2


def test_loader_rejects_mutated_cached_bytes_before_parquet_parser(tmp_path):
    frame = normalize_klines(raw_candles(["2022-01-01"]))
    path = persist_fixture_cache(tmp_path, frame)
    path.write_bytes(b"not the attested cache")
    with pytest.raises(ValueError, match="integrity failure"):
        load_market("TESTUSDT", root=tmp_path)


def test_loader_requires_manifest(tmp_path):
    frame = normalize_klines(raw_candles(["2022-01-01"]))
    persist_fixture_cache(tmp_path, frame)
    (tmp_path / "artifacts" / "normalized_manifest.json").unlink()
    with pytest.raises(FileNotFoundError, match="Missing normalized manifest"):
        load_market("TESTUSDT", root=tmp_path)


def test_daily_frequency_alias_uses_canonical_verified_cache(tmp_path):
    frame = normalize_klines(
        raw_candles(["2022-01-01"], frequency="1D"), frequency="1D"
    )
    persist_fixture_cache(tmp_path, frame, symbol="BTCUSDT", frequency="1d")
    assert len(load_market("BTCUSDT", root=tmp_path, frequency="1D")) == 1
    pd.testing.assert_frame_equal(
        load_market("BTCUSDT", root=tmp_path, frequency="1d"),
        load_market("BTCUSDT", root=tmp_path, frequency="1D"),
    )


@pytest.mark.parametrize(
    "old,new,setting",
    [
        (
            'end_exclusive = "2024-01-01T00:00:00Z"',
            'end_exclusive = "2025-01-01T00:00:00Z"',
            "data.end_exclusive",
        ),
        (
            "minimum_coverage = 0.99",
            "minimum_coverage = 0.90",
            "selection.minimum_coverage",
        ),
        (
            'pandas_frequency = "5min"',
            'pandas_frequency = "1min"',
            "data.pandas_frequency",
        ),
    ],
)
def test_load_and_prepare_reject_drifted_protocol_before_network(
    tmp_path, monkeypatch, old, new, setting
):
    from research.src.alpha_study import data

    frame = normalize_klines(raw_candles(["2022-01-01"]))
    persist_fixture_cache(tmp_path, frame)
    protocol = tmp_path / "protocol.toml"
    protocol.write_text(protocol.read_text().replace(old, new))
    with pytest.raises(ValueError, match=setting):
        load_market("TESTUSDT", root=tmp_path)
    monkeypatch.setattr(
        data,
        "discover_archive_symbols",
        lambda: pytest.fail("Should fail before network"),
    )
    with pytest.raises(ValueError, match=setting):
        data.prepare_study(tmp_path)


def test_load_rejects_manifest_from_another_data_contract(tmp_path):
    frame = normalize_klines(raw_candles(["2022-01-01"]))
    persist_fixture_cache(tmp_path, frame)
    path = tmp_path / "artifacts" / "normalized_manifest.json"
    manifest = json.loads(path.read_text())
    manifest["data_contract_sha256"] = "0" * 64
    path.write_text(json.dumps(manifest))
    with pytest.raises(ValueError, match="data contract mismatch"):
        load_market("TESTUSDT", root=tmp_path)


def test_archive_manifest_is_json_serializable():
    # Selection schema is persisted and shared with future notebook chats.
    selected = select_universe(selection_input()).to_dict(orient="records")
    assert len(json.loads(json.dumps(selected))) == 6


def test_cached_raw_bytes_are_verified_without_network_or_replacement(
    tmp_path, monkeypatch
):
    from research.src.alpha_study import data

    key = data.archive_key("ETHUSDT", "5m", "2022-01")
    path = tmp_path / "data" / "raw" / key
    path.parent.mkdir(parents=True)
    path.write_bytes(b"immutable bytes")
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    path.with_suffix(".zip.CHECKSUM").write_text(digest)

    def unexpected_network(*args, **kwargs):
        pytest.fail("Cached archive should not be refetched")

    monkeypatch.setattr(data, "_get", unexpected_network)
    loaded, record = fetch_archive("ETHUSDT", "5m", "2022-01", tmp_path)
    assert loaded == path
    assert record["sha256"] == digest
    path.write_bytes(b"corrupt cache")
    with pytest.raises(ValueError, match="mismatch"):
        fetch_archive("ETHUSDT", "5m", "2022-01", tmp_path)
    assert path.read_bytes() == b"corrupt cache"


def test_absent_historical_archive_is_auditable_without_price_imputation(
    tmp_path, monkeypatch
):
    from research.src.alpha_study import data

    class Response:
        status_code = 404

    monkeypatch.setattr(data, "_get", lambda *args, **kwargs: Response())
    path, record = fetch_archive("DELISTEDUSDT", "5m", "2023-01", tmp_path)
    assert path is None
    assert record["status"] == "unavailable"
    assert record["reason"] == "checksum_http_404"
    assert not (tmp_path / "data").exists()


def test_v21_reuses_v2_contract_and_raw_cache_without_mutating_provenance(tmp_path):
    frame = normalize_klines(raw_candles(["2022-01-01", "2022-01-01 00:10"]))
    cache = persist_fixture_cache(tmp_path, frame)
    write_fixture_protocol(tmp_path, current=True)
    snapshot = write_fixture_snapshot(tmp_path)
    contract = validate_data_contract(tmp_path)
    manifest_path = tmp_path / "artifacts/normalized_manifest.json"
    manifest = json.loads(manifest_path.read_text())
    manifest["data_contract_sha256"] = contract
    manifest_path.write_text(json.dumps(manifest))
    selection = tmp_path / "artifacts/selection.json"
    selection.write_text(
        json.dumps(
            {
                "protocol_version": "2.0.0",
                "data_contract_sha256": contract,
                "symbols": ["TESTUSDT"],
            }
        )
    )
    unchanged = {
        path: path.read_bytes() for path in (cache, snapshot, manifest_path, selection)
    }
    protocol = tmp_path / "protocol.toml"
    content = protocol.read_text().replace('version = "2.0.0"', 'version = "2.1.0"')
    content = content.replace("fast_sma = 50", "fast_sma = 30").replace(
        "slow_sma = 200", "slow_sma = 90"
    )
    content += '\n[preprocessing]\nmissing_candles = "linear_ohlcv_flagged"\npreserve_source = true\n'
    protocol.write_text(content)
    assert validate_data_contract(tmp_path) == contract
    loaded = load_market("TESTUSDT", root=tmp_path)
    pd.testing.assert_frame_equal(loaded, frame, check_freq=False)
    assert pd.isna(loaded["close"].iloc[1])
    derived = prepare_analysis_frame(loaded)
    assert derived["is_interpolated"].iloc[1]
    for path, original in unchanged.items():
        assert path.read_bytes() == original


def gap_fixture():
    raw = raw_candles(
        [
            "2021-12-31 23:55",
            "2022-01-01 00:00",
            "2022-01-01 00:15",
            "2022-01-01 00:20",
        ],
        [99, 100, 130, 131],
    )
    raw["volume"] = [1.0, 0.0, 30.0, 3.0]
    raw["quote_volume"] = raw["volume"] * raw["close"]
    raw["trade_count"] = [1, 0, 10, 1]
    return normalize_klines(raw)


def test_interpolation_preserves_raw_flags_and_assigns_actual_availability():
    source = gap_fixture()
    original = source.copy(deep=True)
    result = prepare_analysis_frame(source)
    pd.testing.assert_frame_equal(source, original)
    for name in [
        "valid_candle",
        "observed",
        "missing_candle",
        "invalid_candle",
        "zero_volume",
        "close_time",
        "available_at",
    ]:
        pd.testing.assert_series_equal(result[name], source[name])
    assert result["close"].tolist() == pytest.approx([99, 100, 110, 120, 130, 131])
    assert result["volume"].tolist() == pytest.approx([1, 0, 10, 20, 30, 3])
    assert result["trade_count"].iloc[2:4].tolist() == pytest.approx([10 / 3, 20 / 3])
    assert result["is_interpolated"].tolist() == [
        False,
        False,
        True,
        True,
        False,
        False,
    ]
    assert result["analysis_valid_candle"].all()
    assert result["is_observed"].equals(source["observed"])
    assert result["source_missing_candle"].equals(source["missing_candle"])
    assert result["return_is_interpolated"].tolist() == [
        False,
        False,
        True,
        True,
        True,
        False,
    ]
    right_known = pd.Timestamp("2022-01-01 00:20", tz="UTC")
    assert result["data_available_at"].iloc[2:4].eq(right_known).all()
    assert result["return_available_at"].iloc[2:5].eq(right_known).all()
    assert result["log_return"].iloc[2:5].sum() == pytest.approx(np.log(130 / 100))
    assert (result["low"] <= result["close"]).all()
    assert (result["high"] >= result["close"]).all()
    assert result["analysis_zero_volume"].iloc[1]


def test_interpolation_never_extrapolates_or_repairs_invalid_candles():
    raw = raw_candles(
        ["2022-01-01 00:05", "2022-01-01 00:10", "2022-01-01 00:20", "2022-01-01 00:25"]
    )
    raw.loc[1, "high"] = 0
    source = normalize_klines(raw, start="2022-01-01", end="2022-01-01 00:35")
    result = prepare_analysis_frame(source)
    assert not result["is_interpolated"].any()
    assert result["analysis_valid_candle"].equals(source["valid_candle"])
    assert result["data_available_at"].iloc[[0, 2, 3, 6]].isna().all()
    assert result["log_return"].iloc[:5].isna().all()
    assert pd.notna(result["log_return"].iloc[5])


def test_interpolation_requires_complete_grid_and_genuine_boundaries():
    source = gap_fixture()
    with pytest.raises(ValueError, match="complete calendar grid"):
        prepare_analysis_frame(source.drop(source.index[2]))
    with pytest.raises(ValueError, match="raw candles"):
        prepare_analysis_frame(prepare_analysis_frame(source))
    with pytest.raises(ValueError, match="policy"):
        prepare_analysis_frame(source, missing_candles="forward_fill")


def test_online_availability_does_not_backdate_interpolated_observations():
    result = prepare_analysis_frame(gap_fixture())
    online = analysis_available_mask(result, result["available_at"])
    assert online.tolist() == [False, True, False, False, True, True]
    before_right = analysis_available_mask(result, "2022-01-01 00:15")
    assert before_right.tolist() == [False, True, False, False, False, False]
    after_right = analysis_available_mask(result, "2022-01-01 00:20")
    assert after_right.tolist() == [False, True, True, True, True, False]
    with pytest.raises(ValueError, match="share the candle index"):
        analysis_available_mask(result, result["available_at"].iloc[1:])


def test_training_mask_purges_future_interpolation_inputs_and_next_return_labels():
    result = prepare_analysis_frame(gap_fixture())
    before_right = analysis_training_mask(result, "2022-01-01", "2022-01-01 00:15")
    assert not before_right.any()
    after_right = analysis_training_mask(result, "2022-01-01", "2022-01-01 00:20")
    assert after_right.tolist() == [False, True, False, False, False, False]
    admitted = result.loc[after_right]
    assert (
        admitted["data_available_at"]
        .le(pd.Timestamp("2022-01-01 00:20", tz="UTC"))
        .all()
    )
    changed = gap_fixture()
    changed.loc[changed.index >= "2022-01-01 00:15", NUMERIC_COLUMNS] *= 2
    changed_result = prepare_analysis_frame(changed)
    assert not analysis_training_mask(
        changed_result, "2022-01-01", "2022-01-01 00:15"
    ).any()
    with pytest.raises(ValueError, match="nonempty"):
        analysis_training_mask(result, "2022-01-02", "2022-01-01")


def test_training_sources_must_be_known_at_historical_forecast_origin():
    source = gap_fixture()
    result = prepare_analysis_frame(source)
    mask = analysis_training_mask(result, "2022-01-01", "2022-01-01 00:25")
    assert mask.tolist() == [False, True, False, False, True, False]
    assert not mask.loc[result["is_interpolated"]].any()
    assert analysis_available_mask(result, result["available_at"]).loc[mask].all()
    assert (
        analysis_available_mask(result, "2022-01-01 00:25")
        .loc[result["is_interpolated"]]
        .all()
    )
    # The real 00:00 source is usable once its reconstructed 00:05 label is
    # known at fitting time. Its input is still restricted to the 00:05 origin.
    assert mask.loc[pd.Timestamp("2022-01-01 00:00", tz="UTC")]
    changed_source = source.copy()
    changed_source.loc[changed_source.index >= "2022-01-01 00:15", NUMERIC_COLUMNS] *= 2
    changed = prepare_analysis_frame(changed_source)
    early_origin = pd.Timestamp("2022-01-01 00:00", tz="UTC")
    assert changed.loc[early_origin, "close"] == result.loc[early_origin, "close"]
    assert (
        changed.loc[early_origin, "log_return"]
        == result.loc[early_origin, "log_return"]
    )
    changed_mask = analysis_training_mask(changed, "2022-01-01", "2022-01-01 00:25")
    pd.testing.assert_series_equal(changed_mask, mask)


def test_interpolation_keeps_real_zero_volume_candles_and_flags_synthetic_zeros():
    source = gap_fixture()
    source["volume"] = source["volume"].where(source["missing_candle"], 0)
    source["zero_volume"] = source["valid_candle"]
    result = prepare_analysis_frame(source)
    assert result["analysis_zero_volume"].all()
    assert not result.loc[result["is_interpolated"], "zero_volume"].any()
    pd.testing.assert_series_equal(result["zero_volume"], source["zero_volume"])
