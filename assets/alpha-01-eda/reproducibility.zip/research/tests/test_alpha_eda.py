from types import SimpleNamespace

import numpy as np
import pandas as pd
import pytest

from research.src.alpha_study import eda as eda_module
from research.src.alpha_study import statistics as statistics_module
from research.src.alpha_study.eda import (
    daily_log_returns,
    longest_complete_daily_frame,
    market_regimes,
    representative_windows,
    stationarity_panel,
)
from research.src.alpha_study.protocol import StudyConfig


def test_no_daily_return_from_incomplete_candles():
    index = pd.date_range("2022-01-01", periods=864, freq="5min", tz="UTC")
    frame = pd.DataFrame({"log_return": 0.001}, index=index)
    frame.iloc[300, 0] = np.nan
    daily = daily_log_returns({"A": frame})
    assert daily.iloc[0, 0] == pytest.approx(0.288)
    assert pd.isna(daily.iloc[1, 0])
    assert daily.iloc[2, 0] == pytest.approx(0.288)


def test_joint_bootstrap_segment_does_not_bridge_missing_dates():
    index = pd.date_range("2022-01-01", periods=10, freq="D", tz="UTC")
    frame = pd.DataFrame({"A": 1.0, "B": 2.0}, index=index)
    frame.loc[index[4], "B"] = np.nan
    result = longest_complete_daily_frame(frame)
    assert result.index.equals(index[5:])
    with pytest.raises(ValueError, match="complete calendar"):
        longest_complete_daily_frame(frame.drop(index[4]))


@pytest.mark.parametrize("fast,slow", [(50, 200), (30, 90)])
def test_regime_is_available_next_day_and_causal(fast, slow):
    config = StudyConfig(
        raw={
            "regimes": {
                "fast_sma": fast,
                "slow_sma": slow,
                "transition_days": 14,
                "warmup_days": 200,
            }
        }
    )
    index = pd.date_range("2021-01-01", periods=350, freq="D", tz="UTC")
    frame = pd.DataFrame(
        {"close": np.linspace(1, 5, 350), "valid_candle": True}, index=index
    )
    before = market_regimes(frame, config)
    frame.loc[index[300] :, "close"] = 0.1
    after = market_regimes(frame, config)
    pd.testing.assert_frame_equal(before.loc[: index[300]], after.loc[: index[300]])
    assert before.index[0] == index[0] + pd.Timedelta(days=1)
    assert before.loc[index[slow - 1], "regime"] == "unknown"
    assert before.loc[index[slow], "regime"] == "bull"
    assert before.loc[index[slow], "sma_fast"] == pytest.approx(
        frame.close.iloc[slow - fast : slow].mean()
    )
    assert before.loc[index[slow], "sma_slow"] == pytest.approx(
        frame.close.iloc[:slow].mean()
    )
    if (fast, slow) == (50, 200):
        pd.testing.assert_series_equal(before.sma50, before.sma_fast, check_names=False)
        pd.testing.assert_series_equal(
            before.sma200, before.sma_slow, check_names=False
        )
    else:
        assert "sma50" not in before and "sma200" not in before


def test_regimes_default_reads_current_config_and_equality_is_unknown(monkeypatch):
    config = StudyConfig(
        raw={"regimes": {"fast_sma": 30, "slow_sma": 90, "transition_days": 14}}
    )
    monkeypatch.setattr(eda_module, "load_config", lambda: config)
    index = pd.date_range("2021-01-01", periods=120, freq="D", tz="UTC")
    frame = pd.DataFrame({"close": 100.0, "valid_candle": True}, index=index)
    result = market_regimes(frame)
    pd.testing.assert_frame_equal(result, market_regimes(frame, config))
    assert result.regime.eq("unknown").all()
    assert result.sma_fast.count() == 91
    assert result.sma_slow.count() == 31


@pytest.mark.parametrize("interpolated,delayed", [(True, False), (False, True)])
def test_regime_rejects_interpolated_or_delayed_daily_values(interpolated, delayed):
    index = pd.date_range("2021-01-01", periods=120, freq="D", tz="UTC")
    frame = pd.DataFrame(
        {
            "close": np.linspace(100, 200, len(index)),
            "valid_candle": True,
            "is_interpolated": False,
            "data_available_at": index + pd.Timedelta(days=1),
        },
        index=index,
    )
    frame.loc[index[60], "is_interpolated"] = interpolated
    if delayed:
        frame.loc[index[60], "data_available_at"] += pd.Timedelta(days=1)
    config = StudyConfig(raw={"regimes": {"fast_sma": 30, "slow_sma": 90}})
    with pytest.raises(ValueError, match="raw observed|available after nominal close"):
        market_regimes(frame, config)


@pytest.mark.parametrize("transition_days", [3, 14])
def test_regime_transition_duration_is_configured_and_forward_only(transition_days):
    config = StudyConfig(
        raw={
            "regimes": {
                "fast_sma": 30,
                "slow_sma": 90,
                "transition_days": transition_days,
            }
        }
    )
    index = pd.date_range("2021-01-01", periods=240, freq="D", tz="UTC")
    # One drop following equality gives exactly one change of SMA side here.
    frame = pd.DataFrame(
        {"close": np.r_[np.full(200, 100.0), np.full(40, 1.0)], "valid_candle": True},
        index=index,
    )
    result = market_regimes(frame, config)
    transition_index = result.index[result.regime.eq("transition")]
    assert transition_index.equals(index[201 : 201 + transition_days])
    assert result.loc[index[200], "regime"] == "unknown"
    assert result.loc[index[201 + transition_days], "regime"] == "bear"


@pytest.mark.parametrize(
    "fast,slow,transition", [(90, 30, 14), (0, 90, 14), (30, 90, 0)]
)
def test_regime_rejects_invalid_periods(fast, slow, transition):
    config = StudyConfig(
        raw={
            "regimes": {
                "fast_sma": fast,
                "slow_sma": slow,
                "transition_days": transition,
            }
        }
    )
    frame = pd.DataFrame(
        {"close": 1.0, "valid_candle": True},
        index=pd.date_range("2022-01-01", periods=100, freq="D", tz="UTC"),
    )
    with pytest.raises(ValueError, match="positive integer"):
        market_regimes(frame, config)


@pytest.mark.parametrize("policy", [None, "conflict_as_stationary_flagged"])
def test_stationarity_panel_preserves_diagnostics_and_window_availability(
    monkeypatch, policy
):
    index = pd.date_range("2022-01-01", periods=100, freq="5min", tz="UTC")
    window_end = index[-1] + pd.Timedelta(minutes=5)
    window = SimpleNamespace(refit_start=index[0], refit_end=window_end)
    monkeypatch.setattr(eda_module, "representative_windows", lambda config: [window])
    monkeypatch.setattr(
        statistics_module,
        "adfuller",
        lambda values, **kwargs: (-2.0, 0.01, 1, len(values) - 2, {}, 0.0),
    )
    monkeypatch.setattr(
        statistics_module, "kpss", lambda values, **kwargs: (0.2, 0.02, 1, {})
    )
    settings = {"adf_maxlag": 2}
    if policy is not None:
        settings["stationarity_working_policy"] = policy
    config = StudyConfig(raw={"statistics": settings})
    frame = pd.DataFrame(
        {
            "close": np.linspace(10, 20, len(index)),
            "log_return": np.linspace(-0.01, 0.02, len(index)),
            "valid_candle": True,
            "analysis_valid_candle": True,
            "data_available_at": index + pd.Timedelta(minutes=5),
            "return_available_at": index + pd.Timedelta(minutes=5),
            "is_interpolated": False,
            "return_is_interpolated": False,
        },
        index=index,
    )
    frame.loc[index[:3], "valid_candle"] = False
    frame.loc[index[:3], ["is_interpolated", "return_is_interpolated"]] = True
    # The first two values are only reconstructible after this training cutoff.
    frame.loc[index[0], "data_available_at"] = window_end + pd.Timedelta(minutes=5)
    frame.loc[index[:2], "return_available_at"] = window_end + pd.Timedelta(minutes=5)
    summary, records = stationarity_panel({"A": frame}, config)
    by_series = summary.set_index("series")
    assert summary.status.eq("inconclusive").all()
    assert summary.diagnostic_status.eq("inconclusive").all()
    assert records.status.eq("ok").all()
    assert records.diagnostic_status.eq("inconclusive").all()
    assert records.pvalue.notna().all() and records.adjusted_pvalue.notna().all()
    expected_working = "stationary" if policy else "undetermined"
    assert summary.working_status.eq(expected_working).all()
    assert records.working_status.eq(expected_working).all()
    assert summary.working_policy.eq(policy or "strict").all()
    if policy:
        assert records.working_flag.eq("adf-kpss-conflict").all()
    else:
        assert records.working_flag.isna().all()
    assert by_series.loc["log_price", "availability_excluded_nobs"] == 1
    assert by_series.loc["log_return", "availability_excluded_nobs"] == 2
    assert by_series.loc["log_price", "interpolated_nobs"] == 2
    assert by_series.loc["log_return", "interpolated_nobs"] == 1
    assert records.loc[records.series.eq("log_price"), "nobs"].eq(99).all()
    assert records.loc[records.series.eq("log_return"), "nobs"].eq(98).all()
    assert records.window_end.eq(index[-1].isoformat()).all()
    # Underlying immutable observations were not replaced by the analysis mask.
    assert not frame.loc[index[:3], "valid_candle"].any()


def test_eda_windows_never_use_final_period():
    config = StudyConfig()
    windows = representative_windows(config)
    assert all(window.refit_end <= config.final_start for window in windows)
    assert len({w.refit_end.strftime("%Y-%m") for w in windows}) == len(windows)
