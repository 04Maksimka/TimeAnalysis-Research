"""Shared trading/risk invariants; no actual alpha is fitted or evaluated here."""

import copy
import json

import numpy as np
import pandas as pd
import pytest
from arch import arch_model

from research.src.alpha_study.execution import UnscorablePathError, simulate_long_cash
from research.src.alpha_study.protocol import StudyConfig, make_windows
from research.src.alpha_study.risk import GarchState, weekly_garch_forecasts


def market(n=6):
    index = pd.date_range("2022-01-01", periods=n, freq="5min", tz="UTC")
    bars = pd.DataFrame(
        {"open": 100.0, "high": 100.1, "low": 99.9, "close": 100.0, "volume": 100.0},
        index=index,
    )
    return bars, pd.Series(0.01, index=index), pd.Series(0.1, index=index)


def test_positive_signal_enters_next_open_and_hold_has_no_repeated_fees():
    bars, signal, sigma = market()
    result = simulate_long_cash(bars, signal, sigma)
    assert len(result.trades) == 1
    assert len(result.events) == 2
    trade = result.trades.iloc[0]
    assert trade.entry_time == bars.index[1]
    assert trade.exit_time == bars.index[-1]
    assert trade.exit_reason == "end-of-study"
    expected = (1 - 0.0005) * (1 - 0.001) / ((1 + 0.0005) * (1 + 0.001))
    assert result.equity.iloc[-1].equity == pytest.approx(expected)
    assert result.equity.iloc[0].position == False  # noqa: E712
    assert (result.equity.iloc[1:-1].quantity == trade.quantity).all()


def test_signal_exit_uses_next_open_and_actual_costs():
    bars, signal, sigma = market()
    signal.iloc[2:] = -0.01
    bars.loc[bars.index[3], ["open", "high", "low", "close"]] = [105, 106, 104, 105]
    result = simulate_long_cash(bars, signal, sigma, fee=0, slippage=0)
    trade = result.trades.iloc[0]
    assert trade.exit_time == bars.index[3]
    assert trade.exit_price == 105
    assert trade.exit_reason == "signal"
    assert result.equity.iloc[-1].equity == pytest.approx(1.05)


@pytest.mark.parametrize("zero_volume", [False, True])
def test_both_barriers_in_one_candle_choose_stop_and_no_same_bar_reentry(zero_volume):
    bars, signal, sigma = market(3)
    sigma[:] = 0.01
    bars.loc[bars.index[1], ["high", "low"]] = [105, 95]
    if zero_volume:
        bars.loc[bars.index[1], "volume"] = 0
    signal.iloc[1:] = -1
    result = simulate_long_cash(
        bars,
        signal,
        sigma,
        fee=0,
        slippage=0,
        zero_volume_execution="allow_fills_report_assumption",
    )
    assert len(result.trades) == 1
    trade = result.trades.iloc[0]
    assert trade.exit_reason == "stop"
    assert trade.exit_time == trade.entry_time
    assert trade.exit_price == pytest.approx(100 * np.exp(-0.02))


def test_tight_stop_breached_by_entry_slippage_uses_reference_open():
    bars, signal, sigma = market(3)
    sigma[:] = 0.0001
    signal.iloc[1:] = -1
    result = simulate_long_cash(bars, signal, sigma)
    trade = result.trades.iloc[0]
    assert trade.exit_reason == "stop-gap"
    assert trade.exit_reference_price == 100
    assert trade.exit_price == pytest.approx(100 * (1 - 0.0005))


@pytest.mark.parametrize("opening,reason", [(90, "stop-gap"), (110, "take-gap")])
@pytest.mark.parametrize("zero_volume", [False, True])
def test_gap_barrier_uses_open_before_signal_exit(opening, reason, zero_volume):
    bars, signal, sigma = market(4)
    sigma[:] = 0.01
    signal.iloc[1:] = -1
    bars.loc[bars.index[2], ["open", "high", "low", "close"]] = [
        opening,
        opening,
        opening,
        opening,
    ]
    if zero_volume:
        bars.loc[bars.index[2], "volume"] = 0
    result = simulate_long_cash(
        bars,
        signal,
        sigma,
        fee=0,
        slippage=0,
        zero_volume_execution="allow_fills_report_assumption",
    )
    trade = result.trades.iloc[0]
    assert trade.exit_reason == reason
    assert trade.exit_price == opening


def test_invalid_risk_blocks_entry_but_does_not_reprice_existing_brackets():
    bars, signal, sigma = market(7)
    sigma.iloc[:2] = np.nan
    sigma.iloc[3:] = np.nan
    result = simulate_long_cash(bars, signal, sigma, end_close=False)
    assert result.events.iloc[0].reason == "unavailable-risk"
    assert result.events[result.events.event == "entry"].iloc[0].time == bars.index[3]
    assert result.equity.iloc[3:].position.all()
    assert result.equity.iloc[3:].stop.nunique() == 1
    assert result.trades.empty


def test_future_prices_cannot_change_past_execution_or_equity():
    bars, signal, sigma = market(20)
    result = simulate_long_cash(bars, signal, sigma, end_close=False)
    changed = bars.copy()
    changed.loc[changed.index[10] :, ["open", "high", "low", "close"]] *= 2
    other = simulate_long_cash(changed, signal, sigma, end_close=False)
    pd.testing.assert_frame_equal(result.equity.iloc[:10], other.equity.iloc[:10])


def test_weekly_risk_changes_do_not_force_exit_or_modify_entry_barriers():
    bars, signal, sigma = market(7)
    sigma.iloc[3:] = 0.2
    result = simulate_long_cash(bars, signal, sigma)
    assert len(result.trades) == 1
    assert result.trades.iloc[0].entry_sigma == 0.1
    assert result.equity.iloc[1:-1].stop.nunique() == 1


@pytest.mark.parametrize(
    "policies",
    [
        {},
        {
            "zero_volume_execution": "allow_fills_report_assumption",
            "interpolated_execution": "allow_fills_report_assumption",
        },
    ],
)
def test_missing_data_while_holding_is_unscorable(policies):
    bars, signal, sigma = market()
    bars.loc[bars.index[3], :] = np.nan
    with pytest.raises(UnscorablePathError, match="Missing candle"):
        simulate_long_cash(bars, signal, sigma, **policies)


def test_missing_flat_data_cannot_forward_old_prediction_into_a_trade():
    bars, signal, sigma = market()
    signal.iloc[:] = -1
    signal.iloc[1] = 1
    bars.loc[bars.index[1], :] = np.nan
    result = simulate_long_cash(bars, signal, sigma)
    assert result.trades.empty
    assert not result.equity.position.any()


@pytest.mark.parametrize(
    "policies", [{}, {"zero_volume_execution": "no_fills_report_blocked_orders"}]
)
def test_zero_volume_blocks_entry_and_signal_exit_without_inventing_fills(policies):
    bars, signal, sigma = market(6)
    bars.loc[bars.index[1], "volume"] = 0
    bars.loc[bars.index[3], "volume"] = 0
    signal.iloc[2:] = -1
    result = simulate_long_cash(bars, signal, sigma, **policies)
    trade = result.trades.iloc[0]
    assert trade.entry_time == bars.index[2]
    assert trade.exit_time == bars.index[4]
    assert set(result.events.event) == {
        "blocked-entry",
        "entry",
        "blocked-exit",
        "exit",
    }


def test_zero_volume_cannot_execute_bracket_or_terminal_liquidation():
    bars, signal, sigma = market(3)
    bars.loc[bars.index[2], ["volume", "high", "low"]] = [0, 200, 50]
    result = simulate_long_cash(bars, signal, sigma, end_close=False)
    assert result.equity.iloc[-1].position
    assert result.trades.empty
    with pytest.raises(UnscorablePathError, match="liquidate"):
        simulate_long_cash(bars, signal, sigma)


def test_zero_volume_allowed_entry_and_exit_preserve_actual_costs_and_flags():
    bars, signal, sigma = market()
    bars.loc[bars.index[[1, 3]], "volume"] = 0
    bars.loc[bars.index[3], ["open", "high", "low", "close"]] = [105, 106, 104, 105]
    signal.iloc[2:] = -1
    result = simulate_long_cash(
        bars, signal, sigma, zero_volume_execution="allow_fills_report_assumption"
    )
    trade = result.trades.iloc[0]
    assert len(result.trades) == 1
    assert trade.entry_time == bars.index[1]
    assert trade.exit_time == bars.index[3]
    assert trade.exit_reason == "signal"
    assert trade.entry_zero_volume and trade.exit_zero_volume
    assert not trade.synthetic
    assert result.events.event.tolist() == ["entry", "exit"]
    assert result.events.zero_volume.all()
    assert not result.events.synthetic.any()
    assert result.equity.loc[bars.index[[1, 3]], "tradable"].all()
    expected_quantity = 1 / (100 * 1.0005 * 1.001)
    expected_proceeds = expected_quantity * 105 * 0.9995 * 0.999
    assert trade.quantity == pytest.approx(expected_quantity)
    assert trade.entry_fee == pytest.approx(expected_quantity * 100 * 1.0005 * 0.001)
    assert trade.exit_fee == pytest.approx(expected_quantity * 105 * 0.9995 * 0.001)
    assert result.equity.iloc[-1].equity == pytest.approx(expected_proceeds)
    assert result.events.fee_paid.sum() == pytest.approx(
        trade.entry_fee + trade.exit_fee
    )
    assert result.settings["zero_volume_execution"] == "allow_fills_report_assumption"


def test_zero_volume_allowed_terminal_liquidation_has_costs():
    bars, signal, sigma = market(3)
    bars.loc[bars.index[-1], "volume"] = 0
    result = simulate_long_cash(
        bars, signal, sigma, zero_volume_execution="allow_fills_report_assumption"
    )
    trade = result.trades.iloc[0]
    assert trade.exit_reason == "end-of-study"
    assert trade.exit_zero_volume
    expected = 0.9995 * 0.999 / (1.0005 * 1.001)
    assert result.equity.iloc[-1].equity == pytest.approx(expected)


def test_interpolated_candles_require_explicit_execution_policy():
    bars, signal, sigma = market()
    bars["is_interpolated"] = False
    bars.loc[bars.index[2], "is_interpolated"] = True
    with pytest.raises(ValueError, match="explicit execution policy"):
        simulate_long_cash(bars, signal, sigma)


def test_synthetic_holding_candle_marks_trade_even_when_entry_and_exit_are_observed():
    bars, signal, sigma = market(5)
    bars["is_interpolated"] = False
    bars.loc[bars.index[2], "is_interpolated"] = True
    bars["data_available_at"] = bars.index + pd.Timedelta("5min")
    bars.loc[bars.index[2], "data_available_at"] = bars.index[4]
    result = simulate_long_cash(
        bars, signal, sigma, interpolated_execution="allow_fills_report_assumption"
    )
    trade = result.trades.iloc[0]
    assert trade.entry_time == bars.index[1]
    assert trade.exit_time == bars.index[3]
    assert not trade.entry_synthetic and not trade.exit_synthetic
    assert trade.synthetic and trade.contains_synthetic_candles
    assert result.equity.loc[bars.index[2], "synthetic"]
    exit_event = result.events[result.events.event == "exit"].iloc[0]
    assert not exit_event.synthetic and exit_event.trade_synthetic
    assert result.settings["synthetic_candles"] == 1


def test_synthetic_fill_flags_and_zero_volume_policy_are_independent():
    bars, signal, sigma = market(3)
    bars["is_interpolated"] = [False, True, True]
    bars.loc[bars.index[1:], "volume"] = 0
    result = simulate_long_cash(
        bars,
        signal,
        sigma,
        zero_volume_execution="allow_fills_report_assumption",
        interpolated_execution="allow_fills_report_assumption",
    )
    trade = result.trades.iloc[0]
    assert trade.entry_synthetic and trade.exit_synthetic and trade.synthetic
    fills = result.events[result.events.event.isin(["entry", "exit"])]
    assert fills.synthetic.all() and fills.zero_volume.all()
    assert "source-data-availability-unknown" in result.events.reason.tolist()
    blocked = simulate_long_cash(
        bars, signal, sigma, interpolated_execution="allow_fills_report_assumption"
    )
    assert blocked.trades.empty
    assert "blocked-entry" in blocked.events.event.tolist()


def test_future_interpolation_anchor_cannot_enable_an_earlier_signal():
    bars, signal, sigma = market(6)
    bars["is_interpolated"] = False
    bars.loc[bars.index[1], "is_interpolated"] = True
    bars["data_available_at"] = bars.index + pd.Timedelta("5min")
    bars.loc[bars.index[1], "data_available_at"] = bars.index[4] + pd.Timedelta("5min")
    signal[:] = -1
    signal.iloc[1] = 1
    result = simulate_long_cash(
        bars, signal, sigma, interpolated_execution="allow_fills_report_assumption"
    )
    changed = bars.copy()
    changed.loc[changed.index[[1, 4]], ["open", "high", "low", "close"]] *= 2
    changed_signal = signal.copy()
    changed_signal.iloc[1] = 10
    changed_sigma = sigma.copy()
    changed_sigma.iloc[1] = 0.001
    other = simulate_long_cash(
        changed,
        changed_signal,
        changed_sigma,
        interpolated_execution="allow_fills_report_assumption",
    )
    assert result.trades.empty and other.trades.empty
    assert not result.equity.loc[bars.index[2], "signal_available"]
    assert result.events.iloc[0].reason == "source-data-not-yet-available"
    pd.testing.assert_frame_equal(result.equity.iloc[:4], other.equity.iloc[:4])
    pd.testing.assert_frame_equal(result.events, other.events)


@pytest.mark.parametrize("policy", ["zero_volume_execution", "interpolated_execution"])
def test_unknown_execution_policy_is_rejected(policy):
    bars, signal, sigma = market()
    with pytest.raises(ValueError, match="Unknown"):
        simulate_long_cash(bars, signal, sigma, **{policy: "guess"})


def test_execution_requires_identical_full_grid_and_valid_prices():
    bars, signal, sigma = market()
    with pytest.raises(ValueError, match="identical"):
        simulate_long_cash(bars, signal.iloc[1:], sigma)
    with pytest.raises(ValueError, match="full grid"):
        simulate_long_cash(
            bars.drop(bars.index[2]),
            signal.drop(signal.index[2]),
            sigma.drop(sigma.index[2]),
        )
    bars.iloc[0, bars.columns.get_loc("low")] = 150
    with pytest.raises(ValueError, match="OHLC"):
        simulate_long_cash(bars, signal, sigma)


def garch_sample(n=1800):
    rng = np.random.default_rng(221)
    returns = np.zeros(n)
    variance = 0.000025
    for i in range(n):
        returns[i] = np.sqrt(variance) * rng.standard_t(7) * np.sqrt(5 / 7)
        variance = 0.000001 + 0.1 * returns[i] ** 2 + 0.86 * variance
    return pd.Series(
        returns, index=pd.date_range("2022-01-01", periods=n, freq="5min", tz="UTC")
    )


def test_garch_fit_matches_arch_forecast_and_decimal_scaling():
    history = garch_sample()
    state = GarchState.fit(history)
    reference = arch_model(
        history.to_numpy() * 100, mean="Zero", p=1, q=1, dist="StudentsT", rescale=False
    ).fit(disp="off", update_freq=0)
    expected = np.sqrt(reference.forecast(horizon=1).variance.iloc[-1, 0]) / 100
    assert state.forecast_sigma() == pytest.approx(expected)
    assert state.omega == pytest.approx(reference.params["omega"] / 10000)
    assert state.nu > 2
    assert state.nobs == len(history)
    json.dumps(state.as_dict(), allow_nan=False)


def test_garch_state_update_is_causal_and_requires_next_closed_return():
    state = GarchState.fit(garch_sample())
    untouched = copy.deepcopy(state)
    next_time = state.last_timestamp + pd.Timedelta("5min")
    next_variance = state.forecast_sigma() ** 2
    value = 0.015
    expected = np.sqrt(
        state.omega + state.alpha * value**2 + state.beta * next_variance
    )
    assert state.update_closed_return(value, next_time) == pytest.approx(expected)
    assert untouched.last_timestamp < state.last_timestamp
    with pytest.raises(ValueError, match="exactly"):
        state.update_closed_return(0.0, next_time)
    snapshot = state.as_dict()
    with pytest.raises(ValueError, match="missing"):
        state.update_closed_return(np.nan, next_time + pd.Timedelta("5min"))
    assert snapshot == state.as_dict()


def test_garch_rejects_discontinuous_missing_or_overlong_histories():
    history = garch_sample()
    with pytest.raises(ValueError, match="missing candles"):
        GarchState.fit(history.drop(history.index[100]))
    history.iloc[100] = np.nan
    with pytest.raises(ValueError, match="finite contiguous"):
        GarchState.fit(history)
    with pytest.raises(ValueError, match="thirty days"):
        GarchState.fit(garch_sample(8641))


def test_weekly_garch_fits_only_history_and_invalidates_risk_after_gap():
    history = garch_sample(288 * 37)
    history.iloc[0] = np.nan  # Explicitly recorded unavailable first return.
    windows = make_windows(StudyConfig())[:1]
    future_start = windows[0].test_start
    history.loc[future_start + pd.Timedelta("15min")] = np.nan
    result = weekly_garch_forecasts(history, windows)
    assert result.fits[0]["status"] == "ok"
    assert result.fits[0]["excluded_initial_return"] == 1
    assert result.fits[0]["fit"]["nobs"] == 8639
    origin = future_start - pd.Timedelta("5min")
    assert result.forecasts.loc[origin, "status"] == "ok"
    assert (
        result.forecasts.loc[future_start + pd.Timedelta("15min"), "status"]
        == "unavailable"
    )
    changed = history.copy()
    changed.loc[future_start:] *= 10
    other = weekly_garch_forecasts(changed, windows)
    assert result.fits[0]["fit"] == other.fits[0]["fit"]
    assert (
        result.forecasts.loc[origin, "sigma_next"]
        == other.forecasts.loc[origin, "sigma_next"]
    )


def test_weekly_garch_never_compresses_an_interior_history_gap():
    history = garch_sample(288 * 37)
    history.iloc[100] = np.nan
    result = weekly_garch_forecasts(history, make_windows(StudyConfig())[:1])
    assert result.fits[0]["status"] == "unavailable"
    assert result.forecasts.sigma_next.isna().all()
