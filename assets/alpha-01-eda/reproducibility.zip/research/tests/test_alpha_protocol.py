"""The shared time boundaries must not let future labels into fitting."""

from dataclasses import replace

import pandas as pd
import pytest

from research.src.alpha_study.protocol import (
    StudyConfig,
    config_fingerprint,
    label_mask,
    load_config,
    make_windows,
    source_fingerprint,
)


def test_config_matches_the_agreed_protocol():
    config = load_config()
    assert config.version == "2.1.0"
    assert config.raw["selection"]["future_listing_survival_filter"] is True
    assert config.raw["selection"]["current_spot_as_of"] == "2026-10-13"
    assert config.start == pd.Timestamp("2022-01-01", tz="UTC")
    assert config.end == pd.Timestamp("2024-01-01", tz="UTC")
    assert config.development_end == pd.Timestamp("2023-07-01", tz="UTC")
    assert config.bar_delta == pd.Timedelta(minutes=5)
    assert config.raw["statistics"]["bootstrap_repetitions"] == 5000
    assert config.raw["data"]["eda_include_final_default"] is False
    assert config.raw["windows"]["warm_start"] is False
    assert config.raw["regimes"]["fast_sma"] == 30
    assert config.raw["regimes"]["slow_sma"] == 90
    assert config.raw["regimes"]["transition_days"] == 14
    assert config.raw["regimes"]["warmup_days"] == 200
    assert config.raw["preprocessing"]["missing_candles"] == "linear_ohlcv_flagged"
    assert config.raw["preprocessing"]["extrapolate"] is False
    assert (
        config.raw["statistics"]["stationarity_working_policy"]
        == "conflict_as_stationary_flagged"
    )
    assert (
        config.raw["trading"]["zero_volume_execution"]
        == "allow_fills_report_assumption"
    )
    assert (
        config.raw["trading"]["interpolated_execution"]
        == "allow_fills_report_assumption"
    )


def test_exactly_one_hundred_contiguous_seven_day_test_folds():
    windows = make_windows()
    assert len(windows) == 100
    assert windows[0].test_start == pd.Timestamp("2022-01-31", tz="UTC")
    assert windows[-1].test_end == pd.Timestamp("2024-01-01", tz="UTC")
    assert windows[0].train_start == pd.Timestamp("2022-01-01", tz="UTC")
    for number, window in enumerate(windows):
        assert window.fold == number
        assert window.train_end - window.train_start == pd.Timedelta(days=23)
        assert window.validation_end - window.validation_start == pd.Timedelta(days=7)
        assert window.refit_end - window.refit_start == pd.Timedelta(days=30)
        assert window.test_end - window.test_start == pd.Timedelta(days=7)
        assert window.train_end == window.validation_start
        assert window.validation_end == window.refit_end == window.test_start
        if number:
            assert windows[number - 1].test_end == window.test_start


def test_incomplete_last_fold_is_not_silently_shortened():
    config = replace(load_config(), end=pd.Timestamp("2023-12-31", tz="UTC"))
    windows = make_windows(config)
    assert len(windows) == 99
    assert windows[-1].test_end == pd.Timestamp("2023-12-25", tz="UTC")


def test_final_period_boundary_can_split_a_week_without_changing_refits():
    config = load_config()
    spanning = [
        w
        for w in make_windows(config)
        if w.test_start < config.final_start < w.test_end
    ]
    assert len(spanning) == 1
    assert spanning[0].test_start == pd.Timestamp("2023-06-26", tz="UTC")
    assert spanning[0].test_end == pd.Timestamp("2023-07-03", tz="UTC")


def test_future_target_close_is_purged_from_training_and_validation():
    window = make_windows()[0]
    index = pd.date_range(
        window.refit_start,
        window.refit_end + pd.Timedelta(minutes=5),
        freq="5min",
    )
    for left, right in (
        (window.train_start, window.train_end),
        (window.validation_start, window.validation_end),
        (window.refit_start, window.refit_end),
    ):
        mask = label_mask(index, left, right)
        assert mask.loc[right - pd.Timedelta(minutes=10)]
        assert not mask.loc[right - pd.Timedelta(minutes=5)]
        assert not mask.loc[right]
        admitted = index[mask.to_numpy()]
        target_close = (
            admitted + pd.Timedelta(minutes=10) - pd.Timedelta(milliseconds=1)
        )
        assert (target_close < right).all()
        assert (admitted >= left).all()


def test_naive_or_unsorted_indices_are_rejected():
    index = pd.date_range("2022-01-01", periods=12, freq="5min")
    with pytest.raises(ValueError, match="timezone-aware"):
        label_mask(index, "2022-01-01", "2022-01-02")
    with pytest.raises(ValueError, match="unique and ordered"):
        label_mask(index.tz_localize("UTC")[::-1], "2022-01-01", "2022-01-02")


@pytest.mark.parametrize(
    "change",
    [
        {"history_days": 31},
        {"train_days": 0},
        {"test_days": -1},
        {"selection_end": "2022-02-01"},
        {"final_start": "2024-01-01"},
        {"timeframe": "7min"},
    ],
)
def test_invalid_protocol_windows_are_rejected(change):
    with pytest.raises(ValueError):
        replace(StudyConfig(), **change)


def test_hash_records_configuration_changes_and_file_contents(tmp_path):
    config = load_config()
    assert config_fingerprint(config) == config_fingerprint(load_config())
    assert config_fingerprint(config) != config_fingerprint(
        replace(config, version="2")
    )
    file = tmp_path / "source.py"
    file.write_text("x = 1\n", encoding="utf-8")
    before = source_fingerprint([file])
    file.write_text("x = 2\n", encoding="utf-8")
    assert source_fingerprint([file]) != before
