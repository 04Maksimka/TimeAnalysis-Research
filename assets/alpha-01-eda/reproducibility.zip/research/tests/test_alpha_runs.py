import json

import pytest

from research.src.alpha_study import runs
from research.tests.test_alpha_data import (
    write_fixture_protocol,
    write_fixture_snapshot,
)


def test_source_identity_tracks_notebook_code_helpers_and_lock_not_outputs(tmp_path):
    module = tmp_path / "research/src/alpha_study/module.py"
    helper = tmp_path / "infra/protocol/bootstrap.py"
    notebook = tmp_path / "research/posts/eda/alpha-01-eda.ipynb"
    for path in (module, helper, notebook):
        path.parent.mkdir(parents=True, exist_ok=True)
    module.write_text("value = 1\n")
    helper.write_text("value = 2\n")
    (tmp_path / "pyproject.toml").write_text("[project]\n")
    lock = tmp_path / "uv.lock"
    lock.write_text("version = 1\n")
    content = {"cells": [{"cell_type": "code", "source": ["x = 1\n"], "outputs": []}]}
    notebook.write_text(json.dumps(content))
    original = runs._source_identity(tmp_path)["source_sha256"]
    content["cells"][0]["outputs"] = [{"text": "result"}]
    content["cells"][0]["execution_count"] = 1
    notebook.write_text(json.dumps(content))
    assert runs._source_identity(tmp_path)["source_sha256"] == original
    content["cells"][0]["source"] = "x = 2\n"
    notebook.write_text(json.dumps(content))
    changed_code = runs._source_identity(tmp_path)["source_sha256"]
    assert changed_code != original
    helper.write_text("value = 3\n")
    changed_helper = runs._source_identity(tmp_path)["source_sha256"]
    assert changed_helper != changed_code
    lock.write_text("version = 2\n")
    assert runs._source_identity(tmp_path)["source_sha256"] != changed_helper


def test_source_identity_ignores_checkpoint_presence_content_and_removal(tmp_path):
    notebook = tmp_path / "research/posts/eda/alpha-01-eda.ipynb"
    notebook.parent.mkdir(parents=True)
    (tmp_path / "pyproject.toml").write_text("[project]\n")
    (tmp_path / "uv.lock").write_text("version = 1\n")
    content = {"cells": [{"cell_type": "code", "source": "x = 1\n"}]}
    notebook.write_text(json.dumps(content))
    clean_checkout_identity = runs._source_identity(tmp_path)

    checkpoint = notebook.parent / ".ipynb_checkpoints/alpha-01-eda-checkpoint.ipynb"
    checkpoint.parent.mkdir()
    checkpoint.write_text(json.dumps(content))
    assert runs._source_identity(tmp_path) == clean_checkout_identity

    # Even a partially written Jupyter checkpoint must not affect provenance.
    checkpoint.write_text('{"cells": [')
    assert runs._source_identity(tmp_path) == clean_checkout_identity

    checkpoint.unlink()
    assert runs._source_identity(tmp_path) == clean_checkout_identity


def test_changed_manifest_during_run_is_recorded_as_failure(tmp_path, monkeypatch):
    identity = {
        "spec_sha256": "spec",
        "data_hash": "before",
        "source_sha256": "source",
    }
    monkeypatch.setattr(runs, "run_identity", lambda root: identity.copy())
    with (
        pytest.raises(RuntimeError, match="data_hash"),
        runs.tracked_run("01-eda", tmp_path),
    ):
        identity["data_hash"] = "after"
    path = tmp_path / "artifacts/runs.jsonl"
    events = [json.loads(line) for line in path.read_text().splitlines()]
    assert [event["event"] for event in events] == ["freeze", "failure"]
    assert runs.audit_runs(path) == []


def test_run_audit_checks_data_not_only_spec(tmp_path):
    path = tmp_path / "runs.jsonl"
    original = {
        "run_id": "x",
        "spec_sha256": "same",
        "data_hash": "data1",
        "source_sha256": "source",
    }
    runs.append_event(path, {**original, "event": "freeze"})
    runs.append_event(path, {**original, "event": "result", "data_hash": "data2"})
    assert runs.audit_runs(path) == ["line 2: changed run identity"]


def test_run_identity_binds_frozen_listing_snapshot_bytes(tmp_path, monkeypatch):
    root = tmp_path / "research/alpha_study"
    root.mkdir(parents=True)
    write_fixture_protocol(root, current=True)
    snapshot = write_fixture_snapshot(root)
    for name in (
        "selection.json",
        "download_manifest.json",
        "normalized_manifest.json",
    ):
        (root / "artifacts" / name).write_text("{}")
    monkeypatch.setattr(
        runs, "_source_identity", lambda repo: {"source_sha256": "source"}
    )
    monkeypatch.setattr(runs.ledger, "code_version", lambda repo: "test")
    original = runs.run_identity(root)
    assert "current_spot_snapshot.json" in original["manifest_hashes"]
    document = json.loads(snapshot.read_text())
    document["exchange_info"]["symbols"][0]["status"] = "BREAK"
    snapshot.write_text(json.dumps(document))
    updated = runs.run_identity(root)
    assert updated["data_hash"] != original["data_hash"]
    assert updated["spec_sha256"] == original["spec_sha256"]


def test_listing_snapshot_change_during_execution_is_failure(tmp_path, monkeypatch):
    root = tmp_path / "research/alpha_study"
    root.mkdir(parents=True)
    write_fixture_protocol(root, current=True)
    snapshot = write_fixture_snapshot(root)
    for name in (
        "selection.json",
        "download_manifest.json",
        "normalized_manifest.json",
    ):
        (root / "artifacts" / name).write_text("{}")
    monkeypatch.setattr(
        runs, "_source_identity", lambda repo: {"source_sha256": "source"}
    )
    monkeypatch.setattr(runs.ledger, "code_version", lambda repo: "test")
    with (
        pytest.raises(RuntimeError, match="data_hash"),
        runs.tracked_run("01-eda", root),
    ):
        snapshot.write_text(snapshot.read_text() + "\n")
    events = [
        json.loads(line)
        for line in (root / "artifacts/runs.jsonl").read_text().splitlines()
    ]
    assert [event["event"] for event in events] == ["freeze", "failure"]
    assert runs.audit_runs(root / "artifacts/runs.jsonl") == []
