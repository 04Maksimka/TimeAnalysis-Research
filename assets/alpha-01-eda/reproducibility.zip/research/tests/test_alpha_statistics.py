"""Statistical validity, timeline safety and reversible preprocessing."""

import copy
import json

import numpy as np
import pandas as pd
import pytest
from scipy.signal import lfilter
from statsmodels.stats.diagnostic import acorr_ljungbox, het_arch
from statsmodels.stats.multitest import multipletests

from infra.protocol.bootstrap import moving_block_indices
from research.src.alpha_study import statistics as statistics_module
from research.src.alpha_study.statistics import (
    adjust_pvalues,
    daily_loss_differences,
    paired_block_bootstrap,
    residual_diagnostics,
    stationarity_tests,
    stationarity_working_classification,
)
from research.src.alpha_study.transforms import (
    TrainingStandardizer,
    invert_first_difference_forecast,
)


def indexed(values, frequency="5min"):
    return pd.Series(
        values,
        index=pd.date_range(
            "2022-01-01", periods=len(values), freq=frequency, tz="UTC"
        ),
    )


def test_joint_stationarity_on_stationary_and_unit_root_processes():
    # Both are stochastic processes with preset seeds, not p-value-picked samples.
    noise = np.random.default_rng(42).normal(size=5000)
    stationary = indexed(lfilter([1], [1, -0.4], noise))
    random_walk = indexed(noise.cumsum())
    stationary_result = stationarity_tests(stationary, maxlag=12)
    unit_root_result = stationarity_tests(random_walk, maxlag=12)
    assert stationary_result["status"] == "stationary-compatible"
    assert unit_root_result["status"] == "nonstationarity-supported"
    assert stationary_result["tests"][0]["settings"]["autolag"] == "AIC"
    assert stationary_result["tests"][1]["settings"]["nlags"] == "auto"
    assert stationary_result["tests"][1]["pvalue_relation"] == ">"
    assert unit_root_result["tests"][1]["pvalue_relation"] == "<"
    json.dumps(stationary_result, allow_nan=False)
    json.dumps(unit_root_result, allow_nan=False)


@pytest.mark.parametrize(
    "adf_p,kpss_p,diagnostic,working,flag",
    [
        (0.01, 0.08, "stationary-compatible", "stationary", None),
        (0.10, 0.02, "nonstationarity-supported", "nonstationary", None),
        (0.01, 0.02, "inconclusive", "stationary", "adf-kpss-conflict"),
        (0.10, 0.08, "inconclusive", "stationary", "adf-kpss-conflict"),
    ],
)
def test_stationarity_working_rule_keeps_raw_evidence(
    monkeypatch, adf_p, kpss_p, diagnostic, working, flag
):
    monkeypatch.setattr(
        statistics_module,
        "adfuller",
        lambda values, **kwargs: (-2.0, adf_p, 1, len(values) - 2, {}, 0.0),
    )
    monkeypatch.setattr(
        statistics_module,
        "kpss",
        lambda values, **kwargs: (0.2, kpss_p, 1, {}),
    )
    values = indexed(np.linspace(1, 2, 100))
    strict = stationarity_tests(values, maxlag=2)
    flagged = stationarity_tests(
        values, maxlag=2, working_policy="conflict_as_stationary_flagged"
    )
    assert strict["status"] == flagged["status"] == diagnostic
    assert flagged["diagnostic_status"] == diagnostic
    assert strict["tests"] == flagged["tests"]
    assert strict["segment"] == flagged["segment"]
    assert strict["working_policy"] == "strict"
    assert strict["working_status"] == ("undetermined" if flag else working)
    assert flagged["working_status"] == working
    assert flagged["working_flag"] == flag
    assert flagged["tests"][0]["pvalue"] == adf_p
    assert flagged["tests"][1]["pvalue"] == kpss_p
    json.dumps(flagged, allow_nan=False)


@pytest.mark.parametrize("unavailable", ["bound", "failed", "not-applicable"])
def test_working_rule_never_promotes_unavailable_evidence(unavailable):
    report = {
        "status": "inconclusive" if unavailable == "bound" else "not-applicable",
        "tests": [
            {"test": "ADF", "status": "ok", "reject": True, "pvalue": 0.001},
            {
                "test": "KPSS",
                "status": "ok",
                "reject": None,
                "pvalue": 0.1,
                "pvalue_relation": ">",
            },
        ],
    }
    if unavailable != "bound":
        report["tests"][1].update(status=unavailable, pvalue=None)
    original = copy.deepcopy(report)
    working = stationarity_working_classification(
        report, policy="conflict_as_stationary_flagged"
    )
    assert working["diagnostic_status"] == report["status"]
    assert working["working_status"] == "undetermined"
    assert working["working_flag"] is None
    assert report == original


def test_working_rule_rejects_unknown_policy():
    with pytest.raises(ValueError, match="working policy"):
        stationarity_working_classification(
            {"status": "inconclusive", "tests": []}, policy="guess"
        )


@pytest.mark.parametrize("kind", ["missing_timestamp", "missing_value"])
def test_stationarity_never_compresses_missing_observations(kind):
    series = indexed(np.random.default_rng(10).normal(size=120))
    if kind == "missing_timestamp":
        series = series.drop(series.index[35])
    else:
        series.iloc[35] = np.nan
    with pytest.raises(ValueError, match="gaps"):
        stationarity_tests(series, maxlag=2)
    result = stationarity_tests(series, maxlag=2, segment_policy="longest")
    assert (
        result["segment"]["window_start"]
        == indexed(np.zeros(120)).index[36].isoformat()
    )
    assert result["segment"]["selected_nobs"] == 84
    assert result["segment"]["segment_count"] == 2
    assert all(record["nobs"] == 84 for record in result["tests"])


def test_stationarity_marks_constant_and_short_inputs_not_applicable():
    for values in (np.ones(100), np.arange(12)):
        result = stationarity_tests(indexed(values))
        assert result["status"] == "not-applicable"
        assert all(record["pvalue"] is None for record in result["tests"])
        assert result["working_status"] == "undetermined"
        assert (
            stationarity_working_classification(
                result, policy="conflict_as_stationary_flagged"
            )["working_status"]
            == "undetermined"
        )
        json.dumps(result, allow_nan=False)


@pytest.mark.parametrize("kind", ["naive", "duplicate", "wrong_grid"])
def test_statistics_reject_ambiguous_time_indexes(kind):
    series = indexed(np.arange(100))
    if kind == "naive":
        series.index = series.index.tz_localize(None)
    elif kind == "duplicate":
        series = pd.concat([series.iloc[:1], series])
    else:
        series.index = series.index + pd.Timedelta("1min")
    with pytest.raises(ValueError):
        stationarity_tests(series)


def test_residual_diagnostics_match_statsmodels_and_degrees_of_freedom():
    series = indexed(np.random.default_rng(7).normal(size=1800))
    records = residual_diagnostics(series, model_df=3)
    by_test = {(record["test"], record["lags"]): record for record in records}
    expected_lb = acorr_ljungbox(series.to_numpy(), lags=[12], model_df=3)
    expected_arch = het_arch(series.to_numpy(), nlags=12, ddof=3)
    assert by_test[("Ljung-Box", 12)]["pvalue"] == pytest.approx(
        expected_lb.iloc[0]["lb_pvalue"]
    )
    assert by_test[("ARCH-LM", 12)]["pvalue"] == pytest.approx(expected_arch[1])
    assert by_test[("Ljung-Box", 288)]["status"] == "ok"
    assert (
        by_test[("Jarque-Bera", None)]["settings"]["interpretation"]
        == "descriptive-only"
    )
    json.dumps(records, allow_nan=False)


def test_residual_diagnostics_do_not_invent_invalid_pvalues():
    records = residual_diagnostics(indexed(np.arange(100)), model_df=12)
    assert records[0]["status"] == "not-applicable"
    assert records[0]["pvalue"] is None
    assert records[2]["status"] == "not-applicable"


@pytest.mark.parametrize("method", ["holm", "fdr_by"])
def test_corrections_preserve_declared_family_and_failed_tests(method):
    records = [
        {"family": "main", "pvalue": 0.01, "status": "ok"},
        {"family": "main", "pvalue": 0.04, "status": "ok"},
        {"family": "main", "pvalue": None, "status": "failed"},
        {"family": "other", "pvalue": 0.01},
    ]
    result = adjust_pvalues(records, method=method)
    expected = multipletests([0.01, 0.04, 1.0], method=method)[1]
    assert result[0]["adjusted_pvalue"] == pytest.approx(expected[0])
    assert result[1]["adjusted_pvalue"] == pytest.approx(expected[1])
    assert result[2]["adjusted_pvalue"] is None
    assert result[2]["status"] == "failed"
    assert result[2]["family_size"] == 3
    assert result[3]["adjusted_pvalue"] == pytest.approx(0.01)
    assert "adjusted_pvalue" not in records[0]
    json.dumps(result, allow_nan=False)


def test_correction_never_treats_kpss_bound_as_exact_pvalue():
    result = adjust_pvalues(
        [
            {"family": "x", "pvalue": 0.01, "pvalue_relation": "<"},
            {"family": "x", "pvalue": float("nan")},
        ]
    )
    assert all(record["adjusted_pvalue"] is None for record in result)
    with pytest.raises(ValueError, match="family"):
        adjust_pvalues([{"pvalue": 0.02}])


@pytest.mark.parametrize("alternative", ["less", "greater", "two-sided"])
def test_identical_daily_differences_have_pvalue_one(alternative):
    result = paired_block_bootstrap(
        indexed(np.zeros(180), "1D"), alternative=alternative
    )
    assert result.iloc[0]["pvalue"] == 1
    assert result.iloc[0]["ci_low"] == result.iloc[0]["ci_high"] == 0


def test_constant_nonzero_difference_uses_centered_null_and_plus_one():
    result = paired_block_bootstrap(
        indexed(np.ones(180), "1D"), draws=999, alternative="greater"
    ).iloc[0]
    assert result["effect"] == 1
    assert result["ci_low"] == result["ci_high"] == 1
    assert result["pvalue"] == 0.001
    wrong_tail = paired_block_bootstrap(
        indexed(np.ones(180), "1D"), draws=999, alternative="less"
    ).iloc[0]
    assert wrong_tail["pvalue"] == 1


def test_bootstrap_shares_indices_across_columns_and_matches_centered_null():
    series = indexed(np.random.default_rng(12).normal(0.2, 1, 196), "1D")
    frame = pd.DataFrame({"original": series, "doubled": 2 * series})
    result = paired_block_bootstrap(frame, draws=200, seed=11).set_index("comparison")
    indices = moving_block_indices(196, 14, 200, np.random.default_rng(11))
    means = series.to_numpy()[indices].mean(axis=1)
    null_means = (series.to_numpy() - series.mean())[indices].mean(axis=1)
    expected_p = (1 + (abs(null_means) >= abs(series.mean())).sum()) / 201
    assert result.loc["original", "pvalue"] == pytest.approx(expected_p)
    assert result.loc["original", "ci_low"] == pytest.approx(np.quantile(means, 0.025))
    assert result.loc["doubled", "pvalue"] == result.loc["original", "pvalue"]
    assert result.loc["doubled", "ci_low"] == 2 * result.loc["original", "ci_low"]
    assert result.loc["doubled", "ci_high"] == 2 * result.loc["original", "ci_high"]


def test_bootstrap_rejects_missing_dates_nan_and_insufficient_effective_blocks():
    daily = indexed(np.zeros(84), "1D")
    with pytest.raises(ValueError, match="consecutive"):
        paired_block_bootstrap(daily.drop(daily.index[40]))
    daily.iloc[40] = np.nan
    with pytest.raises(ValueError, match="finite"):
        paired_block_bootstrap(daily)
    result = paired_block_bootstrap(indexed(np.zeros(55), "1D"))
    assert result.iloc[0]["status"] == "not-applicable"
    assert result.iloc[0]["pvalue"] is None


@pytest.mark.parametrize("block_days", [7, 14, 28])
def test_bootstrap_disallows_formal_inference_on_short_common_samples(block_days):
    result = paired_block_bootstrap(indexed(np.ones(87), "1D"), block_days=block_days)
    assert result.iloc[0]["status"] == "not-applicable"
    assert result.iloc[0]["min_nobs"] == max(180, 12 * block_days)
    assert result.iloc[0]["pvalue"] is None
    assert result.iloc[0]["ci_low"] is None
    assert result.iloc[0]["effect"] == 1


@pytest.mark.parametrize("persistence", [0.0, 0.4])
def test_bootstrap_approximate_null_size_on_synthetic_daily_processes(persistence):
    # A diagnostic of gross size distortion, not a theorem about arbitrary market
    # dependence. 200 independent null samples, with 200 burn-in observations for
    # AR(1), use the real public API and prespecified simulation seeds.
    rng = np.random.default_rng(519)
    rejections = 0
    for experiment in range(200):
        values = lfilter([1], [1, -persistence], rng.normal(size=396))[200:]
        result = paired_block_bootstrap(
            indexed(values, "1D"), draws=499, seed=experiment
        )
        rejections += bool(result.iloc[0]["reject"])
    # Monte Carlo noise and modest finite-sample distortion are expected; a
    # rejection rate above 10% at nominal 5% is a material calibration regression.
    assert 1 <= rejections <= 20, f"Null rejection rate: {rejections / 200:.1%}"


def test_daily_mse_comparison_requires_same_complete_target_dates():
    actual = indexed(np.zeros(288 * 3))
    model = actual + 1
    baseline = actual + 2
    losses = daily_loss_differences(actual, model, baseline)
    assert losses.tolist() == [-3, -3, -3]
    model.iloc[300] = np.nan
    losses = daily_loss_differences(actual, model, baseline)
    assert losses.iloc[0] == -3 and np.isnan(losses.iloc[1])
    with pytest.raises(ValueError, match="identical"):
        daily_loss_differences(actual, model.iloc[1:], baseline)
    # A wholly absent middle day remains present as NaN, not compressed away.
    keep = (actual.index < actual.index[288]) | (actual.index >= actual.index[576])
    losses = daily_loss_differences(actual[keep], model[keep], baseline[keep])
    assert len(losses) == 3 and np.isnan(losses.iloc[1])


def test_training_scaler_cannot_learn_from_modified_future():
    frame = indexed(np.arange(120, dtype=float)).to_frame("returns")
    start, end = frame.index[10], frame.index[80]
    scaler = TrainingStandardizer.fit(frame, train_start=start, train_end=end)
    modified = frame.copy()
    modified.loc[modified.index >= end, "returns"] = 1e9
    other = TrainingStandardizer.fit(modified, train_start=start, train_end=end)
    assert scaler == other
    assert scaler.nobs == 70
    scaled = scaler.transform(frame)
    assert np.allclose(scaler.inverse_transform(scaled), frame)
    assert scaled.loc[(scaled.index >= start) & (scaled.index < end)].mean().iloc[
        0
    ] == pytest.approx(0, abs=1e-12)


def test_first_difference_forecast_returns_original_scale_and_checks_origin():
    changes = indexed([0.001, -0.002, 0.0005])
    origin = changes.index[0] - pd.Timedelta("5min")
    recovered = invert_first_difference_forecast(
        changes, last_observed=0.01, last_observed_time=origin
    )
    assert np.allclose(recovered, [0.011, 0.009, 0.0095])
    with pytest.raises(ValueError, match="begin one step"):
        invert_first_difference_forecast(
            changes.iloc[1:], last_observed=0.01, last_observed_time=origin
        )
